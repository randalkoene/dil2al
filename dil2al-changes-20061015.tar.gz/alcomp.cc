// alcomp.cc
// Randal A. Koene, 20000304

#include "dil2al.hh"

int get_topic_keywords() {
	const int LLEN = 10240;
	char lbuf[LLEN];
	ifstream dilfile;
	for (int i=0; i<numDILs; i++) {
		dilfile.open(*(dil[i]));
		if (dilfile) {
			if (!find_line(&dilfile,"Topic Keywords",lbuf,LLEN)) {
				EOUT << "dil2al: Missing topic keywords in " << *(dil[i]) << " in get_topic_keywords()\n";
				return 0;
			}
			dilfile.close();
		}
	}
	return 1;
}

String generate_AL_full_entry(String dilid, int chunkfreq) {
	String res("<LI><A HREF=\"detailed-items-by-ID.html#"+dilid+"\">"+dilid+"</A> ("+String((long)chunkfreq)+")\n");
	return res;
}

String generate_AL_entry(String dilid, bool ishighestpriority) {
  // Note: This is currently called only when dil2al is run with the
  // command line argument -a. This function generates an entry for manual
  // modification of an AL.
	String idstr;
	if (!read_file_into_String(idfile,idstr)) return String("");
	int idindex;
	idindex = idstr.index(BigRegex("[<]TD[^>]*[>][ 	]*[<]A[ 	]+[^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+dilid));
	if (idindex<0) {
		EOUT << "dil2al: Unable to find " << dilid << " in " << idfile << " in generate_AL_entry()\n";
		return String("");
	}
	String topdil;
	topdil = idstr.at(BigRegex("[<]TD[^>]*[>][ 	]*[<]A[ 	]+[^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\"[^\"]+"+dilid),idindex+1);
	if (topdil=="") {
		EOUT << "dil2al: Unable to find full reference to " << dilid << " in generate_AL_entry()\n";
		return String("");
	}
	topdil = topdil.after(BigRegex("[<]TD[^>]*[>][ 	]*[<]A[ 	]+[^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\""));
	String topdilfile = topdil;
	topdil = basedir+RELLISTSDIR+topdilfile.before("#");
	if (!read_file_into_String(topdil,idstr)) return String("");
	idindex = idstr.index(BigRegex("[<]TD[^>]*[>][ 	]*[<]A[ 	]+[^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+dilid));
	if (idindex<0) {
		EOUT << "dil2al: Unable to find " << dilid << " in " << topdil << " in generate_AL_entry()\n";
		return String("");
	}
	idindex = idstr.index(BigRegex("[<]TR[^>]*[>]"),idindex+1);
	if (idindex<0) return String("");
	idindex = idstr.index(BigRegex("[<]TD[^>]*[>]"),idindex+1);
	if (idindex<0) return String("");
	topdil = idstr.at(BigRegex("[<]TD[^>]*[>]...[^\n]*"),idindex);
	if (topdil=="") return String("");
	topdil = topdil.after(BigRegex("[<]TD[^>]*[>]"));
	topdil.gsub(BigRegex("[<][^>]+[>]"),"");
	if (topdil.length()>100) {
		topdil = topdil.before(100);
		topdil = topdil.before(BigRegex("[ 	\n.,;:]"),-1);
		topdil += "...";
	}
	idstr = "<TR";
	if (ishighestpriority) idstr += " BGCOLOR=\"#3F5F00\"";
	idstr += "><TD>[<A HREF=\""+topdilfile+"\"><B>"+dilid+"</B></A>][<A HREF=\"file:///cgi-bin/dil2al?dil2al=MEI&DILID="+dilid+"\">edit</A>]\n"+topdil;
	return idstr;
}

String AL_Day_Marker(String & dstfile, AL_Day * ald) {
// Generates a table row with data about ald for inclusion in AL files
	if (!ald) return String("");
	String daytxt = "<!-- @select_TL_DIL_refs: SKIP ROW@ --><B>Day " + time_stamp("%Y%m%d",ald->DayDate())
			+ "</B> (suggested start " + time_stamp_GM("%H:%M",ald->DayStart()) + ", limits "
			+ time_stamp_GM("%H:%M",ald->DayStartMin()) + '-' + time_stamp_GM("%H:%M",ald->DayMaxt());
	if (ald->DayType()==1) daytxt += ", worked " + time_stamp_GM("%H:%M",alworked);
	daytxt += "), "; daytxt += String(ald->Total()); daytxt += " task chunks";
	if (ald->Expanded()) daytxt += " (expanded)";
	if (ald->TD_Head()) {
		String relidfile(relurl(dstfile,idfile));
		daytxt += ", target dates: ";
		PLL_LOOP_FORWARD(AL_TD,ald->TD_Head(),1) {
			daytxt += HTML_put_href((relidfile+'#')+e->DE()->chars(),"DIL#" + String(e->DE()->chars()));
			daytxt += " (" + time_stamp("%H:%M",e->DE()->Target_Date()) + ')';
			if (e->Next()) daytxt += ", ";
		}
	}
	return HTML_put_table_row(DEFAULTALDAYEMPHASIS,HTML_put_table_cell("",daytxt)) + '\n';
}

String AL_Passed_Target_Dates(String & dstfile, AL_TD * atd) {
// Generates a list of passed target date DIL entries
  if (atd) {
    String diltext;
    String passedstr(HTML_put_form_input("hidden","name=\"dil2al\" value=\"MEtgroup\"")+"\n<B>Passed Target Dates:</B>\n<UL>\n"), relidfile(relurl(dstfile,idfile));
    PLL_LOOP_FORWARD(AL_TD,atd,1) {
      if (e->DE()->Entry_Text()) diltext = (*e->DE()->Entry_Text());
      else diltext="";
      HTML_remove_tags(diltext);
      Elipsis_At(diltext,30);
      String deidstr(e->DE()->chars());
      passedstr += "<LI>" + HTML_put_href((relidfile+'#')+deidstr,"DIL#"+ deidstr)
	+ "[<A HREF=\"file:///cgi-bin/dil2al?dil2al=MEI&DILID="+deidstr+"\">edit</A>] ("
	+ time_stamp("%Y%m%d%H%M",e->DE()->Target_Date()) + ") "
	+ HTML_put_form_checkbox(String("TDCHKBX")+deidstr,"noupdate","",true)
	+ HTML_put_form_text(String("TD")+deidstr,12) + ' ' + diltext + '\n';
    }
    passedstr += "</UL>\n"+HTML_put_form_radio("TDupdate","group","Minimize fragmentation",true)
      + ' '+HTML_put_form_radio("TDupdate","direct","Direct")+"<BR>\n"
      + HTML_put_form_submit("Update")+' '+HTML_put_form_reset()+"\n<P>\n";
    return HTML_put_form(htmlformmethod,htmlforminterface,passedstr);
  } else return String("");
}

bool Active_List::generate_focused_AL(DIL_entry * superior, time_t algenwt) {
// create the focused list of DIL entries according to dep
// if superior==NULL then a complete AL of all DIL entries was computed
// algenwt is marked at the top of the AL to indicate the
// time allotted per full day prior to any expansions
	// determine number of task chunks to display
	long deplen = allength;
	if (alfocused<deplen) deplen = alfocused;
	if ((generatealmaxt==0) && (deplen>generatealtcs)) deplen = generatealtcs;
	// AL superior information
	String dstfile(basedir+RELLISTSDIR+filestr()+".html");
	String alstr(DEFAULTALFOCUSEDHEADER);
	alstr.gsub("@SUP@",get_supstr());
	alstr.gsub("@GENERAL-WORK-TIME@",time_stamp_GM("%H:%M",algenwt));
	alstr.gsub("@PASSED@",AL_Passed_Target_Dates(dstfile,td.head()));
	// *** perhaps catch MAXTIME_T and interpret it as "none"
	if (superior) alstr.gsub("@TD@",time_stamp("%Y%m%d",superior->Target_Date())); else alstr.gsub("@TD@","none");
	// task chunk information
	String diltext, dilurl; DIL_entry * de;
	PLL_LOOP_FORWARD(AL_Day,al.head(),(deplen>0)) {
		alstr += AL_Day_Marker(dstfile,e);
		for (AL_TC * atc = e->tc.head(); ((atc) && (deplen>0)); atc = atc->Next()) if ((de = atc->Get_DE())!=NULL) {
			if (de->Entry_Text()) diltext = (*de->Entry_Text());
			else {
				VOUT << "dil2al: Warning - Missing Text Content for DIL entry #" << de->chars() << " in generate_focused_AL(), continuing\n";
				diltext="";
			}
			HTML_remove_tags(diltext);
			Elipsis_At(diltext,100);
			if (de->Topics(0)) {
				dilurl = de->Topics(0)->dil.file+'#'+de->chars();
				dilurl = relurl(dstfile,dilurl);
			} else {
				VOUT << "dil2al: Warning - Missing URL for DIL entry #" << de->chars() << " in generate_focused_AL(), continuing\n";
				dilurl='#'+de->chars();
			}
#ifdef INCLUDE_EXACT_TARGET_DATES
			diltext.prepend("[<A HREF=\"file:///cgi-bin/dil2al?dil2al=MEI&DILID="+de->str()+"\">"+time_stamp("%H%M",atc->TCstart())+"</A>]\n");
#else
			diltext.prepend("[<A HREF=\"file:///cgi-bin/dil2al?dil2al=MEI&DILID="+de->str()+"\">edit</A>]\n");
#endif
			if ((e==al.head()) && (atc==e->tc.head())) alstr += HTML_put_table_row(DEFAULTALFOCUSEDEMPHASIS,HTML_put_table_cell("",'['+HTML_put_href(dilurl,de->chars())+"]\n"+diltext)) + '\n';
			else alstr += HTML_put_table_row("",HTML_put_table_cell("",'['+HTML_put_href(dilurl,de->chars())+"]\n"+diltext)) + '\n';
			deplen--;
		} else EOUT << "dil2al: Missing DIL entry in array at day " << time_stamp("%Y%m%d",e->DayDate()) << " in generate_focused_AL(), continuing as is\n";
	}
	String altail(DEFAULTALFOCUSEDTAIL);
	altail.gsub("@SUP@",get_supstr());
	altail.gsub("@ALFILE@",filestr());
	if (alshowcumulativereq) altail.gsub("@CUMULATIVE@","<LI>"+HTML_put_href(filestr()+".ctr.html","Active List - Cumulative Time Required")+'\n');
	else altail.gsub("@CUMULATIVE@","");
	altail.gsub("@ALDATE@",time_stamp("%c"));
	alstr += altail;
	return write_file_from_String(dstfile,alstr,"AL Focused");
}

bool Active_List::generate_wide_AL(DIL_entry * superior) {
// create the wide list of DIL entries according to dep
// if superior==NULL then a complete AL of all DIL entries was computed
	// determine number of task chunks to display
	long deplen = allength;
	if (alwide<deplen) deplen = alwide;
	if ((generatealmaxt==0) && (deplen>generatealtcs)) deplen = generatealtcs;
	// AL superior information
	String dstfile(basedir+RELLISTSDIR+filestr()+".wide.html");
	String alstr(DEFAULTALWIDEHEADER);
	alstr.gsub("@SUP@",get_supstr());
	// task chunk information
	String diltext, dilurl; DIL_entry * de;
	PLL_LOOP_FORWARD(AL_Day,al.head(),(deplen>0)) {
		alstr += "<BR>" + AL_Day_Marker(dstfile,e);
		for (AL_TC * atc = e->tc.head(); ((atc) && (deplen>0)); atc = atc->Next()) if ((de = atc->Get_DE())!=NULL) {
			if (de->Entry_Text()) diltext = (*de->Entry_Text());
			else {
				VOUT << "dil2al: Warning - Missing Text Content for DIL entry #" << de->chars() << " in generate_wide_AL(), continuing\n";
				diltext="";
			}
			HTML_remove_tags(diltext);
			Elipsis_At(diltext,50);
			dilurl = relurl(dstfile,idfile)+'#'+de->chars();
#ifdef INCLUDE_EXACT_TARGET_DATES
			alstr += HTML_put_list_item(HTML_put_href(dilurl,de->chars())+" ["+time_stamp("%H%M",atc->TCstart())+"] "+diltext);
#else
			alstr += HTML_put_list_item(HTML_put_href(dilurl,de->chars())+' '+diltext);
#endif
			deplen--;
		} else EOUT << "dil2al: Missing DIL entry in array at day " << time_stamp("%Y%m%d",e->DayDate()) << " in generate_wide_AL(), continuing as is\n";
	}
	String altail(DEFAULTALWIDETAIL);
	altail.gsub("@SUP@",get_supstr());
	altail.gsub("@ALFILE@",filestr());
	if (alshowcumulativereq) altail.gsub("@CUMULATIVE@","<LI>"+HTML_put_href(filestr()+".ctr.html","Active List - Cumulative Time Required")+'\n');
	else altail.gsub("@CUMULATIVE@","");
	altail.gsub("@ALDATE@",time_stamp("%c"));
	alstr += altail;
	return write_file_from_String(dstfile,alstr,"AL Wide");
}

bool update_main_ALs(DIL_entry * superior) {
// add or modify a link to the AL referred to by superior on
// the main page (NULL = AL created with all DIL entries)
	String mainstr, tag, text, supstr, supfilestr;
	if (superior) supstr = superior->chars(); else supstr = "all";
	supfilestr = relurl(listfile,basedir+RELLISTSDIR+("active-list."+supstr+".html"));
	// get main lists file
	if (!read_file_into_String(listfile,mainstr)) return false;
	int mainloc = 0;
	// locate list of ALs
	do if ((mainloc=HTML_get_name(mainstr,mainloc,tag,text))<0) {
		EOUT << "dil2al: Unable to find HTML anchor ``AL'' in " << listfile << " in update_main_ALs()\n";
		return false;
	} while (tag!="AL");
	// get list of ALs
	int liststart;
	if ((mainloc=HTML_get_list(mainstr,mainloc,tag,text,&liststart))<0) {
		EOUT << "dil2al: Missing list of ALs in " << listfile << " in update_main_ALs()\n";
		return false;
	}
	// find list item with link to AL corresponding with superior
	int listloc = 0; String itemtext,hreftext;
	do if ((listloc=HTML_get_list_item(text,listloc,tag,itemtext))>=0) 
		if (HTML_get_href(itemtext,0,tag,hreftext)<0) EOUT << "dil2al: Missing HREF to AL in " << listfile << " in update_main_ALs(), continuing\n";
	while ((listloc>=0) && (tag!=supfilestr));
	if (listloc>=0) return true; // link already exists
	// if new, add link to AL corresponding with superior
	String newmainstr(mainstr.before(liststart));
	if (superior) {
		if (superior->Entry_Text()) {
			tag = *(superior->Entry_Text());
			Elipsis_At(tag,100);
		} else {
			VOUT << "dil2al: Warning - No text content available for description of AL in update_main_ALs(), continuing as is\n";
			tag = "(No description available.)";
		}
	} else tag = "A list of tasks created with all DIL entries.";
	// *** perhaps don't use relaxedhtml, despite possible unexpected
	//     behaviour by older function that read the main lists page
	text += HTML_put_list_item(HTML_put_href(supfilestr,"Active List: "+capitalize(supstr))+"<BR>\n"+tag+'\n',true)+"<P>\n";
	newmainstr += HTML_put_list('U',text) + mainstr.from(mainloc);
	return write_file_from_String(listfile,newmainstr,"Main Lists");
}

//...add target dates to important DIL entries
//...make more DIL entries for sub-tasks/dependencies
//...perhaps don't put target dates at midnight
//...note: can remove start time parameter
//...count errors or warnings encountered
//...clean up with HTML functions and speed up bottlenecks
//...move gesn inline functions to headers (See C++ FAQ Lite [9.4])
//...perhaps make it possible to pass NULL to HTML functions
//   in order not to retrieve some of the data
//...perhaps use the BigString readline() function for queries
//...maybe turn algenregular, algenall and allgenhpd into seconds (time_t)

// *** make this able to generate an AL for a specific DIL and
// its dependencies (that DIL can be an AL Project)
#define AL_PREPARATION_DELAY 60
float linear_distribution(float i, float i_limit) {
// linearly distribute TC values (see TL#200006291007.2)
// The value of i should not exceed that of i_limit, since the resulting range should be between 1.0 and 0.1.
  if (i>=i_limit) return 0.0;
  return 1.0 - (0.9*i/i_limit);
}

long * DIL_Required_Task_Chunks(DIL_entry ** dep, int deplen) {
// returns an array with the number of task chunks
// required to complete the DIL entries in the array
// dep with length deplen
  long * req = new long[deplen];
  float completion;
  long c_size = ((long) timechunksize)*60;
  for (int i=0; i<deplen; i++) {
    req[i] = dep[i]->Time_Required();
    completion = dep[i]->Completion_State();
    if (completion<0.0) completion = 1.0; // negative completion values have special meaning but do imply that the task is no longer scheduled to be completed
    if (completion>1.0) {
      EOUT << "dil2al: Completion ratio exceeds 1.0 for DIL#";
      if (calledbyforminput) EOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
      EOUT << dep[i]->chars();
      if (calledbyforminput) EOUT << "</A>";
      EOUT << " in DIL_Required_Task_Chunks(), continuing\n";
      req[i] = 0;
      continue;
    }
    completion = ceil(((double) req[i])*(1.0-completion)); // determine remaining time required
    req[i] = (long) completion;
    if (req[i] % c_size) req[i] = (req[i]/c_size) + 1;
    else req[i] /= c_size;
  }
  return req;
}

void Get_Worked_Estimate() {
// update alworked (in seconds)
	if (alworked<0) { // (alworked>=0) if given on command line
		time_t tod;
		switch (alcurdayworkedstrategy) {
			case ACW_TIME: // estimate according to current time
				tod = time_stamp_time_of_day(curtime);
				tod -= alworkdaystart;
				if (tod<0) alworked = 0; else alworked = tod;
				break;
			case ACW_TL: // *** obtain an estimate from task log entries
				EOUT << "dil2al: ACW_TL option not yet implemented in Get_Worked_Estimate(), setting to 0\n";
				alworked = 0;
				break;
			case ACW_ASK: // *** ask for estimate
				EOUT << "dil2al: ACW_ASK option not yet implemented in Get_Worked_Estimate(), setting to 0\n";
				alworked = 0;
				break;
			default: alworked = 0;
		}
	}
}

AL_TC::AL_TC(time_t _tcstart, long itc, long i_limit): de(NULL), tcstart(_tcstart) {
// create TC and set value
	val = linear_distribution((float) itc, (float) i_limit);
	//if (val<0.0) VOUT << "AL_TC:AL_TC val = " << val << " itc=" << itc << " i_limit=" << i_limit << '\n'; VOUT.flush();
}

AL_TC * AL_TC::next_avail_el() {
// returns the next available task chunk
	PLL_LOOP_FORWARD(AL_TC,this,1) if ((!e->Get_DE()) && (e->get_val()>=0.0)) return e;
	return NULL;
}

AL_TC * AL_TC::avail_el(unsigned int n) {
// returns the nth available task chunk
//  VOUT << "TC val: ";
//  PLL_LOOP_FORWARD(AL_TC,this,1) VOUT << e->get_val() << ',';
//  VOUT << '\n'; VOUT.flush();
	PLL_LOOP_FORWARD(AL_TC,this,1) if ((!e->Get_DE()) && (e->get_val()>=0.0)) {
		if (n==0) return e;
		n--;
	}
	return NULL;
}

long AL_TC::available_before(unsigned int n) {
// returns the number of task chunks available before the
// nth task chunk (i.e. does not include the nth task chunk)
// This is used by AL_Day::available_before().
	long avail = 0;
	PLL_LOOP_FORWARD(AL_TC,this,1) {
		if (n==0) return avail;
		if (!e->Get_DE()) avail++;
		n--;
	}
	return avail;
}

float AL_TC::allocate_with_value(float uval, DIL_entry * d) {
// allocate a DIL entry to a task chunk according to
// a random value
// returns the value of the allocated task chunk
// creates TCs if necessary
// Note: This is only for distributed allocation, i.e. only within regular work time task chunks (identified by val >= 0.0)
	const char _err_msg[] = "dil2al: Available TC values do not add up to day value in AL_TC::allocate_with_value(), continuing\n";
	if ((de) || (val<0.0)) {
		if (Next()) return Next()->allocate_with_value(uval,d);
		EOUT << _err_msg;
		return 0.0;
	}
	if (val<uval) {
		if (Next()) return Next()->allocate_with_value(uval-val,d);
		EOUT << _err_msg;
		return 0.0;
	}
	de = d;
	uval = val;
	val = 0.0;
	return uval;
}

AL_TC * AL_TC::allocate(DIL_entry * d) {
// allocates d to the first available task chunk
// returns the allocated task chunk
// Note: This is only for distributed allocation, i.e. only within regular work time task chunks (identified by val >= 0.0)
	if ((de) || (val<0.0)) {
		if (Next()) return Next()->allocate(d);
		return NULL;
	}
	de = d;
	val = 0.0;
	return this;
}

#ifdef INCLUDE_EXACT_TARGET_DATES
bool AL_TC::allocate_if_available(DIL_entry * d) {
  // allocates d to this specific task chunk if it is available
  if (de) return false;
  de = d;
  if (val>=0.0) val = 0.0;
  return true;
}
#endif

#ifdef INCLUDE_DAY_SPECIFIC_WORK_TIMES
AL_Day::AL_Day(time_t dd, time_t tcsec, time_t curt, time_t dmaxt): daytype(0), dayofweek(-1), avail(0), tot(0), daydate(dd), daystartmin(0), daymaxt(dmaxt), tcseconds(tcsec), expanded(false), cache_i_start(0), cache_i_limit(0), val(0.0) {
  // Note: This version does not detect "last day", but that day type is not
  // tested or used anywhere in dil2al anyway.
  time_t curtmindd = curt - dd;
  if ((curtmindd>=0) && (curtmindd<SECONDSPERDAY)) { // current (first) day
    daytype = 1;
    daystartmin = curtmindd;
  }
  if (alworkdaystart>=daystartmin) daystart = alworkdaystart;
  else daystart = daystartmin;
}
#else
AL_Day::AL_Day(time_t dd, int typ, time_t tcsec, time_t dsmin, time_t dmaxt): daytype(typ), avail(0), tot(0), daydate(dd), daystartmin(dsmin), daymaxt(dmaxt), tcseconds(tcsec), expanded(false), cache_i_start(0), cache_i_limit(0), val(0.0) {
  if (alworkdaystart>=daystartmin) daystart = alworkdaystart;
  else daystart = daystartmin;
}
#endif

#ifdef INCLUDE_DAY_SPECIFIC_WORK_TIMES
long AL_Day::set_avail(time_t av) {
  // The day uses daystart and the applicable wdworkendprefs[] value,
  // as well as the maximum indicated in av (seconds) to determine
  // how much work time is available. That amount is divided into
  // task chunks and stored in "avail" and "tot".
  // The smaller of wdworkendprefs[] and daymaxt is applied as a
  // limit for the day, prior to further limitation by av.
  // If av<0 then no task chunks are made available.
  // returns avail
  if (Prev()) { // Initialize dayofweek
    dayofweek = Prev()->DayofWeek() + 1;
    if (dayofweek>6) dayofweek = 0;
  } else dayofweek = atoi((const char *) time_stamp("%w",daydate));
  time_t dayworkend = wdworkendprefs[dayofweek];
  if (dayworkend<0) dayworkend = daymaxt;
  time_t secondsavailable = dayworkend - daystart; // *** or should this be daystartmin?
  if (secondsavailable<0) secondsavailable = 0;
  else if (secondsavailable>av) secondsavailable = av; // limited to the maximum indicated by av
  if (secondsavailable>0) avail = secondsavailable/tcseconds; // floor
  else avail = 0;
  tot = avail; // initialized with all TCs available
  return avail;
}
#else
long AL_Day::set_avail(time_t av) {
// attempt to make av seconds available through task chunks
// returns the number of task chunks made available
// the number of task chunks is limited by (daymaxt-daystartmin)
// if av<0 no task chunks will be made available
	time_t dtmax = daymaxt - daystartmin;
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "dil2al: (DIAGNOSTICS) av = " << av << ", daymaxt = " << daymaxt << ", daystartmin = " << daystartmin << ", dtmax = " << dtmax << '\n';
#endif
	if (av>0) {
		if (av>dtmax) av = dtmax;
		avail = av/tcseconds; // floor, can't exceed limit
	} else avail = 0;
	tot = avail; // initialized with all TCs available
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "dil2al: (DIAGNOSTICS) av = " << av << ", avail = " << avail << ", tot = " << tot << '\n';
#endif
	return avail;
}
#endif

long AL_Day::available_before(time_t td) {
// returns the number of task chunks available for allocation
// prior to a target date td
// avail, daystart, tcseconds and Next()->DayDate() must contain valid values
// *** might be sped up by putting a for-loop into the
//     corresponding Active_List function
	if (Next()) if (td>=Next()->DayDate()) return avail + Next()->available_before(td); // target date is within a following day
	time_t tdiff = td - (daydate+daystart);
	if (tdiff<=0) return 0; // target date is earlier than or at work start offset
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "@tdiff=" << tdiff << ", tcseconds=" << tcseconds << ", tdiff/tcseconds=" << tdiff/tcseconds << '@';
#endif
	long TCs_before = tdiff / tcseconds; // can't exceed target date
	if (TC_Head()) return TC_Head()->available_before(TCs_before); // count available TCs before target date
	return TCs_before;
}

int AL_Day::days_to(time_t td) {
// returns the number of days to the target date, including
// the current day and the day containing the target date
	if (Next()) if (td>Next()->DayDate()) return 1 + Next()->days_to(td);
	return 1;
}

void AL_Day::add_TCs(long tcs, TC_add_method m, time_t addborder) {
// safely add task chunks to a day
// links new task chunks if tchead!=NULL, using TAIL_REPLACE,
// RANDOM or BEFORE_HEAD methods, TAIL_REPLACE and RANDOM
// methods use the addborder parameter
// (see <A HREF="al-day-expand.fig">al-day-expand.fig</A>)
// uses tchead.length() to insure that tot will
// equal tchead.length() if tchead!=NULL
// [***INCOMPLETE] I need to keep this from moving exact target date task chunks.
#ifdef INCLUDE_EXACT_TARGET_DATES
  time_t newtcstart;
#endif
  expanded = true;
  avail += tcs;
  tot += tcs;
  if (tc.head()) {
    long linked = tc.length(), tci;
    tcs = tot - linked; // recalculated to insure at least tot TCs
    if (tcs<0) tcs = 0;
    switch (m) {
    case TAIL_REPLACE:
      // Place empty TCs at tail and move de pointers at chosen
      // random location to those TCs if de->Target_Date()>addborder
#ifdef INCLUDE_EXACT_TARGET_DATES
      newtcstart = tc.tail()->TCstart() + tcseconds;
#endif
      for (; tcs>0; tcs--) {
#ifdef INCLUDE_EXACT_TARGET_DATES
	AL_TC * altc = new AL_TC(newtcstart);
	newtcstart += tcseconds;
#else
	AL_TC * altc = new AL_TC();
#endif
	tc.link_before(altc); linked++;
	tci = (unsigned long) rint(((float) linked)*(((float) rand()) / ((float) RAND_MAX)));
	if (tc[tci]) if (tc[tci]->get_val()>=0.0) {
	  DIL_entry * de = tc[tci]->Get_DE();
	  if (de) if (de->Target_Date()>addborder) altc->Set_DE(tc[tci]->Set_DE(NULL));
	}
      }
      break;
    case RANDOM:
      // Place empty TCs at head and move de pointers at chosen
      // random location to those TCs
      if (linked>addborder) linked = (long) addborder; // number of TCs prior to tdiff
#ifdef INCLUDE_EXACT_TARGET_DATES
      newtcstart = tc.head()->TCstart() - tcseconds;
#endif
      for (; tcs>0; tcs--) {
#ifdef INCLUDE_EXACT_TARGET_DATES
	AL_TC * altc = new AL_TC(newtcstart);
	newtcstart -= tcseconds;
#else
	AL_TC * altc = new AL_TC();
#endif
	tc.link_after(altc); linked++;
	tci = (unsigned long) rint(((float) linked)*(((float) rand()) / ((float) RAND_MAX)));
	if (tc[tci]) if (tc[tci]->get_val()>=0.0) {
	  DIL_entry * de = tc[tci]->Get_DE();
	  if (de) altc->Set_DE(tc[tci]->Set_DE(NULL));
	}
      }
      break;
    case BEFORE_HEAD:
      // link tcs empty TCs before head
#ifdef INCLUDE_EXACT_TARGET_DATES
      newtcstart = tc.head()->TCstart() - tcseconds;
      for (; tcs>0; tcs--) {
	tc.link_after(new AL_TC(newtcstart));
	newtcstart -= tcseconds;
      }
#else
      for (; tcs>0; tcs--) tc.link_after(new AL_TC());
#endif
      break;
    }
  }
}

// <A NAME="AL_Day::expand"></A>
long AL_Day::expand(long expandn, time_t td) {
// expand work time by adding task chunks prior to
// the target date td
// returns the number of task chunks added (-1==error)
// (see <A HREF="al-day-expand.fig">al-day-expand.fig</A>)
	if (expandn<=0) return 0;
	const time_t tdiff(td - daydate); // target date limit (offset in current day)
	// case: TD1 in al-day-expand.fig
	if (tdiff<(daystartmin+tcseconds)) return 0;
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "E>" << time_stamp("%Y%m%d",DayDate()) << ": (" << Total() << ',' << Avail() << "), expand request = " << expandn << '\n';
#endif
	long addabove = 0;
	time_t dayend = daystart+(tot*tcseconds); // if tot==0 dayend is current time
	// cases: TD4, TD5 and TD6 in al-day-expand.fig
	if (tdiff>=(dayend+tcseconds)) { // TD beyond current end of day tasks
		time_t dayendmax = tdiff;
		if (tdiff>daymaxt) dayendmax = daymaxt; // day upper limit
		addabove = (dayendmax-dayend)/tcseconds; // count TCs that can be added prior to target date and daymaxt
		if (addabove>0) {
			if (addabove>expandn) addabove = expandn; // add expandn or fewer TCs above current dayend
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
			VOUT << "Ea>" << time_stamp("%Y%m%d",DayDate()) << ": (" << Total() << ',' << Avail() << ')';
#endif
			add_TCs(addabove,TAIL_REPLACE,daydate+dayendmax); // add empty TCs by replacing allocated TCs with target dates greater than dayendmax and moving those to the tail and update tot and avail
			expandn -= addabove;
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
			VOUT << "->(" << Total() << ',' << Avail() << ")\n";
#endif
			if (expandn<0) EOUT << "dil2al: Warning - Expansion exceeded requirement in AL_Day::expand()\n";
			if (expandn<=0) return addabove;
		}
	}
	// case: TD3 in al-day-expand.fig
	time_t tlowerexpand = daystart;
	TC_add_method m = RANDOM;
	long totbeforetdiff = (tdiff-daystart)/tcseconds;
	// case: TD2 in al-day-expand.fig
	if (totbeforetdiff<=0) {
		tlowerexpand = tdiff;
		m = BEFORE_HEAD;
	}
	if (totbeforetdiff>tot) totbeforetdiff = tot;
	time_t newdaystart = tlowerexpand - (expandn*tcseconds); // attempt to add expandn TCs prior to daystart
	if (newdaystart<daystartmin) newdaystart = daystartmin; // daystart limit
	long addbelow = (tlowerexpand-newdaystart)/tcseconds; // count TCs to be added prior to daystart
	if (addbelow>0) { // add expandn or fewer TCs below min(daystart,TDtime)
		daystart = newdaystart;
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
		VOUT << "Eab>" << time_stamp("%Y%m%d",DayDate()) << ": (" << Total() << ',' << Avail() << ')';
#endif
		add_TCs(addbelow,m,totbeforetdiff); // add empty TCs before target date and update tot and avail
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
		VOUT << "->(" << Total() << ',' << Avail() << ")\n";
#endif
		return addabove+addbelow;
	}
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "Ex>" << time_stamp("%Y%m%d",DayDate()) << ": (" << Total() << ',' << Avail() << ")\n";
#endif
	return addabove;
}

float AL_Day::set_TC_values(long & i_start, long i_limit) {
// set TC values within this day
// returns sum of TC values
	float v;
	cache_i_start = i_start;
	cache_i_limit = i_limit;
	val = 0.0;
	for (long i=0; i<avail; i++) {
		v = linear_distribution((float) (i+i_start), (float) i_limit); // taken care of in function: if ((i+i_start)>=i_limit) v = 0.0;
		if (tc.head()) {
			AL_TC * atc = tc.head()->avail_el(i);
			if (atc) atc->set_val(v);
			else EOUT << "dil2al: Available TC #" << i << " on day " << time_stamp("%Y%m%d",daydate) << " not found in AL_Day::set_TC_values(), continuing\n";
		}
		// assignment of values to remaining TCs occurs when
		// those TCs are created as a search enters them
		val += v; // store summed values of TCs for that day
	}
	i_start += avail;
	return val;
}

void AL_Day::create_TCs(bool setvalues) {
// creates TCs and sets values according to a random
// distribution if setvalues==true, in which case it
// requires valid cache_i_start and cache_i_limit values
  if (tc.head()) return;
  AL_TC * atc;
#ifdef INCLUDE_EXACT_TARGET_DATES
  time_t newtcstart = daydate + daystart;
#endif
  for (long i = 0; i<tot; i++) {
#ifdef INCLUDE_EXACT_TARGET_DATES
    // This may only be allowed to create postiive values for TCs that are within the range prior to a
    // task's target date. Beyond that, the values should be zero.
    // I.e. tot may be greater than cache_i_limit - cache_i_start.
    if (setvalues) atc = new AL_TC(newtcstart,i+cache_i_start,cache_i_limit);
    else atc = new AL_TC(newtcstart);
    newtcstart += tcseconds;
#else
    if (setvalues) atc = new AL_TC(i+cache_i_start,cache_i_limit);
    else atc = new AL_TC();
#endif
    tc.link_before(atc);
  }
}

float AL_Day::allocate_with_value(float uval, DIL_entry * de) {
// allocate a DIL entry to a task chunk according to
// a random value
// returns the value of the allocated task chunk
// creates TCs if necessary
	if (val<uval) {
		if (Next()) return Next()->allocate_with_value(uval-val,de);
		return 0.0; // (error) no more days, value was beyond sum
	}
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "V>" << time_stamp("%Y%m%d",DayDate()) << ": (" << Total() << ',' << Avail() << ')';
#endif
	create_TCs(true); // create TCs if necessary
	float v = tc.head()->allocate_with_value(uval,de);
	if (v>0.0) {
		val -= v;
		avail--;
	}
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "->(" << Total() << ',' << Avail() << ")\n";
#endif
	return v;
}

#ifdef INCLUDE_EXACT_TARGET_DATES
AL_TC * AL_Day::create_TCs_to_date(time_t tctdate, long req) {
  // Insures that TCs exist up to a specific target date.
  // Should only be called for the day within which tctdate appears.
  // returns a pointer to the AL_TC object representing the first
  // task time chunk preceding tctdate
  // Generally, call create_TCs() before this function!
  if (!tc.tail()) { // there are no regular TCs available during this day
    time_t newtcstart = tctdate-tcseconds;
    if (newtcstart<daystartmin) newtcstart = daystartmin;
    for (; ((req>0) && (newtcstart>=daystartmin)); req--) { // add up to req TCs that precede tctdate
	AL_TC * newtc = new AL_TC(newtcstart);
	newtc->set_val(-1.0); // off-limits to regular task chunk distribution
	tc.link_after(newtc); // newtc becomes the new head of the list
        newtcstart -= tcseconds;
    }
    return tc.tail();
  }
  if ((tc.tail()->TCstart()+tcseconds)<tctdate) { // tctdate is later than the end of the current list
    time_t newtcstart = tc.tail()->TCstart()+tcseconds;
    while (newtcstart<tctdate) { // add TCs up to tctdate and form a link
      AL_TC * newtc = new AL_TC(newtcstart);
      newtc->set_val(-1.0); // off-limits to regular task chunk distribution
      tc.link_before(newtc); // newtc becomes the new tail of the list
      newtcstart += tcseconds;
    }
    return tc.tail();
  } else if (tc.head()->TCstart()>=tctdate) { // tctdate is earlier than the beginning of the current list
    time_t newtcstart = tc.head()->TCstart();
    while (newtcstart>tctdate) { // add TCs beyond tctdate that form a link
      newtcstart -= tcseconds;
      AL_TC * newtc = new AL_TC(newtcstart);
      newtc->set_val(-1.0); // off-limits to regular task chunk distribution
      tc.link_after(newtc); // newtc becomes the new head of the list
    }
    AL_TC * res = tc.head();
    for (; ((req>0) && (newtcstart>=daydate)); req--) { // add up to req TCs that precede tctdate
      newtcstart -= tcseconds;
      AL_TC * newtc = new AL_TC(newtcstart);
      newtc->set_val(-1.0); // off-limits to regular task chunk distribution
      tc.link_after(newtc); // newtc becomes the new head of the list
    }
    return res;
  }
  AL_TC * res = tc.tail();
  while ((res->TCstart()>=tctdate) && (res->Prev())) res = res->Prev();
  return res;
}

long AL_Day::allocate_with_date(DIL_entry * de, time_t tctdate, long req, long & regularworktimechunks) {
  // allocate req task chunks for DIL entry de exactly prior to its target date
  // task chunks that coincide with available task chunks during regular work
  // time are reported in regularworktimechunks
  // Task chunks allocated as consecutive as much as possible. If some task
  // chunks within the consecutive block are not available, those lead to
  // task chunks that could not be allocated.
  // returns the number of task chunks that could not be allocated in a set of
  // consecutive task chunks exactly preceding tctdate
  // (The calling function insures that this day is the day that includes tctdate.)
  // tctdate is used instead of de->Target_Date(), so that recursive calls can be
  // used to allocate additional task chunks on preceding days.
  create_TCs(false); // create TCs if necessary
  AL_TC * date_tc = create_TCs_to_date(tctdate,req); // insure that date specific TCs exist
  long nonconsecutive = 0;
  for (; ((req>0) && (date_tc!=NULL)); req--) {
    if (date_tc->allocate_if_available(de)) {
      if (date_tc->get_val()>=0.0) {
	regularworktimechunks++;
	avail--;
      }
    } else nonconsecutive++;
    date_tc = date_tc->Prev();
  }
  // if this day did not contain enough consecutive task chunks preceding tctdate then try the preceding day
  if (req>0) {
    if (Prev()) nonconsecutive += Prev()->allocate_with_date(de,daydate,req,regularworktimechunks);
    else nonconsecutive += req;
  }
  return nonconsecutive;
  return req;
}
#endif

AL_TC * AL_Day::Get_Avail_TC(unsigned long n) {
// returns the nth available task chunk in the AL
// creates task chunks if necessary where tchead==NULL
// note that n loses some of its value capacity by conversion to
// signed in the comparison below
	if (avail<=(long) n) {
		if (Next()) return Next()->Get_Avail_TC(n-avail);
		return NULL;
	}
	create_TCs();
	return tc.head()->avail_el(n);
}

AL_TC * AL_Day::allocate(DIL_entry * de) {
// allocates de to the first available task
// chunk in this day or following days
// returns the allocated task chunk
// creates task chunks if necessary where tchead==NULL
	if (avail<=0) {
		if (Next()) return Next()->allocate(de);
		return NULL;
	}
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "A>" << time_stamp("%Y%m%d",DayDate()) << ": (" << Total() << ',' << Avail() << ')';
#endif
	create_TCs();
	AL_TC * atc = tc.head()->allocate(de);
	if (atc) avail--;
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "->(" << Total() << ',' << Avail() << ")\n";
#endif
	return atc;
}

AL_Day * AL_Day::Add_Target_Date(DIL_entry * de) {
// Adds a target date reference to the day that contains it
	if (!de) return NULL;
	time_t tdiff = de->Target_Date() - daydate;
	if (tdiff<0) {
		if (Prev()) return Prev()->Add_Target_Date(de);
		return NULL;
	}
	if (tdiff>=SECONDSPERDAY) {
		if (Next()) return Next()->Add_Target_Date(de);
		return NULL;
	}
	AL_TD * atd = new AL_TD(*de);
	td.link_before(atd);
	return this;
}

long AL_Day::remove_unused_TCs() {
// clean up by removing unused TCs
// returns remaining number of TCs in AL
	if (!tc.head()) { // no TCs created in this day
		tot = 0;
		avail = 0;
		if (Next()) return Next()->remove_unused_TCs();
		return 0;
	}
	AL_TC * rtc, * atc = tc.head();
	tot = 0; // insure correct count
	while (atc) { // remove unused TCs in this day
		rtc = atc;
		atc = atc->Next();
		if (!rtc->Get_DE()) rtc->remove();
		else tot++; // faster than calling tchead->length()
	}
	avail = 0;
	if (Next()) return tot + Next()->remove_unused_TCs();
	return tot;
}

float AL_Day::squared_day_distribution(time_t td) {
// distribute values up to target date according to a squared function
	float sumval = 0;
	int tddays = days_to(td);
	float fdays = (float) tddays, fi = 0.0;
	long i = 0;
	PLL_LOOP_FORWARD(AL_Day,this,(e->DayDate()<td)) {
		e->val = 1.0 - (aldaydistslope*(fi*fi));
		sumval += e->val;
		i++; fi = ((float) i)/fdays;
	}
	return sumval;
}

float AL_Day::linear_day_distribution(time_t td) {
// linearly distribute values up to target date
	float sumval = 0;
	int tddays = days_to(td);
	float fdays = (float) tddays;
	long i = 0;
	PLL_LOOP_FORWARD(AL_Day,this,(e->DayDate()<td)) {
		e->val = 1.0 - (aldaydistslope*((float) i/fdays));
		sumval += e->val;
		i++;
	}
	return sumval;
}

#ifdef INCLUDE_DAY_SPECIFIC_WORK_TIMES
long Active_List::Add_Days(time_t tcsec, time_t curt, time_t dmaxt, time_t algenwt) {
  // This function allocates enough days to provide allength task chunks.
  // The days allocated determine the actual number of task chunks, hence
  // allength is updated.
  // The time available during the first day may be constrained by the
  // current time.
  // Days take into account weekday specific maximum work times, as
  // specified in wdworkendprefs[], as well as the maximum given in
  // seconds by algenwt.
  // returns the number of days allocated
  time_t dd = time_stamp_time_date(curtime); // current day start
  long actualallength = 0;
  //VOUT << "seeking " << allength << " chunks\n";
  //VOUT << "current time " << curt << '\n';
  //VOUT << "dmaxt " << dmaxt << '\n';
  for (long tcstoallocate = allength; (tcstoallocate>0); ) {
    AL_Day * newalday = new AL_Day(dd,tcsec,curt,dmaxt);
    al.link_before(newalday);
    long daytcs = newalday->set_avail(algenwt);
    //VOUT << "  " << daytcs;
    tcstoallocate -= daytcs;
    actualallength += daytcs;
    dd = time_add_day(dd); // (See the problems described in TL#200609141144.3.)
  }
  allength = actualallength;
  //VOUT << "\ngot " << allength << '\n';
  return al.length();
}
#else
AL_Day * Active_List::Add_Day(int typ, time_t tcsec, time_t dsmin, time_t dmaxt) {
// Add a day to the AL
	time_t dd;
	if (al.tail()) dd = time_add_day(al.tail()->DayDate()); // next day
	else {
#ifdef DIAGNOSTIC_OUTPUT
		EOUT << "curtime = " << curtime << ", curtime(time_t) = " << time_stamp_time(curtime) << '\n';
#endif
		dd = time_stamp_time_date(curtime); // start with current day in calendar time
		typ = 1; // insure start is marked
	}
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "DD: " << dd << ", T: " << Time(NULL) << '\n';
	EOUT << "DDS: " << time_stamp("%Y%m%d%H%M",dd) << ", TS: " << time_stamp("%Y%m%d%H%M",Time(NULL)) << '\n';
#endif
	AL_Day * ald = new AL_Day(dd,typ,tcsec,dsmin,dmaxt);
	al.link_before(ald);
	return ald;
}
#endif

Active_List::Active_List(long req[], long deplen, int algenwt, DIL_entry * sup): superior(sup), supstr("all"), alfilestr("active-list.all"), allength(0), deavail(0) {
	if (superior) {
		supstr = superior->chars();
		alfilestr = "active-list."+supstr;
	}
	allength = Initialize_AL_Length(req,deplen,algenwt,sup);
}

#ifdef INCLUDE_DAY_SPECIFIC_WORK_TIMES
long Active_List::Initialize_AL_Length(long req[], long deplen, time_t algenwt, DIL_entry * superior) {
// returns the number of TCs allocated, data is initialized
// This new version (20060830) uses the wdworkendprefs data to set limits
// to the number of hours allocated on specific days, while algenwt is
// used as an upper limit on the number of hours allocated per day
// (prior to any expansion).
// algenwt is in seconds
  // values used on computations
  long tcseconds = timechunksize*60;
  float c_size = (float) tcseconds;
  long tcsperfullday = algenwt/tcseconds; // floor
#ifdef DIAGNOSTIC_OUTPUT
  EOUT << "tcsperfullday=" << tcsperfullday << '\n';
#endif

  // default initializations
  allength = generatealtcs; // directly into the Active_List::allength variable
#ifdef DIAGNOSTIC_OUTPUT
  EOUT << "allength = " << allength << '\n';
#endif
  time_t lastdaytime = SECONDSPERDAY; // default to full day when no generatealmaxt is specified
  time_t allastdaylimit = -1; // *** why compute this?
  long aldays = 0;

  // curtime data
  time_t curtimesec = time_stamp_time(curtime);
  time_t curdaystart = time_stamp_time_date(curtime);
  time_t curdaytime = time_stamp_time_of_day(curtime);
#ifdef DIAGNOSTIC_OUTPUT
  EOUT << "curdaytime(time_t) = " << curdaytime << '\n';
#endif
  // *** MAKE NEXT LINE DAY SPECIFIC
  long curdaytcs = (long) ceil(((float) (algenwt-alworked))/c_size); // ceiling
  long curdaymaxtcs = (SECONDSPERDAY-curdaytime)/tcseconds; // floor, can't exceed limit
  if (curdaytcs>curdaymaxtcs) curdaytcs = curdaymaxtcs;
#ifdef DIAGNOSTIC_OUTPUT
  EOUT << "curdaytcs = " << curdaytcs << '\n';
#endif

  // determine allength and aldays
  // THIS NOW CORRECTLY OBTAINS allength FROM req[] WHEN generatealtcs==0, BUT aldays IS OBTAINED LATER BY
  // ASKING EACH DAY FOR THE NUMBER OF TASK CHUNKS AVAILABLE.
  VOUT << "AL request initiated with settings generatealtcs=" << generatealtcs << " and generatealmaxt=" << generatealmaxt << '\n';
  if (generatealtcs==0) {
    if (superior) { // *** DIL entry specific AL
      EOUT << "dil2al: DIL entry specific AL not yet implemented in Active_List::Initialize_AL_Length()\n";
    }
    if (!req) {
      EOUT << "dil2al: Missing required time array, req, in Active_List::Initialize_AL_Length()\n";
      return -1;
    }
    for (int i=0; i<deplen; i++) generatealtcs += req[i]; // complete AL
    allength = generatealtcs;
    //aldays = (long) ceil(((float) (allength-curdaytcs))/((float) tcsperfullday)); // ceiling, to include remainder
  } else {
    if (generatealmaxt>0) { // time limit requested
      String maxtstr = time_stamp("%Y%m%d%H%M",generatealmaxt);
      lastdaytime = time_stamp_time_of_day(maxtstr);
      allastdaylimit = lastdaytime - alworkdaystart; // work time on last day of AL
      if (allastdaylimit<0) allastdaylimit = 0;
      if (allastdaylimit>algenwt) allastdaylimit = algenwt;
      time_t lastdaystart = time_stamp_time_date(maxtstr);
      if (curdaystart==lastdaystart) { // last day work time minus time already worked today
	time_t alrem = allastdaylimit - alworked;
	if (alrem<0) allength = 1; // this can be expanded
	else allength = alrem/tcseconds; // floor, can't exceed limit
	//aldays = 0;
      } else {
	long aldays = (lastdaystart-(curdaystart+SECONDSPERDAY))/SECONDSPERDAY; // full days between current and last
	if (aldays>0) allength += aldays*tcsperfullday; // chunks in those days
	else allength = 0;
	allength += allastdaylimit/tcseconds; // floor, can't exceed limit
	allength += curdaytcs;
	//aldays++; // add last day for day start tags
      }
    }// else aldays = (long) ceil(((float) (allength-curdaytcs))/((float) tcsperfullday)); // ceiling, to include remainder
  }

  // initialize data
#ifdef DIAGNOSTIC_OUTPUT
  EOUT << "curdaytime (GM)    = " << time_stamp_GM("%H%M",curdaytime) << '\n';
#endif
  aldays = Add_Days(tcseconds,curtimesec,lastdaytime,algenwt); // also updates allength
  if (!al.head()) {
    EOUT << "dil2al: No AL days generated in Active_List::Initialize_AL_Length()\n";
    return -1;
  }
#ifdef DIAGNOSTIC_OUTPUT
  EOUT << "algenwt = " << algenwt << ", alworked = " << alworked << '\n';
  EOUT << "Day TCs (tot,avail): "; PLL_LOOP_FORWARD(AL_Day,al.head(),1) EOUT << '(' << e->Total() << ',' << e->Avail() << "),"; EOUT << '\n';
  EOUT << "sum of available TCs in allocated days: allength = " << allength << '\n';
#endif
  VOUT << "Preparing AL consisting of " << aldays << " Days that together provide " << allength << " available task chunks.\n";
  return allength;
}
#else
long Active_List::Initialize_AL_Length(long req[], long deplen, time_t algenwt, DIL_entry * superior) {
// returns the number of TCs allocated, data is initialized
	// values used on computations
	long tcseconds = timechunksize*60;
	float c_size = (float) tcseconds;
	long tcsperfullday = algenwt/tcseconds; // floor
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "tcsperfullday=" << tcsperfullday << '\n';
#endif
	// default initializations
	long allength = generatealtcs; // Note that here it is a local variable.
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "allength = " << allength << '\n';
#endif
	time_t lastdaytime = SECONDSPERDAY; // default to full day when no generatealmaxt is specified
	time_t allastdaylimit = -1; // *** why compute this?
	long aldays = 0;
	// curtime data
	time_t curdaystart = time_stamp_time_date(curtime);
	time_t curdaytime = time_stamp_time_of_day(curtime);
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "curdaytime(time_t) = " << curdaytime << '\n';
#endif
	long curdaytcs = (long) ceil(((float) (algenwt-alworked))/c_size); // ceiling
	long curdaymaxtcs = (SECONDSPERDAY-curdaytime)/tcseconds; // floor, can't exceed limit
	if (curdaytcs>curdaymaxtcs) curdaytcs = curdaymaxtcs;
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "curdaytcs = " << curdaytcs << '\n';
#endif
	// determine allength and aldays
	VOUT << "AL request initiated with settings generatealtcs=" << generatealtcs << " and generatealmaxt=" << generatealmaxt << '\n';
	if (generatealtcs==0) {
		if (superior) { // *** DIL entry specific AL
			EOUT << "dil2al: DIL entry specific AL not yet implemented in Active_List::Initialize_AL_Length()\n";
		}
		if (!req) {
			EOUT << "dil2al: Missing required time array, req, in Active_List::Initialize_AL_Length()\n";
			return -1;
		}
		for (int i=0; i<deplen; i++) generatealtcs += req[i]; // complete AL
		allength = generatealtcs;
		aldays = (long) ceil(((float) (allength-curdaytcs))/((float) tcsperfullday)); // ceiling, to include remainder
	} else {
		if (generatealmaxt>0) { // time limit requested
			String maxtstr = time_stamp("%Y%m%d%H%M",generatealmaxt);
			lastdaytime = time_stamp_time_of_day(maxtstr);
			allastdaylimit = lastdaytime - alworkdaystart; // work time on last day of AL
			if (allastdaylimit<0) allastdaylimit = 0;
			if (allastdaylimit>algenwt) allastdaylimit = algenwt;
			time_t lastdaystart = time_stamp_time_date(maxtstr);
			if (curdaystart==lastdaystart) { // last day work time minus time already worked today
				time_t alrem = allastdaylimit - alworked;
				if (alrem<0) allength = 1; // this can be expanded
				else allength = alrem/tcseconds; // floor, can't exceed limit
				aldays = 0;
			} else {
				long aldays = (lastdaystart-(curdaystart+SECONDSPERDAY))/SECONDSPERDAY; // full days between current and last
				if (aldays>0) allength += aldays*tcsperfullday; // chunks in those days
				else allength = 0;
				allength += allastdaylimit/tcseconds; // floor, can't exceed limit
				allength += curdaytcs;
				aldays++; // add last day for day start tags
			}
		} else aldays = (long) ceil(((float) (allength-curdaytcs))/((float) tcsperfullday)); // ceiling, to include remainder
	}
	// initialize data
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "curdaytime (GM)    = " << time_stamp_GM("%H%M",curdaytime) << '\n';
#endif
	if (!aldays) Add_Day(1,tcseconds,curdaytime,lastdaytime); // current and last day
	else {
		Add_Day(1,tcseconds,curdaytime); // current day
#ifdef DIAGNOSTIC_OUTPUT
		for (int i=0; i<(aldays-1); i++) {
			AL_Day * tmp = Add_Day(0,tcseconds,0); // full days
			EOUT << "daystartmin = " << time_stamp_GM("%Y%m%d -- %H%M",tmp->DayStartMin()) << '\n';
			EOUT << "alworkdaystart = " << time_stamp_GM("%Y%m%d -- %H%M",alworkdaystart) << '\n';
			EOUT << "daystart = " << time_stamp_GM("%Y%m%d -- %H%M",tmp->DayStart()) << '\n';
		}
#else
		for (int i=0; i<(aldays-1); i++) Add_Day(0,tcseconds,0); // full days
#endif
		Add_Day(2,tcseconds,0,lastdaytime); // last day
	}
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "allength determined to get " << aldays << " days: " << allength << '\n';
#endif
	if (!al.head()) {
		EOUT << "dil2al: No AL days generated in Active_List::Initialize_AL_Length()\n";
		return -1;
	}
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "algenwt = " << algenwt << ", alworked = " << alworked << '\n';
#endif
	allength = al.head()->set_avail(algenwt-alworked); // remaining time to work on current day (prior to any expansions)
	PLL_LOOP_FORWARD(AL_Day,al.head()->Next(),1) allength += e->set_avail(algenwt);
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "Day TCs (tot,avail): "; PLL_LOOP_FORWARD(AL_Day,al.head(),1) EOUT << '(' << e->Total() << ',' << e->Avail() << "),"; EOUT << '\n';
	EOUT << "sum of available TCs in allocated days: allength = " << allength << '\n';
#endif
	return allength;
}
#endif

long Active_List::expand(long expandn, time_t td) {
// expand work time by adding task chunks to days prior to
// the target date td
// returns the number of task chunks added (-1==error)
	long nadded = 0;
	float sumval, uval;
	switch (aldaydistfunc) { // apply chosen AL day distribution function
		case ALDAYDISTFUNCSQUARED: if ((sumval = al.head()->squared_day_distribution(td))<0) return -1; break;
		default: if ((sumval = al.head()->linear_day_distribution(td))<0) return -1;
	}
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "AL: deavail =" << deavail << '\n';
#endif
	while ((expandn>nadded) && (sumval>FLT_EPSILON)) {
		// *** should this really be done randomly?
		uval = sumval*(((float) rand()) / ((float) RAND_MAX));
		AL_Day * e;
		for (e = al.head(); (e); e = e->Next()) if (uval>e->val) uval -= e->val; else break;
		if (!e) break; // no further expansion is possible
		if (e->expand(1,td)>0) nadded++;
		else { // day cannot expand further
			sumval -= e->val;
			e->val = 0.0;
		}
	}
	allength += nadded; // update total number of TCs in AL
	deavail += nadded; // update temporary value tracking available TCs
#ifdef DETAILED_AL_DIAGNOSTIC_OUTPUT
	VOUT << "AL: deavail =" << deavail << '\n';
#endif
	return nadded;
}

float Active_List::set_TC_values() {
// set TC values in AL
// returns sum of all TC values
// requires that al contains a valid deavail value
	if (deavail<=0) return 0.0;
	float sumval = 0.0;
	long i_start = 0;
	PLL_LOOP_FORWARD(AL_Day,al.head(),1) sumval += e->set_TC_values(i_start,deavail);
	return sumval;
}

float Active_List::allocate_with_value(float uval, DIL_entry * de) {
// allocate a DIL entry to a task chunk according to
// a random value
// returns the value of the allocated task chunk
	if (!al.head()) return 0.0;
	float v = al.head()->allocate_with_value(uval,de);
	if (v>0.0) deavail--; // update temporary value tracking available TCs
	return v;
}

#ifdef INCLUDE_EXACT_TARGET_DATES
long Active_List::allocate_with_date(DIL_entry * de, long req) {
  // allocate req number of task chunks (if available) exactly prior to
  // the target date of de
  if (!al.head()) return req;
  time_t de_tdate = de->Target_Date();
  if ((al.tail()->DayDate()+SECONDSPERDAY-1)<de_tdate) {
    VOUT << "dil2al: Exact target date " << time_stamp("%Y%m%d%H%M",de_tdate) << " exceeds range of generated AL, allocation of DIL entry ";
    if (calledbyforminput) VOUT << "<A HREF=\"" << idfile << '#' << de->chars() << "\">";
    VOUT << de->chars();
    if (calledbyforminput) VOUT << "</A>";
    VOUT << " excluded\n";
    long secondsrequired = timechunksize*60*req;
    if ((al.tail()->DayDate()+SECONDSPERDAY-1)>=(de_tdate-secondsrequired)) VOUT << "        [The " << req << " task chunks needed MAY overlap with time allocated in this AL!]\n";
    return 0;
  }
  // Note: Processing below implies that de is within the current time (checked by calling function) to maximum AL_Day range.
  long regularworktimechunks = 0;
  PLL_LOOP_FORWARD(AL_Day,al.head(),1) if ((e->DayDate()+SECONDSPERDAY)>de_tdate) {
    req = e->allocate_with_date(de,de_tdate,req,regularworktimechunks);
    break;
  }
  deavail -= regularworktimechunks;
  return req;
}
#endif

AL_TC * Active_List::Get_Avail_TC(unsigned long n) {
// returns the nth available task chunk in the AL
// creates task chunks if necessary where tchead==NULL
	if (!al.head()) return NULL;
	return al.head()->Get_Avail_TC(n);
}

AL_TC * Active_List::allocate(DIL_entry * de) {
// allocates de to the first available task chunk in the AL
// returns the allocated task chunk
// creates task chunks if necessary where tchead==NULL
	if (!al.head()) return NULL;
	return al.head()->allocate(de);
}

AL_Day * Active_List::Add_Target_Date(DIL_entry * de) {
// Adds a target date reference to the day that contains it
	if (!al.head()) return NULL;
	return al.head()->Add_Target_Date(de);
}

AL_TD * Active_List::Add_Passed_Target_Date(DIL_entry * de) {
// Adds a passed target date reference to the list
	if (!de) return NULL;
	AL_TD * atd = new AL_TD(*de);
	td.link_before(atd);
	return atd;
}

long Active_List::remove_unused_TCs() {
// clean up by removing unused TCs
// returns remaining number of TCs in AL
	if (!al.head()) {
		allength = 0;
		return 0;
	}
	allength = al.head()->remove_unused_TCs();
	return allength;
}

void generate_EPS_cells(time_t grouptd, String & cumreqstr, String & rowreqstr, double & groupreq, double cumreq, time_t t_current, DIL_entry & de) {
// generate HTML table cells for the EPS method date presented
// when alshowcumulativereq==true
// (See <A HREF="../../doc/html/lists.html#gS1">Earliest Possible Scheduling (EPS)</A>.)
	double cumreqhours = (cumreq*((double) timechunksize))/60.0;
	double epsdays = floor(cumreqhours/alepshours);
	double epshours = cumreqhours - (epsdays*alepshours);
	time_t epsdayssec = ((time_t) epsdays)*SECONDSPERDAY;
	time_t epshourssec = ((time_t) rint(epshours*60.0))*60; // note: properly converts 0.33 and 0.67 hours to 20 and 40 minutes respectively
	time_t epsgrouptd = t_current + epsdayssec + epshourssec;
	String epsgrouptreq = String((groupreq*((double) timechunksize))/60.0,"%6.2f");
	String epsgrouptdstr = time_stamp("%Y%m%d%H%M",epsgrouptd);
	if (targetdatepreferences) { // determine if the calculated target date should be modified according to stated preferences
          if (weekdayworkendpreferences) { // preferred target times on specific days of the week
	    //	    cout << epsgrouptdstr << " --- ";
	    int dayofweek = atoi((const char *) time_stamp("%w",epsgrouptd));
	    if (wdworkendprefs[dayofweek]>=0) {
              if (time_stamp_time_of_day(epsgrouptdstr)<wdworkendprefs[dayofweek]) { // to preferred time
		epsgrouptd = time_stamp_time_date(epsgrouptdstr) + wdworkendprefs[dayofweek];
	      } else { // set to preferred time on next day
		dayofweek++; if (dayofweek>6) dayofweek = 0;
		if (wdworkendprefs[dayofweek] >= 0 ) epsgrouptd = time_stamp_time_date(epsgrouptdstr) + SECONDSPERDAY + wdworkendprefs[dayofweek];
		else epsgrouptd = time_stamp_time_date(epsgrouptdstr) + SECONDSPERDAY + alworkdaystart + (((time_t) rint(alepshours*60.0))*60);
	      }
	      epsgrouptdstr = time_stamp("%Y%m%d%H%M",epsgrouptd);
	    }
	    //	    cout << epsgrouptdstr << '\n';
	  }
	}
	cumreqstr.gsub("@GROUPTREQ@",epsgrouptreq);
	cumreqstr.gsub("@GROUPEPSTD@",epsgrouptdstr);
	// [***INCOMPLETE] In the lines below, I could indicate fixed target dates by not offering update and text input.
	if (rapidscheduleupdating && (epsgrouptd<=grouptd)) { // option not to update target dates beyond the EPS suggested target dates
		cumreqstr.gsub("@GROUPCHECKED@\"","\" checked");
		rowreqstr += HTML_put_table_cell("",epsgrouptreq)+
			   HTML_put_table_cell("",HTML_put_form_checkbox(String("TDCHKBX")+de.chars(),"noupdate","",true)+HTML_put_form_text(String("TD")+de.chars(),epsgrouptdstr,12));
	} else {
		cumreqstr.gsub("@GROUPCHECKED@","");
		rowreqstr += HTML_put_table_cell("",epsgrouptreq)+
			   HTML_put_table_cell("",HTML_put_form_checkbox(String("TDCHKBX")+de.chars(),"noupdate","")+HTML_put_form_text(String("TD")+de.chars(),epsgrouptdstr,12));
	}
	groupreq = 0.0;
	//return epsgrouptdstr;
}

/*
An alternative simplified method would specify an arrary of DIL_Entry pointers
per day, of which some ranges are regular work time and some are not.
When distributing a task, ask all the days for the number of available
task chunks prior to the target date. Use that sum, and a random distribution
(see implementation in nibr) to select a task chunk the required number of
times. To create this, just work your way through the generate_AL function,
or rather a second version of it, and replace called functions as you go.
*/

bool ALCRT_continue_condition(DIL_entry * de, time_t t_limit) {
  // Indicates if processing for the Cumulative Required Times HTML form
  // should continue, based on settings of alCRTlimit.
  switch (alCRTlimit) {
  case 1: if (de->Target_Date()<t_limit) return true; break;;
  case 2: if (de->Target_Date()<MAXTIME_T) return true; break;;
  default: return true;
  }
  return false;
}

bool generate_AL(DIL_entry ** dep, DIL_entry * superior) {
// create AL from sorted array of DIL entries
// if superior == NULL then the AL spans all DIL categories
// if generatealtcs == 0, a complete AL will be computed, for
// the completion of all DIL entries that are dependencies of
// superior
// if generatealmaxt > 0, the AL will be computed up to the
// limit date specified
// if generatealtcs > 0, the AL will be computed for that
// number of Task Chunks
	// check parameters
	if (!dep) {
		EOUT << "dil2al: Missing sorted DIL pointer in generate_AL()\n";
		return false;
	}
	if (!dep[0]) {
		EOUT << "dil2al: Empty DIL in generate_AL()\n";
		return false;
	}
	if (generatealtcs<0) {
		EOUT << "dil2al: Invalid AL interval size (" << generatealtcs << ") requested in generate_AL()\n";
		return false;
	}
	VOUT << "AL automatic expansion is set to ";
	if (alautoexpand) VOUT << "EXPAND\n"; else VOUT << "STRICT\n";
	// prepare DIL entry data
	int deplen = dep[0]->fulllength(); // *** if you supply a custom list of sorted entries, supply the length of the list as well
	long * req = DIL_Required_Task_Chunks(dep,deplen);
	// allocate desired AL interval
	// Note: If there is ever a need for intervals beginning
	// at other times than the current time, that can be
	// accomplished easily by setting curtime to the desired
	// start of the interval.
	time_t algenhpd = ((time_t) algenregular)*3600; // seconds per day (before any expansion)
	if (!superior) algenhpd = ((time_t) algenall)*3600;
	else { // detect specific hpd for superior
		// *** (search up or down?)
		EOUT << "dil2al: Search for superior-specific hours-per-day parmameter not yet implemented in generate_AL()\n";
	}
	Get_Worked_Estimate(); // estimated time already worked on current day
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "alworked = " << alworked << '\n';
#endif
	#define LOCAL_CLEAN_EXIT { delete[] req; return false; }
	Active_List al(req,deplen,algenhpd,superior);
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "allength = " << al.length() << '\n';
#endif
	if (al.length()<1) LOCAL_CLEAN_EXIT
	// distribute task chunks per DIL entry with target date within AL interval
	VOUT << "Distributing task chunks per DIL entry over " << al.length() << " AL task chunks\n";
	float sumval=1.0, uval; double cumreq = 0.0, groupreq = 0.0; int groupnum = 0;
	String cumreqstr, rowreqstr, entryexcerptcell, dstfile, relidfile; time_t grouptd = -1;
	if (alshowcumulativereq) { // cumulative required time file header
		cumreqstr = DEFAULTALCUMULATIVEREQHEADER;
		cumreqstr.gsub("@SUP@",al.get_supstr());
		cumreqstr.gsub("@EPSHRS@",String((double) alepshours,"%5.2f"));
		cumreqstr.gsub("@FORMMETHOD@",htmlformmethod);
		cumreqstr.gsub("@FORMACTION@",htmlforminterface);
		dstfile = basedir+RELLISTSDIR+al.filestr()+".ctr.html";
		relidfile = relurl(dstfile,idfile);
	}
	time_t t_current = Time(NULL) + AL_PREPARATION_DELAY; // expected time upon completion of AL generation
	time_t t_start = al.AL_Head()->DayDate()+al.AL_Head()->DayStart(); // AL start
	time_t t_limit = al.AL_Tail()->DayDate()+al.AL_Tail()->DayMaxt(); // AL limit
	srand(t_current);
	if (superior) { // *** DIL entry specific AL
		EOUT << "dil2al: Actual dependency check for DIL entry specific AL not yet implemented in generate_AL()\n";
	}

	int i, cnt = 0;
	#define GENERATE_AL_DEPLOOP_CONTINUE prevde = dep[i]; continue

	// Create Cumulative Required Time HTML form
	if (alshowcumulativereq) {
	  VOUT << "Cumulative Required Time DEs:\n"; VOUT.flush();
#ifdef INCLUDE_DAY_SPECIFIC_WORK_TIMES
	  // [*** INCOMPLETE] The following is an approximation, not a correct accounting
	  // of time used by exact target dates and difference between work time available
	  // on different days of the week. For a better implementation, note that the
	  // AL is already created when this function is called, and that the exact
	  // target dates may be processed in advance in generate_AL to adjust available
	  // time during each day.
	  float alepshourscache = alepshours;
	  time_t wdtimediff, sumtime = 0;
	  time_t alepssec = ((time_t) rint(alepshours*60.0))*60;
	  for (int wdi=0; wdi<7; wdi++) {
	    wdtimediff = wdworkendprefs[wdi] - alworkdaystart;
	    if (wdtimediff>alepssec) sumtime += alepssec;
	    else sumtime += wdtimediff;
	  }
	  alepshours = ((float) sumtime) / (7.0*3600.0);
	  VOUT << "  Using approximate number of hours available for work per day " << alepshours << ".\n";
#endif
	  DIL_entry * prevde = NULL; // use prevde, since dep[i-1] can point to DIL entry that does not satisfy the conditionals below
	  for (i=0; ((i<deplen) && (ALCRT_continue_condition(dep[i],t_limit))); i++) if ((req[i]>0) && (dep[i]->Is_Dependency_Of(superior))) { // non-completed DIL entries
	    DIL_Topical_List * dtl = dep[i]->Topics(0);
	    time_t curtd = dep[i]->Target_Date();
	    if (grouptd>=0) { // if first row of form
	      if (curtd==grouptd) rowreqstr += HTML_put_table_cell("","@GROUPTREQ@")+HTML_put_table_cell("",HTML_put_form_checkbox(String("TDCHKBX")+prevde->chars(),"noupdate@GROUPCHECKED@","")+HTML_put_form_text(String("TD")+prevde->chars(),"@GROUPEPSTD@",12)); // if in same group, add @place holders@ to row
	      else { // if not in same group complete group data up to previous entry (prevde)
		generate_EPS_cells(grouptd,cumreqstr,rowreqstr,groupreq,cumreq,t_current,*prevde);
		groupnum++;
	      }
	      // *** optionally remove the following cell once T_{pref} is used
	      //     to determine preferable shifts
	      rowreqstr += entryexcerptcell;
	      cumreqstr += HTML_put_table_row("",rowreqstr)+'\n';
	    }
	    grouptd = curtd;
	    groupreq += (double) req[i];
	    cumreq += (double) req[i];
	    rowreqstr = HTML_put_table_cell("",String((long) groupnum))+
	      HTML_put_table_cell("",HTML_put_href((relidfile+'#')+dep[i]->chars(),"DIL#" + String(dep[i]->chars())))+
	      HTML_put_table_cell("",HTML_put_href((relurl(dstfile,dtl->dil.file)+'#')+dep[i]->chars(),dtl->dil.title)+" [<A HREF=\"file:///cgi-bin/dil2al?dil2al=MEI&DILID="+dep[i]->str()+"\">edit</A>]");
	    if (dep[i]->tdfixed()) rowreqstr += HTML_put_table_cell("","<B>"+time_stamp("%Y%m%d%H%M",curtd)+"</B>");
	    else rowreqstr += HTML_put_table_cell("",time_stamp("%Y%m%d%H%M",curtd));
	    rowreqstr += HTML_put_table_cell("",String((((double) req[i])*((double) timechunksize))/60.0,"%6.2f"))+
	      HTML_put_table_cell("",String((cumreq*((double) timechunksize))/60.0,"%6.2f"));
	    if (dep[i]->Entry_Text()) entryexcerptcell = (*dep[i]->Entry_Text());
	    else entryexcerptcell = "(Missing Text Content)";
	    HTML_remove_tags(entryexcerptcell);
	    Elipsis_At(entryexcerptcell,alcumtimereqexcerptlength);
	    entryexcerptcell = HTML_put_table_cell("",entryexcerptcell);
	    prevde = dep[i];
	  }
	  VOUT << "  Processed cumulative required time schedule suggestions for " << i << " of " << deplen << " DIL entries.\n";
	  if (i<deplen) if (dep[i]->Target_Date()>=t_limit) VOUT << "  (Target date " << time_stamp("%Y%m%d%H%M",dep[i]->Target_Date()) << " of the " << i << "th DIL entry exceeds AL time limit " << time_stamp("%Y%m%d%H%M",t_limit) << ".)\n";
#ifdef INCLUDE_DAY_SPECIFIC_WORK_TIMES
	  alepshours = alepshourscache;
#endif
	}

	// AL generation for DIL entries with exact target dates (task chunks immediately precede target date)
#ifdef INCLUDE_EXACT_TARGET_DATES
	VOUT << "Exact TD DEs:\n"; VOUT.flush();
	DIL_entry * prevde = NULL; // use prevde, since dep[i-1] can point to DIL entry that does not satisfy the conditionals below
	for (i=0; ((i<deplen) && (dep[i]->Target_Date()<t_limit)); i++) if ((req[i]>0) && (dep[i]->tdexact()) && (dep[i]->Is_Dependency_Of(superior))) { // non-completed exact target date DIL entries
	  //VOUT << '.' << i; VOUT.flush();
	  //if (dep[i]==NULL) { VOUT << "NULL"; VOUT.flush(); }
		if (dep[i]->Target_Date()<t_start) { // skip DIL entries with target date prior to current time
			// Note: addition to list of passed target date DIL entries is done in DE loop below
			if (verbose) {
			  VOUT << "dil2al: Warning - EXACT Target Date of DIL entry ";
			  if (calledbyforminput) VOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
			  VOUT << dep[i]->chars();
			  if (calledbyforminput) VOUT << "</A>";
			  VOUT << " precedes current time\n";
			}
			GENERATE_AL_DEPLOOP_CONTINUE;
		}
		al.Add_Target_Date(dep[i]); // add target date reference
		// Note: Expansion, if allowed, is done in the DE loop below.
		// ALLOCATION OF TASK CHUNKS TO TASK CHUNK TIME SLOTS
		// *** here, we should use a different allocation function in the al (let the days before the target date handle it)
		// *** warnings should also be different, namely not based on whether some task chunks are available, but whether a sufficient
		//     block of consecutive task chunks prior to the target date is available.
		req[i] = al.allocate_with_date(dep[i],req[i]);
		if (req[i]>0) {
		  VOUT << "Insufficient task chunks available exactly prior to " << time_stamp("%Y%m%d%H%M",dep[i]->Target_Date()) << " for DIL entry #";
		  if (calledbyforminput) VOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
		  VOUT << dep[i]->chars();
		  if (calledbyforminput) VOUT << "</A>";
		  VOUT << " (" << req[i] << " more required), distributing remainder\n";			  
		}
		prevde = dep[i];
		if (req[i]==0) cnt++; // otherwise, it will also be handled and counteed in the DE loop below
	}
#endif

	// AL generation for DIL entries with non-exact target dates (task chunks to be distributed)
	VOUT << "DEs:\n"; VOUT.flush();
	prevde = NULL; // use prevde, since dep[i-1] can point to DIL entry that does not satisfy the conditionals below
	for (i=0; ((i<deplen) && (dep[i]->Target_Date()<t_limit)); i++) if ((req[i]>0) && (dep[i]->Is_Dependency_Of(superior))) { // non-completed DIL entries
#ifdef DIAGNOSTIC_OUTPUT
		EOUT << dep[i]->chars() << " (" << req[i] << ") :\n";
#endif
		if (dep[i]->Target_Date()<t_start) { // skip DIL entries with target date prior to current time
			al.Add_Passed_Target_Date(dep[i]); // add to list of passed target date DIL entries
			VOUT << "dil2al: Warning - Target Date of DIL entry ";
			if (calledbyforminput) VOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
			VOUT << dep[i]->chars();
			if (calledbyforminput) VOUT << "</A>";
			VOUT << " precedes current time\n";
			GENERATE_AL_DEPLOOP_CONTINUE;
		}
		al.Add_Target_Date(dep[i]); // add target date reference
		// *** simplify the below by making member functions
		//     that do things like take req[i], automatically
		//     check if expansion is allowed, do the work, and
		//     return the remainder for req[i]
		long expandn = req[i] - al.available_before(dep[i]->Target_Date()); // also sets al.deavail
		if ((expandn>0) && (alautoexpand)) {
			VOUT << "Expanded for DIL entry #" << dep[i]->chars() << " (" << expandn << ")\n";
			if ((expandn -= al.expand(expandn,dep[i]->Target_Date()))!=0) {
				VOUT << "DIL entry #";
				if (calledbyforminput) VOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
				VOUT << dep[i]->chars();
				if (calledbyforminput) VOUT << "</A>";
				VOUT << " tasks cannot be completed before " << time_stamp("%Y%m%d%H%M",dep[i]->Target_Date()) << "(required: " << req[i] << ", available: " << al.deavail;
				if (calledbyforminput) VOUT << ", <A HREF=\"" << homedir << "doc/html/formalizer-doc.html#AL-update-strategies\">suggestions</A>";
				VOUT <<  ")\n";
			}
		}
		// *** currently only linear distribution function available
		// ALLOCATION OF TASK CHUNKS TO TASK CHUNK TIME SLOTS
		if ((sumval=al.set_TC_values())>0.0) {
			// randomly allocate TCs for this DIL entry
			while ((req[i]>0) && (al.deavail>0)) {
				uval = sumval*(((float) rand()) / ((float) RAND_MAX));
				uval = al.allocate_with_value(uval,dep[i]);
				if (uval>0.0) {
					sumval -= uval;
					req[i]--;
#ifdef DIAGNOSTIC_OUTPUT
					PLL_LOOP_FORWARD(AL_Day,al.AL_Head(),1) {
						EOUT << '|';
						if (e->TC_Head()) { 
							for (AL_TC * etc = e->TC_Head(); (etc); etc = etc->Next())
								if (etc->Get_DE()) EOUT << 'x'; else EOUT << '_';
						}
					}
					EOUT << '\n';
#endif
				}
			}
			if (req[i]>0) {
			  VOUT << "Not all task chunks of DIL entry #";
			  if (calledbyforminput) VOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
			  VOUT << dep[i]->chars();
			  if (calledbyforminput) VOUT << "</A>";
			  VOUT << " could be scheduled before target date " << time_stamp("%Y%m%d%H%M",dep[i]->Target_Date()) << " (required: " << req[i];
			  if (calledbyforminput) VOUT << " ,<A HREF=\"" << homedir << "doc/html/formalizer-doc.html#AL-update-strategies\">suggestions</A>";
			  VOUT << ")\n";			  
			}
		} else {
			if (sumval==0.0) {
			  VOUT << "No task chunks available for DIL entry #";
			  if (calledbyforminput) VOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
			  VOUT << dep[i]->chars();
			  if (calledbyforminput) VOUT << "</A>";
			  VOUT << " before target date " << time_stamp("%Y%m%d%H%M",dep[i]->Target_Date()) << " (required: " << req[i] << ", available: " << al.deavail;
			  if (calledbyforminput) VOUT << ", <A HREF=\"" << homedir << "doc/html/formalizer-doc.html#AL-update-strategies\">suggestions</A>";
			  VOUT <<  ")\n";
			} else {
			  EOUT << "dil2al: Negative sum of values for DIL entry #";
			  if (calledbyforminput) EOUT << "<A HREF=\"" << idfile << '#' << dep[i]->chars() << "\">";
			  EOUT << dep[i]->chars();
			  if (calledbyforminput) EOUT << "</A>";
			  EOUT << " in generate_AL(), continuing\n";
			}
		}
		prevde = dep[i];
		cnt++;
#ifdef DEBUG
		if ((i%10)==0) { VOUT << '>'; VOUT.flush(); }
#endif
	}

	// All AL generation iterations have been completed.
	VOUT << "Scheduled DIL entries with target date in requested range: " << cnt << '\n';
	if (alshowcumulativereq) { // cumulative required time file tail
		String cumreqtail(DEFAULTALCUMULATIVEREQTAIL);
		cumreqtail.gsub("@SUP@",al.get_supstr());
		cumreqtail.gsub("@ALFILE@",al.filestr());
		cumreqtail.gsub("@ALDATE@",time_stamp("%c"));
		generate_EPS_cells(grouptd,cumreqstr,rowreqstr,groupreq,cumreq,t_current,*prevde); // final call to complete grouop data for all entries
		rowreqstr += entryexcerptcell;
		cumreqstr += HTML_put_table_row("",rowreqstr)+'\n' + cumreqtail;
		write_file_from_String(dstfile,cumreqstr,"AL Cumulative Time Required");
	}
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "*\n";
#endif
	// randomly pick tasks that could not be allocated entirely before their target dates
	// *** TESTING WITHOUT THIS LINE! AL_TC * atc = al.Get_Avail_TC(0);
	VOUT << "dil2al ALPHA TEST Warning: Testing without al.Get_Avail_TC(0) line in generate_AL()\n";
	int j, k = 1; cnt = 0;
	while (k>=0) {
		// random DIL entry
		j = (int) (((float) i)*((float) rand()) / ((float) RAND_MAX));
		if (j>=i) j=i-1;
		if (j<0) break; // i==0
		// find nearest DIL entry requiring task chunks
		// Note: current order of search gives partially
		// allocated DIL entries priority over DIL entries
		// with target dates prior to current time
		for (k = j; ((k<i) && (req[k]<=0)); k++);
		if (k>=i) for (k = (j-1); ((k>=0) && (req[k]<=0)); k--);
		// allocate earliest available task chunk in AL
		if (k>=0) {
			if (al.allocate(dep[k])) {
				req[k]--;
#ifdef DIAGNOSTIC_OUTPUT
				PLL_LOOP_FORWARD(AL_Day,al.AL_Head(),1) {
					EOUT << '|';
					if (e->TC_Head()) { 
						for (AL_TC * etc = e->TC_Head(); (etc); etc = etc->Next())
							if (etc->Get_DE()) EOUT << 'x'; else EOUT << '_';
					}
				}
				EOUT << '\n';
#endif
			} else break;
		}
#ifdef DEBUG
		if ((cnt%10)==0) { VOUT << '+'; VOUT.flush(); }
#endif
		cnt++;
	}
	VOUT << "Scheduled task chunks beyond their intended target dates: " << cnt << '\n';
#ifdef DIAGNOSTIC_OUTPUT
	EOUT << "*\n";
#endif
	// randomly pick tasks that have target dates exceeding the AL interval
	int remlen = deplen - i;
	k = 0; cnt = 0;
	while (k<deplen) {
		// random DIL entry
		j = (int) (((float) remlen)*((float) rand()) / ((float) RAND_MAX));
		if (j>=remlen) j=remlen-1;
		if (j<0) break;
		j += i;
		// find nearest DIL entry requiring task chunks
		for (k = j; ((k>=i) && (req[k]<=0)); k--);
		if (k<i) for (k = (j+1); ((k<deplen) && (req[k]<=0)); k++);
		// allocate earliest available task chunk in AL
		if (k<deplen) {
			if (al.allocate(dep[k])) {
				req[k]--;
#ifdef DIAGNOSTIC_OUTPUT
				PLL_LOOP_FORWARD(AL_Day,al.AL_Head(),1) {
					EOUT << '|';
					if (e->TC_Head()) { 
						for (AL_TC * etc = e->TC_Head(); (etc); etc = etc->Next())
							if (etc->Get_DE()) EOUT << 'x'; else EOUT << '_';
					}
				}
				EOUT << '\n';
#endif
			} else break;
		}
#ifdef DEBUG
		if ((cnt%10)==0) { VOUT << '"'; VOUT.flush(); }
#endif
	}
	VOUT << "Scheduled tasks for DIL entries with target dates beyond requested range: " << cnt << '\n';
	// clean up by removing unused TCs
#ifdef DIAGNOSTIC_OUTPUT
	PLL_LOOP_FORWARD(AL_Day,al.AL_Head(),1) for (AL_TC * etc = e->TC_Head(); (etc); etc=etc->Next()) if (!etc->Get_DE()) cerr << '?'; cerr << '\n';
#endif
	al.remove_unused_TCs();
	// create visible AL
	if (!al.generate_focused_AL(superior,algenhpd)) LOCAL_CLEAN_EXIT
	if (!al.generate_wide_AL(superior)) LOCAL_CLEAN_EXIT
	// update DIL, AL, TL main page
	if (!update_main_ALs(superior)) LOCAL_CLEAN_EXIT
	// clean up
	delete[] req;
	return true;
}

int get_AL_entry(String & alstr, int alpos, String & rowcontent, int & rowstart, int & rowend) {
// gets an entry from an AL table and returns whether that row
// is a Day (0) or a TC (1), returns -1 if row cannot be obtained
	String params, cellcontent;
	if ((rowend=HTML_get_table_row(alstr,alpos,params,rowcontent,&rowstart))<0) return -1;
	if (HTML_get_table_cell(rowcontent,0,params,cellcontent)<0) return -1;
	if (cellcontent.contains(BigRegex("[<]!--[ 	]+@select_TL_DIL_refs:[ 	]+SKIP ROW@[ 	]+--[>][^(]*Day"))) return 0;
	return 1;
}

bool remove_AL_TC(String alref, String dilid) {
// removes the top task chunk if it has DIL entry ID dilid
// from the AL indicated by alref and updates the suggested
// start time of that AL day according to the assumed time
// taken to do the task chunk (desynchronization is noticed
// and taken care of in select_TL_DIL_refs())
// day rows at the top of the AL that are not followed by task
// rows are removed
// returns false if dilid did not match the DIL entry ID of
// the top task chunk, or if the visible focused AL became
// empty
	String alstr, newalstr;
	if (!read_file_into_String(alref,alstr)) return false;
	newalstr.alloc(alstr.length());
	// get day row and remove empty days at top of AL
	// and find top TC to compare with dilid
	StringList alentries; int numentries = 0, alpos = 0, tcsfound = 0, tcentries[2], rowstart, rowend;
	while (tcsfound<2) {
		switch (get_AL_entry(alstr,alpos,alentries[numentries],rowstart,rowend)) {
			case -1:
				// *** could detect from numentries and tcsfound
				//     to give a different VOUT message if the
				//     visible AL portion contained no more TCs
				EOUT << "Missing data in AL " << alref << " after position " << alpos << " in remove_AL_TC()";
				return false;
				break;
			case 0: break;
			case 1:
				if (numentries==0) {
					EOUT << "TC without preceding Day ID in " << alref << " after position " << alpos << " in remove_AL_TC()";
					return false;
				}
				if (tcsfound==0) {
					String alhrefurl, alhreftext;
					if (HTML_get_href(alentries[numentries],0,alhrefurl,alhreftext)<0) {
						EOUT << "Missing DIL ID reference in " << alref << " after position " << alpos << " in remove_AL_TC()";
						return false;
					}
					if (alhreftext!=dilid) { // different task
						VOUT << "Top of AL " << alref << " does not match DIL entry " << dilid << '\n';
						return false;
					}
				}
				tcentries[tcsfound] = numentries;
				tcsfound++;
				break;
		}
		if (alpos==0) newalstr = alstr.at(0,rowstart); // copy head of AL
		numentries++; alpos = rowend;
	}
	if (tcentries[1]==(tcentries[0]+1)) { // next TC on same day, modify daystart
		BigRegex rds("(suggested start[ 	]+\\([0-9][0-9]:[0-9][0-9]\\)");
		int didx = tcentries[0]-1, dstimepos;
		if ((dstimepos=alentries[didx].index(rds))<0) {
			EOUT << "Missing suggested start in AL " << alref << " at row " << didx << " in remove_AL_TC()\n";
			return false;
		}
		String daystartstr = alentries[didx].at(rds.subpos(1),rds.sublen(1));
		daystartstr.del(':');
		time_t tds = time_stamp_time_of_day(daystartstr) + ((time_t) (timechunksize*60));
		if (tds>=SECONDSPERDAY) {
			VOUT << "Updated suggested start time exceeds length of day, limiting to 23:59\n";
			tds = SECONDSPERDAY-1;
		}
		daystartstr = time_stamp_GM("%H:%M",tds);
		for (int i = 0; i<5; i++) alentries[didx][rds.subpos(1)+i] = daystartstr[i];
	}
	// determine day before second TC and write it
	int didx = tcentries[1]-1;
	if (didx==tcentries[0]) didx--;
	newalstr += HTML_put_table_row(DEFAULTALDAYEMPHASIS,alentries[didx]) + '\n';
	// write second TC with top TC colors
	newalstr += HTML_put_table_row(DEFAULTALFOCUSEDEMPHASIS,alentries[tcentries[1]]) + '\n';
	// copy remainder of AL
	newalstr += alstr.at(alpos,alstr.length()-alpos);
	return write_file_from_String(alref,newalstr,"AL");
}

bool update_DIL_to_AL() {
// generate an updated AL from the DIL hierarchy
// uses generatealmaxt and generatealtcs
	/*
	When computing priorities, also parse for ALs and refresh AL parameters
	for all detail items if prefixed with E (``automatic estimate'').
	*/
	// *** can make this first part prepare in the background
	//     before a TC is completed
	Detailed_Items_List dilist;
	DIL_entry ** dep = dilist.Sort_by_Target_Date(true);
#ifdef DEBUG
	if (dep) {
		int entrynum = dep[0]->fulllength();
		for (int i = 0; i<entrynum; i++) cerr << dep[i]->chars() << '\n';
	}
#endif
	if (!generate_AL(dep)) {
		delete[] dep;
		return false;
	}
	delete[] dep; // may not be necessary here
	return true;
}

bool refresh_quick_load_cache() {
  if (!usequickloadcache) {
    EOUT << "dil2al: The usequickloadcache flag is not set in refresh_quick_load_cache()\n";
    return false;
  }
  Detailed_Items_List dilist;
  if (dilist.Get_All_DIL_ID_File_Parameters()<0) return false;
  if (dilist.Get_All_Topical_DIL_Parameters(true)<0) return false;
  return true;
}
