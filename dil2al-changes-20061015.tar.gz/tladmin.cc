// tladmin.cc
// Randal A. Koene, 20000304

#include "dil2al.hh"

String get_TL_head() {
// resolves the TL symbolic link to the TL head file
	if (taskloghead!="") return taskloghead;
	const int LLEN = 10240;
	char lbuf[LLEN];
	int res;
	if ((res=readlink(tasklog,lbuf,LLEN))<0) {
		EOUT << "dil2al: Unable to read Task Log symbolic link\n" << tasklog << " in get_TL_head()\n";
		return String("");
	} else {
		lbuf[res]='\0';
		if (lbuf[0]=='/') taskloghead=lbuf;
		else {
			taskloghead = tasklog;
			taskloghead.gsub(BigRegex("[^/]*$"),"");
			taskloghead += lbuf;
		}
		if (verbose) VOUT << "Task Log symbolic link resolved to " << taskloghead << '\n';
		return taskloghead;
	}
}

int max_chunk_entry(String & tlchunk) {
// searches for the largest entry number in a Task Log chunk
// returns 0 if there are no entries
// note that this works even if the entries are not in order or entry numbers are missing
#ifdef DEBUG
	cout << "TLCHUNK:\n" << tlchunk << '\n';
#endif
	int maxentry = 0, entryindex = -1;
	while ((entryindex = tlchunk.index(BigRegex("[<]!--[ 	]*entry Begin[ 	]*--[>]"),entryindex+1))>=0) {
		String entryid = tlchunk.before(BigRegex("[ 	]*[<]/B[>]"),entryindex);
		entryid = entryid.after("<B>",-1);
		int entryidnum = 0;
		if (entryid.matches(BRXint)) entryidnum = atoi((const char *) entryid);
#ifdef DEBUG
		cout << "entryid = " << entryid << "\nentryidnum = " << entryidnum << '\n';
#endif
		if (entryidnum>maxentry) maxentry = entryidnum;
	}
#ifdef DEBUG
	cout << "maxentry = " << maxentry << '\n';
#endif
	return maxentry;
}

String generate_TL_chunk_header(String nametag, String newalref, String altitle, String alhead, String newdilref, String diltitle, String dilhead, int generateparts) {
// generatparts = 0 both parts, -1 begin part, 1 end part
#ifdef DEBUG
	cout << "Generating TL chunk header with tag = " << nametag << ", AL = " << newalref << ", DIL entry = " << newdilref << '\n';
#endif
	String chunkheader;
	if (generateparts<=0) {
		chunkheader = "<!-- chunk Begin --><TR><TD><FONT COLOR=\"#FFFFFF\"><A NAME=\""+nametag+"\"><B>"+nametag+"</B></A>\n<!-- chunk AL --><A HREF=\""+newalref+"\">"+altitle+"</A> (";
		if (alhead!="") chunkheader += "<A HREF=\""+alhead+"\">previous</A>/next)\n<!-- chunk Context -->";
		else chunkheader += "previous/next)\n<!-- chunk Context -->";
		if (newdilref[0]=='!') chunkheader += newdilref.after("!")+" (";
		else chunkheader += "<A HREF=\""+newdilref+"\">"+diltitle+" "+newdilref.after("#")+"</A> (";
		if (dilhead!="") chunkheader +=  "<A HREF=\""+dilhead+"\">previous</A>/next)</FONT>\n<P>\n\n";
		else chunkheader += "previous/next)</FONT>\n<P>\n\n";
	}
	if (generateparts>=0) {
		chunkheader += "<!-- chunk End --></TD></TR>\n\n";
	}
	return chunkheader;		
}

String generate_TL_entry_header(String nametag, String newalref, String altitle, String alhead, String newdilref, String diltitle, String dilhead) {
	String entryheader;
	entryheader = "<!-- entry Begin --><FONT COLOR=\"#FFFFFF\">[<A NAME=\""+nametag+"\"><B>"+nametag.after(".")+"</B></A>";
	if ((newalref[0]!='*') || (newdilref[0]!='*')) {
		entryheader += " -\n<!-- entry AL -->";
		if (newalref[0]!='*') {
			entryheader += "<A HREF=\""+newalref+"\">"+altitle+"</A> (";
			if (alhead!="") entryheader += "<A HREF=\""+alhead+"\">previous</A>/next)\n<!-- entry Context -->";
			else entryheader += "previous/next)\n<!-- entry Context -->";
		} else entryheader += "\n<!-- entry Context -->";
		if (newdilref[0]!='*') {
			if (newdilref[0]=='!') entryheader += newdilref.after("!")+" (";
			else entryheader += "<A HREF=\""+newdilref+"\">"+diltitle+" "+newdilref.after("#")+"</A> (";
			if (dilhead!="") entryheader +=  "<A HREF=\""+dilhead+"\">previous</A>/next)]</FONT>\n<BR>\n";
			else entryheader += "previous/next)]</FONT>\n<BR>\n";
		} else entryheader += "]</FONT>\n<BR>\n";
	} else entryheader += "]</FONT>\n"; //*** add "<BR>\n" here?
	return entryheader;
}

// Don't worry if some of these things aren't optimal yet, they can always be
// improved with experience from use.

String get_most_recent_TC_AL(String & tl) {
// returns the AL reference of the most recent task chunk
	String curAL;
	curAL = tl.at(BigRegex("[<]!-- chunk AL [^(]*"),-1);
	curAL.del(BigRegex("[<]!-- chunk AL -->[^\"]*\""));
	curAL.del(BigRegex("\".*"));
	curAL.prepend(basedir+RELLISTSDIR);
	return curAL;
}

String get_most_recent_TC_DE(String & tl) {
// returns the DIL entry reference of the most recent task chunk
	String curDE;
	curDE = tl.at(BigRegex("[<]!-- chunk Context --[>][^\n][^(]*("),-1);
	curDE.del(BigRegex("[<]!-- chunk Context --[>]"));
	curDE.del(BigRegex("[<]A [^>]*[Hh][Rr][Ee][Ff][ 	]*=[^\"]*\""));
	curDE.gsub("\">",":");
	curDE.del(BigRegex("\\([<][^>]*[>]\\)?[ 	]*("));
	return curDE;
}

void stop_TL_chunk(String & tl) {
// Mark the completion time of a Task Log chunk if there is one open
// AL options determine if and how the current AL and closed chunk's
// DIL entry should be updated, and the corresponding update is done.
	if (tl.gsub(BigRegex("[<]!--[ 	]+chunk End[ 	]+--[>][ 	]*[<]/TD[>][ 	]*[<]/TR[>]"),"<!-- chunk End --><I>"+curtime+"</I></TD></TR>")<=0) return;
	// determine if AL anc completion ratios should be updated automatically
	if (alautoupdate==AAU_NO) return;
	if (alautoupdate==AAU_ASK) if (confirmation("Update AL and completion ratios? (y/N) ",'y')) return;
	// obtain AL and DIL information from the most recent chunk
	String chunkid; int lasttlchunk;
	if ((lasttlchunk = locate_most_recent_TL_chunk(tl,-1,&chunkid))>=0) {
		bool recomputeAL = false;
		String curAL = get_most_recent_TC_AL(tl);
		String curDE = get_most_recent_TC_DE(tl);
		// a proper DIL entry ID is returned in the form:
		// some-DIL-file.html#XXXXXXXXXXXXXX.Y:DIL-title-and-entry-ID
		curDE = curDE.before(':'); curDE = curDE.after('#');
		if (curDE.matches(BRXdouble)) {
			time_t tdiff = time_stamp_diff(chunkid,curtime);
// *** suggest tdiff, but allow entry of other time, in which
//     case request if required time and completion status should
//     be modified directly
// *** if tdiff > taskchunksize*1.25 recompute AL... this test
//     may not be necessary, since any significant delay will
//     cause desynchronization between the updated suggested
//     start time in the AL and the current time, which causes
//     recomputation of the AL when a significant difference is
//     detected in select_TL_DIL_refs()
			if (!update_DIL_entry_elements(curDE,0.0,false,0.0,true,0.0,false,tdiff)) recomputeAL = true;
			if (!remove_AL_TC(curAL,curDE)) recomputeAL = true;
		} else {
			VOUT << "Completed task chunk was not a DIL entry\n";
			recomputeAL = true;
		}
		if (recomputeAL) { // recompute the AL
			VOUT << "Recomputing AL\n";
			Detailed_Items_List dilist;
			DIL_entry ** dep = dilist.Sort_by_Target_Date(true);
			if (!generate_AL(dep)) EOUT << "dil2al: Unable to generate AL in stop_TL_chunk(), continuing as is\n";
			delete[] dep;
		}
	} else EOUT << "dil2al: Unable to update AL and DIL entry in stop_TL_chunk(), continuing\n";
}

String select_TL_DIL_refs(String & tl, bool newchunk, String newalref) {
// select DIL reference for new TL chunk or entry
// tl should provide a pointer to a String containing
// the most recent section of the Task Log
// newchunk indicates if a new chunk or a new entry is being prepared
// if newalref is not "" then use it as AL for default/quick choices
// return value "*<DIL-ref>"=same as chunk, "!<DIL-ref>"=non-DIL identifying
// comment, "*"=decision postponed (see variableAL), ""=error
// when newchunk=true the default is the highest priority item in the current AL
// when newchunk=true the default is the same as that of the current chunk
	const int LLEN = 10240;
	char lbuf[LLEN];
	StringList diloptions;
	int numdiloptions = 0;
	String curAL;
	if (newalref=="") curAL = get_most_recent_TC_AL(tl); // obtain current AL from TL
	else {
		if (newalref[0]=='*') newalref.del("*");
		curAL = basedir+RELLISTSDIR+newalref;
	}
	// obtain default DIL ref for TL entry
	if (!newchunk) { // chunk DIL ref (or identifying comment) is default
		diloptions[0] = get_most_recent_TC_DE(tl);
		if (diloptions[0]=="") {
			EOUT << "dil2al: Entry is not in a Task Log chunk in select_TL_DIL_refs()\n";
			return String("");
		}
		numdiloptions++;
	}
	// recompute the AL if the suggested start time for the next
	// TC is significantly earlier than the current time
	String curALstr;
	if (read_file_into_String(curAL,curALstr)) {
		String tmpstr, cellcontent;
		HTML_get_table_cell(curALstr,0,tmpstr,cellcontent);
		HTML_remove_tags(cellcontent);
		BigRegex alr("Day[ 	]+\\([0-9]+\\).*suggested[ 	]+start[ 	]+\\([0-9][0-9]\\):\\([0-9][0-9]\\)");
		if (cellcontent.index(alr)==0) {
			// get suggested start time for next TC
			tmpstr = cellcontent.at(alr.subpos(1),alr.sublen(1))+cellcontent.at(alr.subpos(2),alr.sublen(2))+cellcontent.at(alr.subpos(3),alr.sublen(3));
			time_t tdiff = time_stamp_diff(tmpstr,curtime); // positive if curtime is later than suggested time
			if (tdiff>alsyncslack) { // recompute the AL
				// determine if AL updating should be automatic
				// *** Note: A separate configuration variable should be used if alautoupdate
				//     should apply only to the recomputation of the AL in stop_TL_chunk()
				//     above.
				switch (alautoupdate) {
					case AAU_NO:
						if (verbose) VOUT << "Warning: AL desynchronized, no automatic recomputation (alautoupdate==AAU_NO)\n";
						break;
					case AAU_ASK:
						if (confirmation("AL desynchronized, update now? (y/N) ",'y')) break;
					default:
						VOUT << "Recomputing AL\n";
						Detailed_Items_List dilist;
						DIL_entry ** dep = dilist.Sort_by_Target_Date(true);
						// *** make this able to request generation of an AL
						//     corresponding to the superior that generated curAL
						if (!generate_AL(dep)) EOUT << "dil2al: Unable to generate AL in select_TL_DIL_refs(), continuing as is\n";
						else { // get new version of AL
							curALstr = "";
							read_file_into_String(curAL,curALstr);
						}
						delete[] dep;
				}
			}
			// *** it is possible to add a message here if curtime is a lot
			//     smaller than the suggested start time of the AL, e.g.
			//     if all suggested TCs for this AL day have been completed
		} else EOUT << "Day row missing at top of AL " << curAL << " in select_TL_DIL_refs(), continuing as is\n";
	}
	// some options from high priority current AL items
	if (curALstr.length()>0) {
		int cellindex = 0; String cellparameters, cellcontent;
		while ((numdiloptions<6) && ((cellindex=HTML_get_table_cell(curALstr,cellindex,cellparameters,cellcontent))>=0))
			if (!cellcontent.contains(BigRegex("[<]!--[ 	]+@select_TL_DIL_refs:[ 	]+SKIP ROW@[ 	]+--[>]"))) { // skip marked rows
				diloptions[numdiloptions]=cellcontent;
				String idhreftext;
				if (HTML_get_href(cellcontent,0,cellparameters,idhreftext)>=0) {
					// only unique DIL options
					for (int i=0; i<numdiloptions; i++) if (diloptions[i].contains(idhreftext)) { cellparameters=""; break; }
					if (cellparameters.length()>0) {
						diloptions[numdiloptions]=cellparameters+':'+cellcontent.after(BigRegex("[]]\n?"));
						HTML_remove_tags(diloptions[numdiloptions]);
						remove_whitespace(diloptions[numdiloptions]);
						if (diloptions[numdiloptions]!="") numdiloptions++;
					}
				} else EOUT << "Missing DIL entry reference in AL " << curAL << " in select_TL_DIL_refs(), continuing\n";
			}
	}
	// some options from recent DIL refs in TL
	BigRegex r("[<]!-- \\(chunk\\|entry\\) Context --[>]\\([^\n][^(]*\\)(");
	int pos = tl.length(), matchlen;
	while (((pos = r.search(tl,pos-1,matchlen,-1))>=0) && (numdiloptions<10)) {
#ifdef VERBOSEDEBUG
		cout << "Context...\n";
#endif
		int subpos;
		if (r.match_info(subpos,matchlen,2)) {
			diloptions[numdiloptions] = tl.at(subpos,matchlen);
#ifdef VERBOSEDEBUG
			cout << "Candidate Context from TL: " << diloptions[numdiloptions] << '\n';
#endif
			String idhrefname = diloptions[numdiloptions].at(BigRegex("#[0-9]+[.][0-9]+"));
			// only unique DIL options
			for (int i=0; i<numdiloptions; i++) if (diloptions[i].contains(idhrefname)) { idhrefname=""; break; }
			if (idhrefname!="") {
				diloptions[numdiloptions].del(BigRegex("[<]A [^>]*[Hh][Rr][Ee][Ff][ 	]*=[^\"]*\""));
				diloptions[numdiloptions].gsub("\">",":");
				diloptions[numdiloptions].del(BigRegex("\\([<][^>]*[>]\\)?[ 	]*("));
				if (diloptions[numdiloptions]!="") numdiloptions++;
			}
		}
	}
	// can enter DIL ids directly, or quick-chooser choice from priority list, or textual comment instead of DIL
	if (askALDILref) {
		String affiliation = "", bufstr;
		while (affiliation=="") {
			if (useansi) cout << ANSI_UNDERLINE_ON; // underline on
			if (newchunk) cout << "\nChunk "; else cout << "\nEntry ";
			cout << "DIL reference ID or identifying comment (DIL references generally\npreferred) can include HREFs\n";
			if (useansi) cout << ANSI_UNDERLINE_OFF; // underline off
			for (int i=1; i<numdiloptions; i++) cout << i << ". " << diloptions[i] << '\n';
			if (useansi) cout << ANSI_BOLD_ON; // bold on
			cout << "\"\"=" << diloptions[0] << " DEFAULT (\"d\"),\n\"\"/\"?\"=browse (can import from ~/tmp/dilref, ESC SHIFT+M 3),\n\"?&\"=fork browser, \"*\"=postpone and get new Active List\n(current AL = "
				<< curAL.after(basedir+RELLISTSDIR) << "): ";
			if (useansi) cout << ANSI_BOLD_OFF; // bold off
			cin.getline(lbuf,LLEN);
			bufstr = lbuf;
			//			if (lbuf[0]!='\0') {
			if (downcase(bufstr) != "d") {
				affiliation = lbuf;
				if (affiliation.matches(BRXint)) { // quick-select menu item
					int q = atoi((const char *) affiliation);
					if ((q>0) && (q<numdiloptions)) affiliation = diloptions[q].before(":");
					else {
						EOUT << "dil2al: Selection " << q << " is not a predefined DIL reference option\n";
						affiliation = "";
					}
				} else if (affiliation.matches(BRXdouble)) { // DIL ID
					ifstream dbid(idfile);
					if (!dbid) {
						EOUT << "dil2al: Unable to read " << idfile << " in select_TL_DIL_ref()\n";
						return String("");
					}
					affiliation.prepend("#");
#ifdef DEBUG
					cout << "seeking " << affiliation << '\n';
#endif
					if (find_line(&dbid,affiliation,lbuf,LLEN)) {
						affiliation = lbuf;
						affiliation.del(BigRegex("[^<]*[<]TD[^>]*[>][<]A[^>]*[Hh][Rr][Ee][Ff]=\""));
						affiliation = affiliation.before("\"");
#ifdef DEBUG
					cout << "exists: " << affiliation << '\n';
#endif
					} else {
						EOUT << "dil2al: DIL reference " << affiliation << " not found in " << idfile << '\n';
						affiliation = "";
					}
					dbid.close();
				} else if (affiliation.empty() || (affiliation=="?")) {
					if (System_Call(browser+" "+curAL)<0) EOUT << "dil2al: Unable to browse in select_TL_DIL_refs(), continuing\n";
					affiliation = "";
					ifstream drf(dilref);
					if (drf) {
						if (find_line(&drf,"Current URL",lbuf,LLEN)) {
							String urlline = lbuf;
							drf.getline(lbuf,LLEN);
							if (lbuf[0]==' ') urlline += lbuf;
							urlline.del("Current URL");
							urlline.del("file://");
							urlline.gsub(" ","");
							urlline.del(basedir+RELLISTSDIR);
							if (useansi) cout << ANSI_BOLD_ON; // bold on
							cout << "Take `" << urlline << "' as DIL reference ID or identifying comment? (y/N)";
							if (useansi) cout << ANSI_BOLD_OFF; // bold off
							cin.getline(lbuf,LLEN);
							if ((lbuf[0]=='y') || (lbuf[0]=='Y')) affiliation=urlline;
						}
						drf.close();
						unlink(dilref);
					}
				} else if (affiliation=="?&") {
					if (System_Call("rxvt -e "+browser+" "+curAL+" &")<0) EOUT << "dil2al: Unable to spawn a browser in select_TL_DIL_refs(), continuing\n";
					affiliation = "";
				} else if (affiliation!="*") affiliation.prepend("!"); // else non-DIL identifying comment
			} else {
				affiliation=diloptions[0].before(":");
				if (!newchunk) affiliation.prepend("*"); // same as chunk DIL (no entry specific reference required)
			}
		}
		return affiliation;
	} else {
		diloptions[0]=diloptions[0].before(":");
		if (!newchunk) diloptions[0].prepend("*");
		return diloptions[0];
	}
}

String select_TL_AL_refs(String & tl, bool newchunk, String newdilref) {
// select AL reference for new TL chunk or entry
// tl should provide a pointer to a String containing
// the most recent section of the Task Log
// newchunk indicates if a new chunk or a new entry is being prepared
// if newdilref=="*" then possibly choose a new AL
// return value "*<AL-ref>"=same as chunk, ""=error
// default is current AL
	const int LLEN = 10240;
	char lbuf[LLEN];
	StringList aloptions;
	int numaloptions = 0;
	// AL should default either to current, or to that associated with DIL
	// alternatives can be read from list.html
	// obtain current AL from TL
	String curAL = get_most_recent_TC_AL(tl);
//*** could insure that if newdilref!="*" the default
//*** Active List returned is curAL if the DIL is in it,
//*** otherwise the primary one the DIL in newdilref is in
	if ((askALDILref) && (newdilref=="*")) {
		// some options from listfile
		ifstream alf(listfile);
		if (!alf) EOUT << "dil2al: Unable to read " << listfile << " in select_TL_AL_refs(), continuing\n";
		else {
			if (find_line(&alf,"[<]A[ 	][^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\"AL\"",lbuf,LLEN)) {
				String alid[2];
				while (find_in_line(&alf,"[<]LI[>][<]A[ 	][^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\"(.+)[<][/]A[>]",2,alid,"[<][/]UL[>]",lbuf,LLEN)==1) {
					alid[1].gsub("\">",":");
					alid[1].del(RELLISTSDIR);
					if (!curAL.contains(alid[1].before(":"))) {
						aloptions[numaloptions] = alid[1];
						numaloptions++;
					}
				}
			} else EOUT << "dil2al: No AL references in " << listfile << " in select_TL_AL_refs(), continuing\n";
			alf.close();
		}
		// can enter AL ids directly, or quick-chooser choice from priority list
		String affiliation = "";
		while (affiliation=="") {
			if (useansi) cout << ANSI_UNDERLINE_ON; // underline on
			if (newchunk) cout << "\nChunk "; else cout << "\nEntry ";
			cout << "AL reference ID\n";
			if (useansi) cout << ANSI_UNDERLINE_OFF; // underline off
			for (int i=0; i<numaloptions; i++) cout << i << ". " << aloptions[i] << '\n';
			if (useansi) cout << ANSI_BOLD_ON; // bold on
			cout << "\"\"=" << curAL.after(basedir+RELLISTSDIR) << " DEFAULT,\n\"?\"=browse (e.g. use S to save file info to ~/tmp/dilref for dil2al),\n\"?&\"=fork browser: ";
			if (useansi) cout << ANSI_BOLD_OFF; // bold off
			cin.getline(lbuf,LLEN);
			if (lbuf[0]!='\0') {
				affiliation = lbuf;
				if (affiliation.matches(BRXint)) { // quick-select menu item
					int q = atoi((const char *) affiliation);
					if ((q>=0) && (q<numaloptions)) affiliation = aloptions[q].before(":");
					else {
						EOUT << "dil2al: Selection " << q << " is not a predefined AL reference option\n";
						affiliation = "";
					}
				} else if (affiliation=="?") {
					if (System_Call(browser+" "+listfile)<0) EOUT << "dil2al: Unable to browse in select_TL_AL_refs(), continuing\n";
					affiliation = "";
					ifstream drf(dilref);
					if (drf) {
						if (find_line(&drf,"Current URL",lbuf,LLEN)) {
							String urlline = lbuf;
							drf.getline(lbuf,LLEN);
							if (lbuf[0]==' ') urlline += lbuf;
							urlline.del("Current URL");
							urlline.del("file://");
							urlline.gsub(" ","");
							urlline.del(basedir+RELLISTSDIR);
							if (useansi) cout << ANSI_BOLD_ON; // bold on
							cout << "Take `" << urlline << "' as AL reference ID? (y/N)";
							if (useansi) cout << ANSI_BOLD_OFF; // bold off
							cin.getline(lbuf,LLEN);
							if ((lbuf[0]=='y') || (lbuf[0]=='Y')) affiliation = urlline;
						}
						drf.close();
						unlink(dilref);
					}
				} else if (affiliation=="?&") {
					if (System_Call("rxvt -e "+browser+" "+curAL+" &")<0) EOUT << "dil2al: Unable to spawn a browser in select_TL_AL_refs(), continuing\n";
					affiliation = "";
				} else { // verify that string is AL ID
					alf.open(listfile);
					if (!alf) {
						EOUT << "dil2al: Unable to read " << listfile << " in select_TL_AL_ref()\n";
						return String("");
					}
#ifdef DEBUG
					cout << "seeking " << affiliation << '\n';
#endif
					if (find_line(&alf,"[<]A[ 	][^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\"AL\"",lbuf,LLEN)) {
						affiliation.prepend(RELLISTSDIR);
						affiliation.prepend("[<]LI[>][<]A[ 	][^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\"");
						if (find_line(&alf,affiliation,lbuf,LLEN)) {
							affiliation = lbuf;
							affiliation = affiliation.after(BigRegex("[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\""));
							affiliation = affiliation.after(RELLISTSDIR);
							affiliation = affiliation.before("\">");
#ifdef DEBUG
							cout << "exists: " << affiliation << '\n';
#endif
						} else {
							EOUT << "dil2al: AL reference " << affiliation << " not found in " << listfile << '\n';
							affiliation = "";
						}
					} else {
						EOUT << "dil2al: No AL references found in " << listfile << " in select_TL_AL_ref()\n";
						return String("");
					}
					alf.close();
				}
			} else {
				affiliation = curAL.after(basedir+RELLISTSDIR);
				if (!newchunk) affiliation.prepend("*"); // same as chunk AL (no entry specific reference required)
			}
		}
		return affiliation;
	} else {
		curAL = curAL.after(basedir+RELLISTSDIR);
		if (!newchunk) curAL.prepend("*");
		return curAL;
	}
}

String add_TL_chunk_or_entry(String & tl, String & notestr, bool newchunk, String chunkid, int  & tlinsertloc) {
// Add a new chunk or a new entry to the Task Log
// tlinsertloc is used when adding an entry, while it
// is set here when adding a chunk
	String nametag;
	int chunkendindex = -1; // used to find NAME tag and for entry insertion
	if (!newchunk) {
		// determine entry NAME tag
		nametag = chunkid;
		chunkendindex = tl.index(BigRegex("[<]!--[ 	]*chunk End[ 	]*--[>]"),tlinsertloc);
		if (chunkendindex>=0) {
			String tlchunk = tl.at(tlinsertloc,chunkendindex-tlinsertloc);
			nametag = nametag + "." + String((long) max_chunk_entry(tlchunk)+1);
		} else {
			EOUT << "dil2al: Unable to find Task Log chunk end in add_TL_chunk_or_entry()\n";
			return String("");
		}
	} else {
		nametag = curtime; // new NAME tag for new chunk
		// if a current chunk is active, mark its completion time
		stop_TL_chunk(tl); // can close previous task chunk and update AL and completion ratios
	}
#ifdef DEBUGTIER1
	cout << "chunkid nametag: " << nametag << '\n';
#endif
	// obtain DIL reference ID or identifying comment and AL reference ID
	String newdilref,newalref,alhead,dilhead,altitle,diltitle;
#ifdef DEBUGTIER1
	cout << '+';
#endif
	while ((newdilref=="*") || (newdilref=="")) {
#ifdef DEBUGTIER1
		cout << 'x';
#endif
		if ((newdilref=select_TL_DIL_refs(tl,newchunk,newalref))=="") return String("");
#ifdef DEBUGTIER1
		cout << 'x';
#endif
		if ((newalref=="") || (newdilref=="*")) if ((newalref=select_TL_AL_refs(tl,newchunk,newdilref))=="") return String("");
#ifdef DEBUGTIER1
		cout << 'x';
#endif
	}
#ifdef DEBUGTIER1
	cout << "newdilref: " << newdilref << "\nnewalref: " << newalref << '\n';
#endif
	String lfstr, lfrx;
#ifdef DEBUG_BIGSTRING
	//lfstr.debug_on();
	globaldebugop=true;
#endif
	if (newalref[0]!='*') {
		// find previous AL reference with the same ID
		if (!read_file_into_String(listfile,lfstr)) return String("");
		// AL head and title in lists file
#ifdef DEBUG_BIGSTRING
		globaldebugop=false;
		//lfstr.debug_off();
		cout << "[Freshly read] lfstr.length()=" << lfstr.length() << '\n';
#endif
#ifdef DEBUGTIER1
		cout << ".";
#endif
		lfrx = "[<]LI[>][ 	]*[<]A[ 	][^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\""+RX_Search_Safe(RELLISTSDIR+newalref)+"\"[^\n]*";
		altitle = lfstr.at(BigRegex(lfrx));
#ifdef DEBUG_BIGSTRING
		cout << "[After reading into alhead] lfstr.length()=" << lfstr.length() << '\n';
#endif
		alhead = altitle.at(BigRegex("([^)]*AL head"));
		altitle.del(BigRegex("[ 	]*([^)]*AL head.*"));
		altitle.gsub(BigRegex("[<][^>]*[>]"),"");
		if (alhead!="") {
#ifdef DEBUGTIER1
			cout << ".";
#endif
			alhead.del(BigRegex("([^,]*,[ 	]*[<]A [^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\""));
			if (alhead[0]!='/') {
				if (alhead.contains(RELLISTSDIR,0)) alhead.del(RELLISTSDIR);
				else alhead.prepend("../");
			}
			alhead = alhead.before("\"");
			alhead.del(get_TL_head());
		}
#ifdef DEBUGTIER1
		cout << "altitle: " << altitle << "\nalhead: " << alhead << '\n';
#endif
	}
	String dfstr, dlrx;
	if (newdilref[0]!='*') {
		// find previous DIL reference with the same ID or identifying comment
		if (newdilref[0]=='!') { // non-DIL identifying comment
			int dilheadindex;
			if ((dilheadindex = tl.index(BigRegex("Context[ 	]*--[>][ 	]*"+RX_Search_Safe(newdilref.after("!"))+"[^(]*([^/]*/next"),-1))>=0) {
				dilhead = tl.at(BigRegex("Begin[ 	]*-->[^\n]*[<]A[ 	]+[^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\"[^\"]+"),dilheadindex-tl.length());
				if (dilhead!="") {
					dilhead = dilhead.after("\"",-1);
					dilhead.prepend('#');
#ifdef DEBUGTIER1
					cout << "diltitle: " << diltitle << "\ndilhead: " << dilhead << '\n';
#endif
				} else EOUT << "dil2al: Context error, no matching Begin in add_TL_chunk_or_entry(), continuing\n";
			} else {
				// search for Context in previous TL sections
				String prevtlfile = tl.at(BigRegex("[<]/H1[>]\n+[<]TABLE.*[>][ 	]*previous[ 	]+TL[ 	]+section"));
				if (prevtlfile!="") {
					prevtlfile = prevtlfile.after(BigRegex("[<]A[ 	]+[Hh][Rr][Ee][Ff]=\""));
					prevtlfile = basedir+RELLISTSDIR+prevtlfile.before("\"");
					while (prevtlfile!="") {
						String prevtl;
						if (!read_file_into_String(prevtlfile,prevtl)) {
							EOUT << "dil2al: Continuing without non-DIL identifying comment previous dilhead\n";
							break;
						}
						if ((dilheadindex = prevtl.index(BigRegex("Context[ 	]*--[>][ 	]*"+RX_Search_Safe(newdilref.after("!"))+"[^(]*([^/]*/next"),-1))>=0) {
							dilhead = prevtl.at(BigRegex("Begin[ 	]*-->[^\n]*[<]A[ 	]+[^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\"[^\"]+"),dilheadindex-tl.length());
							if (dilhead!="") {
								dilhead = dilhead.after("\"",-1);
								dilhead.prepend('#');
#ifdef DEBUGTIER1
								cout << "diltitle: " << diltitle << "\ndilhead: " << dilhead << '\n';
#endif
								break;
							} else EOUT << "dil2al: Context error, no matching Begin in add_TL_chunk_or_entry(), continuing\n";
						}
						prevtlfile = prevtl.at(BigRegex("[<]/H1[>]\n+[<]TABLE.*[>][ 	]*previous[ 	]+TL[ 	]+section"));
						if (prevtlfile!="") {
							prevtlfile = prevtlfile.after(BigRegex("[<]A[ 	]+[Hh][Rr][Ee][Ff]=\""));
							prevtlfile = basedir+RELLISTSDIR+prevtlfile.before("\"");
						}
					}
				}
			}
		} else { // DIL reference ID
			if (!read_file_into_String(basedir+RELLISTSDIR+newdilref.before("#"),dfstr)) return String("");
			// DIL title in newdilref file
			diltitle = dfstr.at(BigRegex("[<]TITLE[>][^<]*[<]/TITLE[>]"));
			diltitle.del("<TITLE>");
			diltitle.del("</TITLE>");
			// DIL head in newdilref file
			dlrx = "[<]TD[^>]*[>][<]A [^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+RX_Search_Safe(newdilref.after("#"))+"\"[^\n]*([^)]*head";
			dilhead = dfstr.at(BigRegex(dlrx));
			if (dilhead!="") {
				dilhead.del(BigRegex("[<]TD[^>]*[>][<]A [^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+RX_Search_Safe(newdilref.after("#"))+"\"[^\n]*([^,]*,[ 	]*[<]A [^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\""));
				dilhead = dilhead.before("\"");
				dilhead.del(get_TL_head());
			}
#ifdef DEBUGTIER1
			cout << "diltitle: " << diltitle << "\ndilhead: " << dilhead << '\n';
#endif
		}
	}
	// prepend newalref, newdilref, alhead, dilhead, altitle and diltitle information to note
	String notepre;
	if (newchunk) {
		notepre = generate_TL_chunk_header(nametag, newalref, altitle, alhead, newdilref, diltitle, dilhead);
		// find new chunk insertion location (becomes tlinsertloc for entry also)
		if ((tlinsertloc=tl.index(BigRegex("[<]!--[ 	]+section End[ 	]+-->")))<0) {
			EOUT << "dil2al: Unable to find section End in " << taskloghead << "in add_TL_chunk_or_entry()\n";
			return String("");
		}
	} else {
		notepre = generate_TL_entry_header(nametag, newalref, altitle, alhead, newdilref, diltitle, dilhead);
		// reposition at End of chunk for insertion of TL entry
		tlinsertloc=chunkendindex;
	}
	// insert note and store if operations on tl are complete
	String tltail = tl.from(tlinsertloc);
	if (newchunk) tl = tl.before(tlinsertloc) + notepre + tltail;
	else tl = tl.before(tlinsertloc) + notepre + notestr + "<P>\n\n" + tltail;
	get_TL_head();
	String tlheadfile=taskloghead.after(basedir+RELLISTSDIR);
	String alheadfile=alhead.before("#"); if ((alhead!="") && (alheadfile=="")) alheadfile = tlheadfile;
	String dilheadfile=dilhead.before("#"); if ((dilhead!="") && (dilheadfile=="")) dilheadfile = tlheadfile;
#ifdef DEBUGTIER1
	cout << "tlheadfile = " << tlheadfile << "\nalheadfile = " << alheadfile << "\ndilheadfile = " << dilheadfile << '\n';
#endif
	if ((tlheadfile!=alheadfile) && (tlheadfile!=dilheadfile)) {
		// store updated Task Log
		if (!write_file_from_String(taskloghead,tl,"Task Log")) return String("");
	}
	String tlp;
	if (alhead!="") {
		// modify ``next'' in previous AL head
		String newalnext, altlfile = basedir+RELLISTSDIR+alheadfile;
#ifdef DEBUGTIER2
		cout << "D1,"; cout.flush();
#endif
//*** This is not very optimized, requiring some copying
//*** of long Strings. This is due to a ``bug'' in the
//*** String class, which caused modifications via a
//*** pointer tlp->at.() or reference tlp.at() to add
//*** several characters of junk at the end of the
//*** string. Note that we cannot simply overwrite tl
//*** here as it may be needed below.
		if (tlheadfile==alheadfile) {
#ifdef DEBUGTIER2
			cout << "D2,"; cout.flush();
#endif
			tlp = tl;
#ifdef DEBUGTIER2
			cout << "D3,"; cout.flush();
#endif
			newalnext = '#'+nametag;
#ifdef DEBUGTIER2
			cout << "D4,"; cout.flush();
#endif
		} else {
			if (!read_file_into_String(altlfile,tlp)) return String("");
			newalnext = tlheadfile+'#'+nametag;
		}
		BigRegex alindexrx("\\(chunk\\|entry\\)[ 	]+Begin[ 	]+--[>][^\n]*[<]A[ 	][^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+alhead.after("#")+'"');
#ifdef DEBUGTIER1
		cout << "D5,"; cout.flush();
#endif
//*** could make this a forward search by continuing to
//*** search until -1 is returned
//*** NOT NECESSARY WITH NON-PARANOID OR FASTER BACKWARD SEARCH METHOD
		int alnextindex=tlp.index(alindexrx,-1);
#ifdef DEBUGTIER1
		cout << "alnextindex = " << alnextindex << '\n';
		cout << "E,"; cout.flush();
#endif
		if (alnextindex<0) {
			EOUT << "dil2al: Unable to find previous AL head in " << alheadfile << " in add_TL_chunk_or_entry()\n";
			return String("");
		}
#ifdef DEBUGTIER2
		cout << "E0,"; cout.flush();
#endif
		String alnext;
#ifdef DEBUGTIER2
		cout << "E0.5,"; cout.flush();
#endif
		BigRegex alnextrx("AL[ 	]+--[>][^\n]*\""+newalref+"\"[^(]*([^)]*/next");
#ifdef DEBUGTIER2
		cout << "E0.75,"; cout.flush();
#endif
		alnext=tlp.at(alnextrx,alnextindex);
#ifdef DEBUGTIER2
		cout << "alnext =  " << alnext << "\nE1,"; cout.flush(); 		
#endif
		alnext = alnext.before("next",-1) + "<A HREF=\""+newalnext+"\">next</A>";
		//alnext.at("next",-1)="<A HREF=\""+newalnext+"\">next</A>";
#ifdef DEBUGTIER2
		cout << "alnext =  " << alnext << "\nE2,"; cout.flush(); 		
#endif
		String ttmp = tlp.before(BigRegex("AL[ 	]+--[>][^\n]*\""+RX_Search_Safe(newalref)+"\"[^(]*([^)]*/next"),alnextindex);
#ifdef DEBUGTIER2
		cout << "E3,"; cout.flush(); 		
#endif
		ttmp += alnext;
#ifdef DEBUGTIER2
		cout << "E4,"; cout.flush(); 		
#endif
		ttmp += tlp.after(BigRegex("AL[ 	]+--[>][^\n]*\""+RX_Search_Safe(newalref)+"\"[^(]*([^)]*/next"),alnextindex);
#ifdef DEBUGTIER2
		cout << "E5,"; cout.flush(); 		
#endif
		tlp = ttmp;
//*** THIS WORKED... SO IT IS OBVIOUSLY DANGEROUS TO USE THE SUBSTRING REPLACEMENT
//*** METHOD FOR INSERTION, BUT THE ABOVE IS OF COURSE VERY NON-OPTIMAL!
//		tlp.at(BigRegex("AL[ 	]+--[>][^\n]*\""+newalref+"\"[^(]*([^)]*/next"),alnextindex)=alnext;
#ifdef DEBUGTIER1
		cout << "F,"; cout.flush();
#endif
		if (alheadfile!=dilheadfile) {
			if (!write_file_from_String(altlfile,tlp,"AL head Task Log")) return String("");
		}
	}
#ifdef DEBUGTIER1
	cout << "G,"; cout.flush();
#endif
	if (dilhead!="") {
#ifdef DEBUGTIER1
		cout << "H,"; cout.flush();
#endif
		// modify ``next'' in previous DIL head
		String newdilnext, diltlfile = basedir+RELLISTSDIR+dilheadfile;
		if (dilheadfile==tlheadfile) newdilnext = '#'+nametag;
		else newdilnext = tlheadfile+'#'+nametag;
		if (alheadfile!=dilheadfile) {
			if (tlheadfile==dilheadfile) tlp = tl;
			else if (!read_file_into_String(diltlfile,tlp)) return String("");
		}
#ifdef DEBUGTIER2
		cout << "H1,"; cout.flush();
#endif
		String dilnext;
//*** could make this a forward search by continuing to
//*** search until -1 is returned
//*** NOT NECESSARY WITH NON-PARANOID OR FASTER BACKWARD SEARCH METHOD
		int dilnextindex=tlp.index(BigRegex("\\(chunk\\|entry\\)[ 	]+Begin[ 	]+--[>][^\n]*[<]A[ 	][^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+RX_Search_Safe(dilhead.after("#")+'"')),-1);
		if (dilnextindex<0) {
			EOUT << "dil2al: Unable to find previous DIL head in " << dilheadfile << " in add_TL_chunk_or_entry()\n";
			return String("");
		}
#ifdef DEBUGTIER2
		cout << "H2,"; cout.flush();
#endif
		if (newdilref[0]=='!') {
#ifdef DEBUGTIER2
			cout << "H3,"; cout.flush();
#endif
			dilnext=tlp.at(BigRegex("Context[ 	]+--[>][ 	]*"+RX_Search_Safe(newdilref.after("!"))+"[^(]*([^)]*/next"),dilnextindex);
			dilnext.at("next",-1)="<A HREF=\""+newdilnext+"\">next</A>";
			tlp.at(BigRegex("Context[ 	]+--[>][ 	]*"+RX_Search_Safe(newdilref.after("!"))+"[^(]*([^)]*/next"),dilnextindex)=dilnext;
		} else {
#ifdef DEBUGTIER2
			cout << "H4,"; cout.flush();
#endif
			dilnext=tlp.at(BigRegex("Context[ 	]+--[>][^\n]*\""+RX_Search_Safe(newdilref)+"\"[^(]*([^)]*/next"),dilnextindex);
			dilnext.at("next",-1)="<A HREF=\""+newdilnext+"\">next</A>";
			tlp.at(BigRegex("Context[ 	]+--[>][^\n]*\""+RX_Search_Safe(newdilref)+"\"[^(]*([^)]*/next"),dilnextindex)=dilnext;
		}
		if (!write_file_from_String(diltlfile,tlp,"Context head Task Log")) return String("");
#ifdef DEBUGTIER2
		cout << "H5,"; cout.flush();
#endif
	}
	if (newalref[0]!='*') {
#ifdef DEBUGTIER1
		cout << "I,";
#endif
		// update AL head in listfile
		if (alhead!="") {
#ifdef DEBUGTIER1
			cout << ",J"; cout.flush();
#endif
			String newalnext = lfstr.at(BigRegex(lfrx));
#ifdef DEBUG_BIGSTRING
			cout << "[After reading into newalnext] lfstr.length()=" << lfstr.length() << '\n';
#endif
#ifdef DEBUGTIER2
			cout << ",J1"; cout.flush();
#endif
			newalnext.at(BigRegex("[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\"[^\"]+\""),-1) = "HREF=\""+(RELLISTSDIR+tlheadfile)+'#'+nametag+"\"";
#ifdef DEBUGTIER2
			cout << ",J2"; cout.flush();
#endif
#ifdef DEBUG_BIGSTRING
			cout << "lfstr.length()=" << lfstr.length() << '\n';
			newalnext.debug_on();
#endif
			lfstr.at(BigRegex(lfrx)) = newalnext;
#ifdef DEBUG_BIGSTRING
			newalnext.debug_off();
			cout << "lfstr.length()=" << lfstr.length() << '\n';
#endif
		} else {
#ifdef DEBUGTIER2
			cout << ",JJ"; cout.flush();
#endif
			String newalnext = lfstr.at(BigRegex("[<]LI[>][ 	]*[<]A[ 	][^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\""+RX_Search_Safe(RELLISTSDIR+newalref)+"\"[^\n]*"));
#ifdef DEBUGTIER2
			cout << ",JJ1"; cout.flush();
#endif
			newalnext.at("<BR>",-1) = " (<A HREF=\""+(RELLISTSDIR+tlheadfile)+'#'+nametag+"\">AL tail</A>,<A HREF=\""+(RELLISTSDIR+tlheadfile)+('#'+nametag)+"\">AL head</A>)<BR>";
#ifdef DEBUGTIER2
			cout << ",JJ2"; cout.flush();
#endif
			lfstr.at(BigRegex("[<]LI[>][ 	]*[<]A[ 	][^>]*[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\""+RX_Search_Safe(RELLISTSDIR+newalref)+"\"[^\n]*")) = newalnext;
		}
		if (!write_file_from_String(listfile,lfstr,"Main Lists")) return String("");
	}
#ifdef DEBUGTIER1
	cout << ",K";
#endif
	if ((newdilref[0]!='*') && (newdilref[0]!='!')) {
#ifdef DEBUGTIER1
		cout << ",L";
#endif
		// update DIL head in DIL file
		if (dilhead!="") {
			String newdilnext = dfstr.at(BigRegex(dlrx)); 
#ifdef DEBUGTIER2
			cout << ",L1";
#endif
			newdilnext.at(BigRegex("[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\"[^\"]+\""),-1) = "HREF=\""+tlheadfile+'#'+nametag+"\"";
#ifdef DEBUGTIER2
			cout << ",L2";
#endif
			dfstr.at(BigRegex(dlrx)) = newdilnext;
		} else {
#ifdef DEBUGTIER1
			cout << ",M";
#endif
			String newdilnext = dfstr.at(BigRegex("[<]TD[^>]*[>][<]A [^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+RX_Search_Safe(newdilref.after("#"))+"\"[^\n]*"));
#ifdef DEBUGTIER2
			cout << ",M1";
#endif
			newdilnext += " (<A HREF=\""+tlheadfile+'#'+nametag+"\">tail</A>,<A HREF=\""+tlheadfile+'#'+nametag+"\">head</A>)<BR>";
#ifdef DEBUGTIER2
			cout << ",M2";
#endif
			dfstr.at(BigRegex("[<]TD[^>]*[>][<]A [^>]*[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+RX_Search_Safe(newdilref.after("#"))+"\"[^\n]*")) = newdilnext;
		}
		if (!write_file_from_String(basedir+RELLISTSDIR+newdilref.before("#"),dfstr,"DIL")) return String("");
	}
#ifdef DEBUGTIER1
	cout << ",N\n";
#endif
	if (newchunk) chunkcreated = true; // update process variable
	return nametag;
}

bool add_TL_section(String & tl) {
// Add a new section to the Task Log
// Note: modifies current Task Log head file, tl, taskloghead,
//       Main List File (listfile), Task Log symbolic link (tasklog);
//       update in-memory copies and any variables that reference specific
//       items or locations in the modified variables and files if necessary
	// close any currently active TL chunk
	stop_TL_chunk(tl);
	// initialize new TL section
	get_TL_head();
	String curtlid = taskloghead.after("task-log.");
	curtlid = curtlid.before(".html");
	if (curtlid==curdate) {
		EOUT << "dil2al: Cannot create Task Log section with same ID as current Task Log head\n";
		return false;
	}
	String newreltlhead = "task-log."+curdate+".html";
	String newtlsection = "<HTML>\n<HEAD><TITLE>Task Log ("+curdate+")</TITLE>\n</HEAD>\n<BODY BGCOLOR=\"#000000\" TEXT=\"#FFDF00\" LINK=\"#AFAFFF\" VLINK=\"#7F7FFF\">\n<H1><FONT COLOR=\"#00FF00\">Task Log ("
					+ curdate + ")</FONT></H1>\n\n<TABLE WIDTH=\"100%\" CELLPADDING=3 BGCOLOR=\"#007F00\"><TR><TD WIDTH=\"30%\" ALIGN=CENTER><A HREF=\"task-log."
					+ curtlid + ".html\"><FONT COLOR=\"#FFFFFF\">previous TL section ("+curtlid+")</FONT></A><TD WIDTH=\"40%\" BGCOLOR=\"#005F00\">&nbsp;<TD WIDTH=\"30%\" ALIGN=CENTER><FONT COLOR=\"#FFFFFF\">(no next TL section)</FONT></TABLE>\n\n"
					+ "<P>\n<LI><A HREF=\"../lists.html#AL\">Project Active Lists</A>\n"
					+ "<LI><A HREF=\"../lists.html#DIL\">Topical Detailed Items Lists</A>\n"
					+ "<LI><A HREF=\"detailed-items-by-ID.html\">Detailed Items by ID</A>\n"
					+ "<LI><A HREF=\"../work-log.html\">Work Log</A>\n<P>\n<HR>\n<P>\n"
					+ "<!-- section Begin --><TABLE WIDTH=\"100%\" CELLPADDING=3 BGCOLOR=\"#3F3F3F\">\n\n"
					+ "<!-- section End --></TABLE>\n\n<P>\n<HR>\n"
					+ "~/doc/<A HREF=\"../maincont.html\">html</A>/<A HREF=\"../lists.html\">lists</A>/"+newreltlhead+"\n\n</BODY>\n";
	String newtaskloghead = basedir+RELLISTSDIR+newreltlhead;
	if (!write_file_from_String(newtaskloghead,newtlsection,"New Task Log section",true)) return false;
	// update next TL section reference in tl and store current Task Log
	tl.at(BigRegex("[<]FONT[ 	]+COLOR[ 	]*=[ 	]*\"#FFFFFF\"[>][ 	]*([ 	]*no next TL section[ 	]*)[ 	]*[<]/FONT[>][<]/TABLE[>]")) = "<A HREF=\""+newreltlhead+"\"><FONT COLOR=\"#FFFFFF\">next TL section ("+curdate+")</FONT></A></TABLE>";
	if (!write_file_from_String(taskloghead,tl,"Task Log")) return false;
	// update list of Task Log sections in listfile
	String lfstr;
	if (!read_file_into_String(listfile,lfstr)) return false;
	int lftlindex = lfstr.index("<A NAME=\"TL\">");
	if (lftlindex>=0) if ((lftlindex=lfstr.index("</OL>",lftlindex))>=0) lfstr.at(lftlindex,1) = "<LI><A HREF=\""+(RELLISTSDIR+newreltlhead)+"\">Task Log: section initiation date mark "+curdate+"</A>\n<";
	if (lftlindex<0) EOUT << "dil2al: Unable to update Task Log sections list in " << listfile << " in add_TL_section(), continuing as is\n";
	if (!write_file_from_String(listfile,lfstr,"Main List")) return false;
	// update Task Log symbolic link in tasklog
	if (unlink(tasklog)<0) {
		EOUT << "dil2al: Unable to remove Task Log symbolic link " << tasklog << " to task-log." << curtlid << ".html in add_TL_section()\n";
		return false;
	}
	if (symlink(newreltlhead,tasklog)<0) {
		EOUT << "dil2al: Unable to create Task Log symbolic link " << tasklog << " to " << newreltlhead << " in add_TL_section()\n";
		return false;
	}
	// set variables to new Task Log section
	tl = newtlsection;
	taskloghead = newtaskloghead;
	return true;
}

int locate_most_recent_TL_chunk(String & tl, int seekfrom, String * chunkid) {
// seeks from seekfrom through the task log to find the
// most recent chunk, set seekfrom==-1 to search backwards
// from the end of the task log
// returns the starting location of the most recent chunk or the
// beginning of the section (-1 == not found)
// if chunkid!=NULL sets (*chunkid) to the chunk ID or to "" if
// the beginning of the section is returned
// requires a valid task log section in tl
	int tlinsertloc;
	if ((tlinsertloc = tl.index(BigRegex("[<]!--[ 	]+chunk Begin[ 	]+--[>]"),seekfrom))<0) {
		if (chunkid) (*chunkid) = ""; // no chunks in TL
		if ((tlinsertloc = tl.index(BigRegex("[<]!--[ 	]+section Begin[ 	]+--[>]")))<0) {
			// TL section not properly formatted
			EOUT << "dil2al: Section Begin not found in " << taskloghead << " in locate_most_recent_TL_chunk()\n";
			return -1;
		} 
		return tlinsertloc;
	}
	if (chunkid) {
		// get chunk time stamp at tlinsertloc
		(*chunkid) = tl.at(BigRegex("[<]TR[>][<]TD[>][<][^>]*=[^>]*[>][<]A[ 	]+[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\"[0-9]+"),tlinsertloc);
		chunkid->del(BigRegex("[<]TR[>][<]TD[>][<][^>]*=[^>]*[>][<]A[ 	]+[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""));
	}
	return tlinsertloc;
}

String decide_add_TL_chunk(String & tl, int & tlinsertloc, bool comparetimes, bool createifgreater) {
// Add a Task Log chunk based on strategies and time since creation
// of most recent chunk
// time-based decisions can be either
// create-if-greater-than-chunksize-plus-slack or
// create-unless-smaller-than-chunksize
// initialize tlinsertloc with -1 to search from end of Task Log
// tlinsertloc is updated for use when adding entry to Task Log
// returns chunkid
	// find most recent TL chunk (immediately preceding @INSERT-TL-NOTE@ if present)
	const int LLEN = 10240;
	char lbuf[LLEN];
	String chunkid; bool newchunk = !createifgreater;
	if ((tlinsertloc = locate_most_recent_TL_chunk(tl,tlinsertloc,&chunkid))<0) return String("");
	if (chunkid=="") newchunk=true;
	else {
		// compare chunk time stamp with curtime
#ifdef DEBUG
		cout << "decision chunkid = " << chunkid << "\ncurtime = " << curtime << '\n';
#endif
		if (createifgreater) {
			// test if curtime > chunk_creation_time+timechunksize+timechunkslack
			if ((comparetimes) && ((time_stamp_diff(chunkid,curtime)/60)>(timechunksize+timechunkslack))) {
				if (timechunkoverstrategy==TCS_NEW) newchunk=true;
				else if (timechunkoverstrategy==TCS_ASK) {
					if (useansi) cout << ANSI_BOLD_ON; // bold on
					cout << "\nDifference between time stamp of current Task Log chunk and current time is\ngreater than " << (timechunksize+timechunkslack) << " minutes. Create new Task Log chunk? (y/N) ";
					if (useansi) cout << ANSI_BOLD_OFF; // bold off
					cin.getline(lbuf,LLEN);
					if ((lbuf[0]=='y') || (lbuf[0]=='Y')) newchunk=true;
				}
			}
		} else {
			// test if curtime == chunk_creation_time, e.g. created during make_note() opportunity in chunk_controller()
			if (chunkid==curtime) newchunk=false;
			else {
				// test if curtime < chunk_creation_time+timechunksize
				if ((comparetimes) && ((time_stamp_diff(chunkid,curtime)/60)<timechunksize)) {
					if (timechunkunderstrategy==TCS_CURRENT) newchunk=false;
					else if (timechunkunderstrategy==TCS_ASK) {
						if (useansi) cout << ANSI_BOLD_ON; // bold on
						cout << "\nDifference between time stamp of current Task Log chunk and current time is\nless than " << timechunksize << " minutes. Create new Task Log chunk anyway? (y/N) ";
						if (useansi) cout << ANSI_BOLD_OFF; // bold off
						cin.getline(lbuf,LLEN);
						if ((lbuf[0]!='y') && (lbuf[0]!='Y')) newchunk=false;
					}
				}
			}
		}
	}
	if (newchunk) {
		bool newsection = false;
		// if TL contains more than sectionsize chunks consider starting a new section
		int numchunks = BigRegex_freq(tl,"[<]!--[ 	]+chunk Begin[ 	]+--[>]");
		if (numchunks>=sectionsize) {
			if (sectionstrategy==TSS_NEW) newsection = true;
			else if (sectionstrategy==TSS_ASK) {
				if (useansi) cout << ANSI_BOLD_ON; // bold on
				cout << "\nThere are " << numchunks << " chunks in this Task Log section. Create new section? (y/N) ";
				if (useansi) cout << ANSI_BOLD_OFF; // bold off
				cin.getline(lbuf,LLEN);
				if ((lbuf[0]=='y') || (lbuf[0]=='Y')) newsection=true;
			}
		}
		if (newsection) {
			// add a new section to the Task Log
			if (!add_TL_section(tl)) {
				EOUT << "dil2al: Unable to add new Task Log section in decide_add_TL_chunk()\n";
				return String("");
			}
		}
		// add a new chunk to the Task Log
		if ((chunkid = add_TL_chunk_or_entry(tl,chunkid,true,chunkid,tlinsertloc))=="") {
			EOUT << "dil2al: Unable to add new Task Log chunk in decide_add_TL_chunk()\n";
			return String("");
		}
	}
	return chunkid;
}
