// rxwrappers.hh
// Randal A. Koene, 20000307

#ifndef __RX_WRAPPERS__
#define __RX_WRAPPERS__

// redefinition of regular function names so that they call these wrappers
#define re_pattern_buffer
#define re_registers
#define 


#endif
