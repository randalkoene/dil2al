// diladmin.cc
// Randal A. Koene, 20000304

#include "dil2al.hh"

//#define DEBUGTIER1
//#define DEBUGTIER2
//#define DEBUG_HIERARCHY_EXPRESSIONS
//#define DEBUG_PLAN_ENTRY

// Topical_DIL_Files Class member files (see dil2al.hh)

void Topical_DIL_Files::Set_File(String file, int n) {
	if (!n) { ft.file = file; updated=true; return; }
	if (n>0) {
		if (Next()) Next()->Set_File(file,n-1);
		else {
			Topical_DIL_Files * tdf = new Topical_DIL_Files();
			if (Root()->link_before(tdf)) Next()->Set_File(file,n-1);
		}
	} else {
		if (Prev()) Prev()->Set_File(file,n+1);
		else {
			Topical_DIL_Files * tdf = new Topical_DIL_Files();
			if (Root()->link_after(tdf)) Prev()->Set_File(file,n+1);
		}
	}
}

void Topical_DIL_Files::Set_Title(String title, int n) {
	if (!n) { ft.title = title; updated=true; return; }
	if (n>0) {
		if (Next()) Next()->Set_Title(title,n-1);
		else {
			Topical_DIL_Files * tdf = new Topical_DIL_Files();
			if (Root()->link_before(tdf)) Next()->Set_Title(title,n-1);
		}
	} else {
		if (Prev()) Prev()->Set_Title(title,n+1);
		else {
			Topical_DIL_Files * tdf = new Topical_DIL_Files();
			if (Root()->link_after(tdf)) Prev()->Set_Title(title,n+1);
		}
	}
}

int Topical_DIL_Files::Refresh() {
// Clear and reload Topical DIL files list
	if (Prev()) return Prev()->Refresh(); // seek head of list
	delete Next(); // clear list
	ft.file=""; ft.title="";
	const int LLEN = 10240, SLEN = 1024;
	char lbuf[LLEN], sbuf[SLEN];
	ifstream lf(listfile);
	regex_t re;
	regmatch_t rm[3];
	int mres;
	numDILs = 0;
	if (lf) {
		// find DIL header
		if (!find_line(&lf,"<H1><A NAME=\"DIL\">",lbuf,LLEN)) return 0;
		// find <UL>
		if (!find_line(&lf,"<UL>",lbuf,LLEN)) return 0;
		// get DILs
		if (regcomp(&re,"<LI><A +HREF=\"([^\"]*)\">([^<]*)<", REG_EXTENDED) != 0) {
			EOUT << "dil2al: Unable to compile regular expression in get_topical_DILs()\n";
			return 0;
		}
		do {
			if (lf.eof()) {
				regfree(&re);
				return numDILs;
			}
			lf.getline(lbuf,LLEN);
			mres = regexec(&re,lbuf, (size_t) 3, rm, 0);
			if ((mres != 0) && (mres != REG_NOMATCH)) {
				EOUT << "dil2al: Internal error while matching in get_topical_DILs()\n";
				regfree(&re);
				return 0;
			}
			if (!mres) {
				if (rm[2].rm_so==-1) EOUT << "dil2al: Wrong number of substring matches in get_topical_DILs()\n";
				else {
					strncpy(sbuf,&lbuf[rm[1].rm_so],rm[1].rm_eo-rm[1].rm_so);
					sbuf[rm[1].rm_eo-rm[1].rm_so]='\0';
					Set_File(absurl(listfile,sbuf),numDILs);
					strncpy(sbuf,&lbuf[rm[2].rm_so],rm[2].rm_eo-rm[2].rm_so);
					sbuf[rm[2].rm_eo-rm[2].rm_so]='\0';
					Set_Title(sbuf,numDILs);
					numDILs++;
				}
			}
		} while (!pattern_in_line("</UL>",lbuf));
		regfree(&re);
		return numDILs;
	} else {
		EOUT << "dil2al: Error - " << listfile << " not found\n";
		return 0;
	}
}

void DIL_Visualize_with_Tabs::Visualize_Element(DIL_entry * de, int depth) {
	if (depth>0) s += replicate('\t',depth);
	s += "DIL#" + String(de->chars()) + '\n';
	content += "\nDIL#" + String(de->chars()) + ":\n";
	String * ctxt = de->Entry_Text();
	if (ctxt) {
		String ptxtcontent(*ctxt);
		content += (*HTML_remove_tags(ptxtcontent));
	}
	content += '\n';
}

void DIL_Visualize_with_Tabs::Visualize_NotShown(int numdependencies, int depth) {
  if (numdependencies>0) {
    if (depth>0) s += replicate('\t',depth);
    s += '['+String((long) numdependencies)+" dependencies...]\n";
  }
}

void DIL_Visualize_with_HTML_Tabs::Visualize_Element(DIL_entry * de, int depth) {
  String ptxtcontent;
  content += "\nDIL#" + String(de->chars()) + ":\n";
  String * ctxt = de->Entry_Text();
  if (ctxt) {
    ptxtcontent = (*ctxt);
    content += (*HTML_remove_tags(ptxtcontent));
    Elipsis_At(ptxtcontent,hierarchyexcerptlength);
    ptxtcontent.gsub('\n',' ');
  } else ptxtcontent = "<!-- excerpt requires content file option -->";
  content += '\n';
  if (depth>0) s += replicate('\t',depth);
  s += HTML_put_href((de->Topics(0)->dil.file+'#')+de->chars(),"DIL#" + String(de->chars())) + ": " + ptxtcontent + '\n';
}

void DIL_Visualize_with_HTML_Tabs::Visualize_NotShown(int numdependencies, int depth) {
  if (numdependencies>0) {
    if (depth>0) s += replicate('\t',depth);
    s += '['+String((long) numdependencies);
    if (reversehierarchy) s += " superiors...]\n";
    else s += " dependencies...]\n";
  }
}

bool DIL_Visualize_with_FORM_Tabs::Visualize_Plan_Entry(DIL_entry * de) {
  // returns false mostly just to indicate when a regular content editing
  // link should be added to s
  if ((!de) || (!Level_Data())) return false;
  if (hierarchyplanparse) { // additional parsing requested
    if (de->Is_Plan_Entry()==PLAN_ENTRY_TYPE_ACTION) {
#ifdef DEBUG_PLAN_ENTRY
      s += '[' + String((long) de->Is_Plan_Entry()) + ']';
#endif
      if (Level_Data()->Prev()) {
	DIL_entry * pe = Level_Data()->Prev()->Entry();
	if (pe->Is_Plan_Entry()==PLAN_ENTRY_TYPE_GOAL)
	  if (pe->content->Get_Plan_Entry_Content()->Decision()==(*de)) {
	    s += "<B>{!}</B>";
	  }
      }
    }
#ifdef DEBUG_PLAN_ENTRY
    else s += '{' + String((long) de->Is_Plan_Entry()) + '}';
#endif
  }
  if (Level_Data()->likelihood>DILSUPS_REL_UNSPECIFIED) {
    if (cumlikelihood==0.0) cumlikelihood = Level_Data()->likelihood;
    else cumlikelihood *= Level_Data()->likelihood;
    s += " (";
    if (de->content) {
      s += "<A HREF=\"file:///cgi-bin/dil2al?dil2al=MEI&DILID="+de->str()+"\">"; // open link to modification interface
      double desirability = de->content->PLAN_OUTCOME_DESIRABILITY;
      if (desirability>0.0) {
	s += "<B>" + String(desirability,"%3.1f") + "</B>,";
	if (Level_Data()->Prev()) Level_Data()->Prev()->benefit += (Level_Data()->likelihood*desirability);
      } else {
	s += String(desirability,"%3.1f") + ',';
	if (Level_Data()->Prev()) Level_Data()->Prev()->risk += (Level_Data()->likelihood*(-desirability));
      }
      s += "</A>"; //close link to modification interface
    } 
    s += String(Level_Data()->likelihood,"%4.2f") + '|' + String(cumlikelihood,"%5.3f") + ')';
  } else return false;
  return true;
}

void DIL_Visualize_with_FORM_Tabs::Visualize_Element(DIL_entry * de, int depth) {
  const char haslocalflag[2] = {'L','F'};
  const char specialnonlocalflag[1] = {'S'};
  String ptxtcontent;
  content += "\nDIL#" + String(de->chars()) + ":\n";
  String * ctxt = de->Entry_Text();
  if (ctxt) {
    ptxtcontent = (*ctxt);
    content += (*HTML_remove_tags(ptxtcontent));
    Elipsis_At(ptxtcontent,hierarchyexcerptlength);
    ptxtcontent.gsub('\n',' ');
  } else ptxtcontent = "<!-- excerpt requires content file option -->";
  content += '\n';
  if (depth>0) s += replicate('\t',depth);
  else cumlikelihood = 0.0;
  // differentiation of display depending on completion status
  bool pending = true;
  if (de->content) pending = ((de->content->completion>=0.0) && (de->content->completion<1.0));
  // show checkbox and DIL ID reference
  s += "<INPUT type=\"checkbox\" name=\"DILIDCHKBX"+String(de->chars())+"\" value=\"extract\">";
  if (pending) s += HTML_put_href((de->Topics(0)->dil.file+'#')+de->chars(),"<B>DIL#" + String(de->chars()) + "</B>");
  else s += HTML_put_href((de->Topics(0)->dil.file+'#')+de->chars(),"DIL#" + String(de->chars()));
  // optionally show local target date
  if (hierarchysorting) {
    bool isfromlocal; int haslocal, numpropagating;
    time_t tdate = de->Target_Date_Info(isfromlocal,haslocal,numpropagating);
    s += " TD=";
    if (isfromlocal) s += "<B>";
    if (tdate<MAXTIME_T) s += time_stamp("%Y%m%d%H%M,",tdate);
    else s += "unspecified,";
    if (isfromlocal) s += "</B>";
    if (haslocal>0) s += haslocalflag[haslocal-1];
    if (haslocal<0) {
      s += "<B>";
      s += specialnonlocalflag[2+haslocal];
      s += "</B>";
    }
    s += String((long) numpropagating);
  }
  // show level-specific data
  if (Level_Data()) { // visualization that depends on level-specific data
    if (!Visualize_Plan_Entry(de)) if (de->content) s += "[<A HREF=\"file:///cgi-bin/dil2al?dil2al=MEI&DILID="+de->str()+"\">edit</A>]";
  }
  // show DIL entry text content
  s += ": " + ptxtcontent + '\n';
}

void DIL_Visualize_with_FORM_Tabs::Visualize_NotShown(int numdependencies, int depth) {
  if (numdependencies>0) {
    if (depth>0) s += replicate('\t',depth);
    s += '['+String((long) numdependencies);
    if (reversehierarchy) s += " superiors...]\n";
    else s += " dependencies...]\n";
  }
  if (Level_Data())
    if (Level_Data()->has_benefit_risk()) {
      if (depth>0) s += replicate('\t',depth);
      s += "&lt;" + String(Level_Data()->benefit,"%3.1f") + '/' + String(Level_Data()->risk,"%3.1f") + "&gt;\n";
    }
}

// DIL administration functions

bool get_active_DIL_IDs(StringList & idfileids, unsigned long * resnumidfileids) {
// obtains all DIL IDs from the DIL-by-ID file
// optionally adds the number of IDs found to resnumidfileids
	const int LLEN = 10240;
	char lbuf[LLEN];
	String dilid[2];
	unsigned long numidfileids = 0;
	int res;
	ifstream df(idfile);
	if (df) {
		if (!find_line(&df,"[<]!-- *dil2al: *DIL ID *begin *--[>]",lbuf,LLEN)) {
			EOUT << "dil2al: Tag <!-- dil2al: DIL ID begin --> not found in " << idfile << "in get_active_DIL_IDs()\n";
			return false;
		}
		do {
			if ((res=find_in_line(&df,"[<]TR[>]",0,NULL,"[<]!-- *dil2al: *DIL ID *end *--[>]",lbuf,LLEN))==1) {
				res = find_in_line(&df,"[<]TD[^>]*[>][<]A +NAME=\"([.0-9]+)\"",2,dilid,"[<]TR[>]|[<]!-- *dil2al: *DIL ID *end *--[>]",lbuf,LLEN);
				if (res<-1) return false;
				idfileids[numidfileids++] = dilid[1];
			} else {
				if (res>=-1) res=-1;
				else return false;
			}
		} while ((res>0) || ((res==0) && (!pattern_in_line("[<]!-- *dil2al: *DIL ID *end *--[>]",lbuf))));
		df.close();
	} else {
		EOUT << "dil2al: Unable to open DIL ID file " << idfile << "in get_active_DIL_IDs()\n";
		return false;
	}
	if (resnumidfileids) (*resnumidfileids) += numidfileids;
	return true;
}

String superior_reference_info(StringList * supinfoptr) {
// add superior DIL entry references to DIL-by-ID entry
	String res("</A> (");
	if (supinfoptr) {
		int suprefsadded = 0;
		res += "1.0)\n<TD>";
		for (unsigned int sr=0; sr<supinfoptr->length(); sr++) if ((*supinfoptr)[sr]!="") {
			if (suprefsadded>0) res += ", ";
			res += (*supinfoptr)[sr];
			suprefsadded++;
		}
		res += "\n\n";
		if (verbose) VOUT << suprefsadded << " superior DIL entry references added\n";
	} else res += "?.?)\n<TD>&nbsp;\n\n";
	return res;
}

bool add_new_to_DIL(String dilfile, StringList * supinfoptr) {
// Adds all new DIL entry ID references to the DIL-by-ID file,
// with superior DIL entry information if provided in supinfoptr
	const int LLEN = 10240;
	char lbuf[LLEN];
	String dilid[2], dilfilename, dilfiletitle;
	StringList dilfileids, idfileids, beforeid;
	unsigned long numdilfileids = 0, numidfileids = 0, newdils = 0;
	int res;
	// get name of DIL file
	if (!substring_from_line("([^/]+)$",2,dilid,(const char *) dilfile)) {
		EOUT << "dil2al: Unable to parse name from DIL file path in add_new_to_DIL()\n";
		return false;
	} else dilfilename = dilid[1];
	dilfile=basedir+RELLISTSDIR+dilfilename;
	if (verbose) VOUT << "Adding new DIL ID from " << dilfile << '\n';
	ifstream df(dilfile);
	if (df) {
		// get title of DIL file
		if (!find_line(&df,"[<]TITLE[>] *DIL: *",lbuf,LLEN)) {
			EOUT << "dil2al: Unable to find title of DIL file in add_new_to_DIL()\n";
			return false;
		}
		if (!substring_from_line("[<]TITLE[>] *DIL: *([^<]+)",2,dilid,lbuf)) {
			EOUT << "dil2al: Unable to parse title from title line of DIL file in add_new_to_DIL()\n";
			return false;
		} else dilfiletitle = dilid[1];
		// collect all DIL IDs in dilfile
		if (!find_line(&df,"[<]!-- *dil2al: *DIL *begin *--[>]",lbuf,LLEN)) {
			EOUT << "dil2al: Tag <!-- dil2al: DIL begin --> not found in " << dilfile << '\n';
			return false;
		}
		if (verbose) VOUT << "Reading DIL IDs\n";
		do {
			if ((res=find_in_line(&df,"[<]TR +BGCOLOR=\"#00005F",0,NULL,"[<]!-- *dil2al: *DIL *end *--[>]",lbuf,LLEN))==1) {
				res = find_in_line(&df,"[<]TD[^>]*[>][<]A +NAME=\"([.0-9]+)\"",2,dilid,"[<]TR +BGCOLOR=\"#00005F|[<]!-- *dil2al: *DIL *end *--[>]",lbuf,LLEN);
				if (res<-1) return false;
				if (numdilfileids) {
					unsigned long i;
					for (i=0; ((i<numdilfileids) && (dilid[1]>dilfileids[i])); i++);
					dilfileids.insert(i,dilid[1]);
				} else dilfileids[0]=dilid[1];
				numdilfileids++;
			} else {
				if (res>=-1) res=-1;
				else return false;
			}
		} while ((res>0) || ((res==0) && (!pattern_in_line("[<]!-- *dil2al: *DIL *end *--[>]",lbuf))));
		df.close();
	} else {
		EOUT << "dil2al: Unable to open DIL file " << dilfile << '\n';
		return false;
	}
	// compare with all DIL IDs in detailed-items-by-ID.html
	if (verbose) VOUT << "Comparing with DIL IDs in " << idfile << '\n';
	if (!get_active_DIL_IDs(idfileids,&numidfileids)) {
		EOUT << "dil2al: Unable to obtain DIL IDs from " << idfile << '\n';
		return false;
	}
//	for (int i=0; i<numidfileids; i++) cout << idfileids[i] << '\n';
	if (verbose) VOUT << "Removing existing IDs from batch to add\n";
//*** THIS IS WHERE IT *SHOULD* STILL ADD ADDITIONAL DIL REFERENCES TO THE
//*** DIL-BY-ID LIST IF AN ITEM OCCURS IN MORE THAN ONE DIL!!!
//*** SEE DIL 20000124180439.1, WHICH OCCURS IN BOTH components.html and experiments.html
//*** (NOTE ALSO THAT SENDTODIL DID NOT WORK PROPERLY FOR THE SECOND OCCURRANCE!)
	newdils=numdilfileids;
	for (unsigned long i=0; i<numdilfileids; i++)
		for (unsigned long j=0; j<numidfileids; j++)
			if ((dilfileids[i])==(idfileids[j])) {
				dilfileids[i]=""; // avoid adding multiples
				newdils--;
				break;
			} else if ((idfileids[j]>dilfileids[i]) && (beforeid[i]=="")) beforeid[i]=idfileids[j];
	if (newdils>0) {
		VOUT << "Number of new DILs: " << newdils << '\n';
//		for (int i=0; i<numdilfileids; i++) cout << dilfileids[i] << ',' << beforeid[i] << '\n';
		// copy idfile and add new DILs in sorted locations (beforeid[i]=="" implies place at end)
		df.open(idfile);
		if (!df) {
			EOUT << "dil2al: Unable to open DIL ID file " << idfile << "in add_new_to_DIL()\n";
			return false;
		}
		ofstream ndf(idfile+".new");
		if (ndf) {
			//df.seekg(0);
			unsigned long i;
			if (verbose) VOUT << "Inserting new IDs\n";
			// find first new DIL to insert
			for (i=0; (i<numdilfileids) && (dilfileids[i]==""); i++);
			while (!df.eof()) {
				df.getline(lbuf,LLEN);
				if (newdils) {
					// test if found an insertion location
					if ((beforeid[i]!="") && (pattern_in_line("[<]TD[^>]*[>][<]A +NAME=\""+beforeid[i],lbuf))) {
						// insert
						ndf << "<TD><A NAME=\"" << dilfileids[i] << "\">"
							<< dilfileids[i] << "</A>\n<TD><A HREF=\""
							<< dilfilename << '#' << dilfileids[i] << "\">"
							<< dilfiletitle << superior_reference_info(supinfoptr) << "<TR>\n";
						// find next DIL to insert
						for (i++; (i<numdilfileids) && (dilfileids[i]==""); i++);
						newdils--;
					}
					// test if found end of DILs (insert rest here)
					if (pattern_in_line("[<]!-- *dil2al: *DIL ID *end *--[>]",lbuf)) {
						do {
							ndf << "<TR>\n<TD><A NAME=\"" << dilfileids[i] << "\">"
								<< dilfileids[i] << "</A>\n<TD><A HREF=\""
								<< dilfilename << '#' << dilfileids[i] << "\">"
								<< dilfiletitle << superior_reference_info(supinfoptr);
							for (i++; (i<numdilfileids) && (dilfileids[i]==""); i++);
							newdils--;
						} while (newdils);
					}
				}
				if (!df.eof()) ndf << lbuf << endl;
			}
			df.close();
			ndf.close();
			if (!backup_and_rename(idfile,"DIL ID")) return false;
		} else {
			EOUT << "dil2al: Unable to create file " << idfile << ".new in add_new_to_DIL()\n";
			return false;
		}
	} else if (verbose) VOUT << "No new IDs to add\n";
	return true;
}

bool create_new_DIL(String dilfile) {
	const int LLEN = 10240;
	char lbuf[LLEN];
	String dilid[2], dilfilename, diltitle;
	// get name of DIL file regardless of whether it was a relative or absolute path
	if (!substring_from_line("([^/]+)$",2,dilid,(const char *) dilfile)) {
		EOUT << "dil2al: Unable to parse name from DIL file path in create_new_DIL()\n";
		return false;
	} else dilfilename = dilid[1];
	dilfile=basedir+RELLISTSDIR+dilfilename;
	if (verbose) VOUT << "Creating new DIL file " << dilfile << '\n';
	ifstream df(dilfile);
	if (df) {
		df.close();
		cout << "DIL file " << dilfilename << " already exists, overwrite? (y/N) ";
		cin.getline(lbuf,LLEN);
		if ((lbuf[0]!='y') && (lbuf[0]!='Y')) return false;
	}
	ofstream ndf(dilfile);
	if (ndf) {
		if (verbose) VOUT << "Initializing new DIL file\n";
		cout << "DIL title for " << dilfilename << ": ";
		cin.getline(lbuf,LLEN); diltitle = lbuf;
		ndf << "<HTML>\n<HEAD>\n<TITLE>DIL: " << diltitle << "</TITLE>\n";
		ndf << "</HEAD>\n<BODY BGCOLOR=\"#000000\" TEXT=\"#F0E0A0\" LINK=\"#AFAFFF\" VLINK=\"#7F7FFF\">\n";
		ndf << "<H1><FONT COLOR=\"#00FF00\">DIL: " << diltitle << "</FONT></H1>\n\n";
		cout << "DIL keywords and relevance, e.g. neuron (1.0), synapse (1.0): ";
		cin.getline(lbuf,LLEN);
		ndf << "<B>Topic Keywords, k_{top} (and relevance in [0,1]):</B> " << lbuf << "\n<P>\n\n";
		ndf << "<TABLE WIDTH=\"100%\" CELLPADDING=3 BORDER=2>\n<!-- dil2al: DIL begin -->\n\n<!-- dil2al: DIL end -->\n</TABLE>\n\n\n";
		ndf << "<LI><A HREF=\"detailed-items-by-ID.html\">Detailed Items by ID</A>\n<LI><A HREF=\"../lists.html#DIL\">Topical Detailed Items Lists</A>\n<P>\n";
		ndf << "<HR>~/doc/<A HREF=\"../maincont.html\">html</A>/<A HREF=\"../lists.html\">lists</A>/"
			<< dilfilename << " <FONT COLOR=\"#AFAFAF\"><I>&nbsp;&nbsp;&nbsp;(created " << curdate << ", Randal A. Koene)</I></FONT>\n\n</BODY>\n";
 		ndf.close();
	} else {
		EOUT << "dil2al: Unable to create file " << dilfile << " in create_new_DIL()\n";
		return false;
	}
	// Add DIL title and reference to list.html
	df.open(listfile);
	if (!df) {
		EOUT << "dil2al: Unable to open " << listfile << " in create_new_DIL()\n";
		return false;
	}
	ndf.open(listfile+".new");
	if (!ndf) {
		EOUT << "dil2al: Unable to create " << listfile << ".new in create_new_DIL()\n";
		return false;
	}
	if (verbose) VOUT << "Adding new DIL to " << listfile << '\n';
	if (copy_until_line(&df,&ndf,"<H1><A NAME=\"DIL\">",lbuf,LLEN)<=0) {
		EOUT << "dil2al: No DIL header ``<H1><A NAME=\"DIL\">'' found in create_new_DIL()\n";
		return false;
	}
	ndf << lbuf << endl;
	if (copy_until_line(&df,&ndf,"</UL>",lbuf,LLEN)<=0) {
		EOUT << "dil2al: No DIL list end ``</UL>'' found in create_new_DIL()\n";
		return false;
	}
	ndf << "<LI><A HREF=\"" << RELLISTSDIR << dilfilename << "\">" << diltitle << "</A>\n";
	ndf << lbuf << endl;
	ndf << df.rdbuf();
	df.close();
	ndf.close();
	if (!backup_and_rename(listfile,"lists index")) return false;
	return true;
}

bool send_dil_to_DIL(String dilfile) {
	const int LLEN = 10240;
	char lbuf[LLEN];
	String dilid[2], dilfilename;
	// read entry data into string buffer (to avoid confusion in case stdin and create file requests)
	String dentrybuf;
	if (verbose) VOUT << "Reading DIL entry content\n";
	read_data_from_stream(DIN,dentrybuf,"@End of DIL entry@");
	// get inline tag information and remove those inline tags
	String supinfotag("DESUP"); supinfotag = RX_Search_Safe(generate_tag(supinfotag)); // get standardized tag
	supinfotag.gsub(BigRegex(":[ 	]*"),":[%_%]*\\(");
	supinfotag.gsub(" ","[ 	]+");
	supinfotag.gsub("%_%"," 	");
	supinfotag.gsub("SUPid","[.0-9]+");
	supinfotag.gsub(BigRegex("SI[^,)]*"),"[^,)]*");
	supinfotag.gsub(BigRegex("\\(.\\)@"),"_1\\)@",'_');
	BigRegex si(supinfotag); StringList supinfo; int supnum = 0;
	while (dentrybuf.index(si)>=0) {
		supinfo[supnum] = dentrybuf.at(si.subpos(1),si.sublen(1)); // get superior id and information
		dentrybuf.del(si.subpos(0),si.sublen(0)); // remove tag
		supnum++;
	}
	// get name of DIL file regardless of whether it was a relative or absolute path
	if (!substring_from_line("([^/]+)$",2,dilid,(const char *) dilfile)) {
		EOUT << "dil2al: Unable to parse name from DIL file path in send_dil_to_DIL()\n";
		return false;
	} else dilfilename = dilid[1];
	dilfile=basedir+RELLISTSDIR+dilfilename;
	if (verbose) VOUT << "Sending DIL entry to " << dilfile << '\n';
	ifstream df(dilfile);
	if (!df) {
		// optionally create new DIL file
		cout << "DIL file " << dilfilename << " does not exist, create? (y/N) ";
		cin.getline(lbuf,LLEN);
		if ((lbuf[0]=='y') || (lbuf[0]=='Y')) {
			if (!create_new_DIL(dilfilename)) {
				EOUT << "dil2al: Unable to create new DIL file " << dilfilename << " in send_dil_to_DIL()\n";
				return false;
			}
			df.open(dilfile);
		} else return false;
	}
	if (df) {
		ofstream ndf(dilfile+".new");
		if (!ndf) {
			EOUT << "dil2al: Unable to create " << dilfile << ".new in send_dil_to_DIL()\n";
			return false;
		}
		if (verbose) VOUT << "Copying DIL to " << dilfile << ".new and adding new entry\n";
		// copy content up to bottom of DIL table
		if (copy_until_line(&df,&ndf,"[<]!-- *dil2al: *DIL *end *--[>]",lbuf,LLEN)<=0) {
			EOUT << "dil2al: End of DIL table ``<!-- dil2al: DIL end -->'' not found in send_dil_to_DIL()\n";
			return false;
		}
		// add new DIL content
		ndf << dentrybuf;
		// place end of DIL table marker
		ndf << lbuf << endl;
		// copy rest of DIL file
		ndf << df.rdbuf();
		df.close();
		ndf.close();
	} else {
		EOUT << "dil2al: Unable to open new DIL file " << dilfilename << " in send_dil_to_DIL()\n";
		return false;
	}
	if (!backup_and_rename(dilfile,"DIL")) return false;
	StringList * supinfoptr = NULL;
	if (supinfo[0]!="") supinfoptr = &supinfo;
	if (!add_new_to_DIL(dilfile,supinfoptr)) {
		EOUT << "dil2al: Unable to add new item from " << dilfile << " to DIL in send_dil_to_DIL()\n";
		return false;
	}
	return true;
}

String get_new_DIL_ID() {
// generates a new DIL ID based on the current time
// and the next single decimal available with that
// time stamp (in the unlikely event that there are
// already 9 items with that time stamp, it will
// try an ID based on another time stamp)
	// obtain all existing DIL IDs
	StringList idfileids;
	unsigned long numidfileids = 0;
	if (!get_active_DIL_IDs(idfileids,&numidfileids)) {
		EOUT << "dil2al: Unable to obtain DIL IDs from " << idfile << '\n';
		return "";
	}
	// generate a new time stamped DIL ID
	String newdilid;
	for (int loopescape=60; (loopescape); loopescape--) { 
		String idtimestamp = time_stamp("%Y%m%d%H%M%S");
		// try ID decimal indices
		for (char decimalindex = '1'; decimalindex <= '9'; decimalindex++) {
			newdilid = idtimestamp + '.' + decimalindex;
			for (StringList * idfileentry = &idfileids; (idfileentry); idfileentry=idfileentry->get_Next()) {
				if (newdilid==(*idfileentry)[0]) {
					newdilid="";
					break;
				}
			}
			if (newdilid!="") break;
		}
		if (newdilid!="") break;
		if (loopescape>1) {
// #ifdef SYSV
// 			poll((struct poll *) 0, (size_t) 0, 1000); /* 1000 msec */
// #else
			sleep(1); /* usleep(1000000L); 1000000 microsec */
// #endif
		}
	}
	return newdilid;
}

void generate_modify_element_FORM_interface_DIL_entry_content(DIL_entry * de) {
  // generates FORM components specific to editing the content elements of
  // a DIL entry
  VOUT << "<FORM METHOD=\"POST\" ACTION=\"/cgi-bin/dil2al\"><INPUT type=\"hidden\" name=\"dil2al\" value=\"MEi\">\n<P>\n";
  // ID
  VOUT << "<B>DIL ID# " << de->chars() << "</B> Content <INPUT type=\"hidden\" name=\"DILID\" value=\"" << de->chars() << "\">\n<P>\n";
  if (de->content) {
    VOUT << "<TABLE>\n";
    // valuation
    if (de->Is_Plan_Entry()==PLAN_ENTRY_TYPE_OUTCOME) VOUT << "<TR><TD ALIGN=RIGHT><B>desirability</B> = <TD>" << String((double) de->content->PLAN_OUTCOME_DESIRABILITY,"%.2f") << " <TD><INPUT type=\"text\" name=\"valuation\" maxlength=5><TD>&nbsp;\n<P>\n";
    else VOUT << "<TR><TD ALIGN=RIGHT>valuation = <TD>" << String((double) de->content->valuation,"%.2f") << " <TD><INPUT type=\"text\" name=\"valuation\" maxlength=5><TD>&nbsp;\n<P>\n";
    // completion ratio
    VOUT << "<TR><TD ALIGN=RIGHT>completion ratio = <TD>" << String((double) de->content->completion,"%.2f") << " <TD><INPUT type=\"text\" name=\"completion\" maxlength=5><TD>special completion values:\n<UL>\n<LI>-1 = obsolete\n<LI>-2 = replaced\n<LI>-3 = done differently\n<LI>-4 = no longer possible / did not come to pass\n</UL>\n<P>\n";
    // time required
    VOUT << "<TR><TD ALIGN=RIGHT>time required = <TD>" << String((double) (de->content->required/3600.0),"%.2f") << " <TD><INPUT type=\"text\" name=\"required\" maxlength=5><TD>&nbsp;\n<P>\n";
    VOUT << "</TABLE>\n";
  } else VOUT << "<B>No content found!</B>\n<P>\n";
  // text
  if (de->Entry_Text()) {
    String textstr(""),hrefurl,hreftext; int hrefstart,hrefend = 0,hrefnextend; 
    while ((hrefnextend=HTML_get_href(*(de->Entry_Text()),hrefend,hrefurl,hreftext,&hrefstart))>=0) {
      if (hrefstart>hrefend) textstr += de->Entry_Text()->at(hrefend,hrefstart-hrefend);
      hrefurl = absurl(basedir+RELLISTSDIR,hrefurl);
      textstr += HTML_put_href(hrefurl,hreftext);
      hrefend = hrefnextend;
    }
    if (((int) (de->Entry_Text()->length()))>hrefend) textstr += de->Entry_Text()->at(hrefend,de->Entry_Text()->length()-hrefend);
    VOUT << textstr << "\n<P>\n";
    VOUT << "<TEXTAREA name=\"contenttext\" rows=\"20\" cols=\"80\">\n" << *(de->Entry_Text()) << "\n</TEXTAREA>\n<P>\n";
  }
  // close FORM
  VOUT << "<BR><INPUT type=\"submit\" value=\"Process Content\"> <INPUT type=\"reset\"></FORM>\n";
}

void generate_modify_element_FORM_interface_DIL_Superiors(DIL_entry * sup, String dilstr, bool isplanoutcome = false, DIL_Superiors * dilsup = NULL) {
  // shows superior data (where available) and provides input tags for data
  // entry
  if (!sup) VOUT << "*WARNING - This does not appear to be a valid reference!*\n";
  else {
    if (sup->Entry_Text()) {
      String suptext(*(sup->Entry_Text()));
      HTML_remove_tags(suptext);
      remove_whitespace(suptext);
      Elipsis_At(suptext,hierarchyexcerptlength);
      VOUT << suptext << '\n';
    } else VOUT << '\n';
  }
  VOUT << "<BR><TABLE>\n<TR><TD>";
  if (isplanoutcome) VOUT << "likelihood<TD>= ";
  else VOUT << "relevance<TD>= ";
  if (dilsup) VOUT << String((double) dilsup->relevance,"%.2f ");
  VOUT << "<TD><INPUT type=\"text\" name=\"" << dilstr << ".relevance\" maxlength=5><TD>(0.0 = unspecified)\n<TR><TD>unbounded importance<TD>= ";
  if (dilsup) VOUT << String((double) dilsup->unbounded,"%.2f ");
  VOUT << "<TD><INPUT type=\"text\" name=\"" << dilstr << ".unbounded\" maxlength=5><TD>(0.0 = unspecified)\n<TR><TD>bounded importance<TD>= ";
  if (dilsup) VOUT << String((double) dilsup->bounded,"%.2f ");
  VOUT << "<TD><INPUT type=\"text\" name=\"" << dilstr << ".bounded\" maxlength=5><TD>(0.0 = unspecified)\n<TR><TD>target date<TD>= ";
  // Note: Radio buttons are more simplified than property flags. Only one radiotd* variable can be true at a time,
  // even though exact implies the fixed property.
  bool radiotdvariable = true;
  bool radiotdfixed = false;
#ifdef INCLUDE_EXACT_TARGET_DATES
  bool radiotdexact = false;
#endif
  if (dilsup) {
    radiotdfixed = (dilsup->tdproperty() & DILSUPS_TDPROP_FIXED);
    radiotdvariable = !radiotdfixed;
#ifdef INCLUDE_EXACT_TARGET_DATES
    radiotdexact = dilsup->tdexact();
    if (radiotdexact) { radiotdfixed = false; radiotdvariable = false; }
#endif
    if (dilsup->targetdate()==DILSUPS_TD_UNSPECIFIED) VOUT << "unspecified";
    else VOUT << time_stamp("%Y%m%d%H%M",dilsup->targetdate());
  }
  if (radiotdvariable) VOUT << "<TD><INPUT type=\"text\" name=\"" << dilstr << ".targetdate\" maxlength=12>";
  else VOUT << "<TD>(FIXED)";
  VOUT << "<TD>( -1 = unspecified)\n<TR><TD>TD property<TD>" << HTML_put_form_radio(dilstr+".fixed","fixed","fixed",radiotdfixed);
  VOUT << "<TD>" << HTML_put_form_radio(dilstr+".fixed","variable","variable",radiotdvariable);
#ifdef INCLUDE_EXACT_TARGET_DATES
  VOUT << "<TD>" << HTML_put_form_radio(dilstr+".fixed","exact","exact",radiotdexact);
#else
  VOUT << "<TD>&nbsp;";
#endif
#ifdef INCLUDE_EXACT_TARGET_DATES
  bool radiotdnonperiodic = true, radiotddaily = false, radiotdweekly = false, radiotdbiweekly = false, radiotdmonthly = false, radiotdeomoffset = false, radiotdyearly = false;
  if (dilsup) radiotdnonperiodic = !(dilsup->tdproperty() & DILSUPS_TDPROP_PERIODIC);
  if (!radiotdnonperiodic) {
    switch (dilsup->tdperiod()) {
    case 'w': radiotdweekly = true; break;;
    case 'b': radiotdbiweekly = true; break;;
    case 'm': radiotdmonthly = true; break;;
    case 'M': radiotdeomoffset = true; break;;
    case 'y': radiotdyearly = true; break;;
    default: radiotddaily = true; break;;
    }
  }
  VOUT << "\n<TR><TD COLSPAN=4>[if exact: ";
  VOUT << HTML_put_form_radio(dilstr+".period","non-periodic","non-periodic",radiotdnonperiodic) << " / ";
  VOUT << HTML_put_form_radio(dilstr+".period","daily","daily",radiotddaily) << " / ";
  VOUT << HTML_put_form_radio(dilstr+".period","weekly","weekly",radiotdweekly) << " / ";
  VOUT << HTML_put_form_radio(dilstr+".period","bi-weekly","bi-weekly",radiotdbiweekly) << " / ";
  VOUT << HTML_put_form_radio(dilstr+".period","monthly","monthly",radiotdmonthly) << " / ";
  VOUT << HTML_put_form_radio(dilstr+".period","eomoffset","offset from end of month",radiotdeomoffset) << " / ";
  VOUT << HTML_put_form_radio(dilstr+".period","yearly","yearly",radiotdyearly) << ']';
#endif
  VOUT << "\n<TR><TD>computed urgency<TD>= ";
  if (dilsup) VOUT << String((double) dilsup->urgency,"%.2f ");
  VOUT << "<TD><INPUT type=\"text\" name=\"" << dilstr << ".urgency\" maxlength=5><TD>(0.0 = unspecified)\n<TR><TD>computed priority<TD>= ";
  if (dilsup) VOUT << String((double) dilsup->priority,"%.2f ");
  VOUT << "<TD><INPUT type=\"text\" name=\"" << dilstr << ".priority\" maxlength=5><TD>(0.0 = unspecified)\n";
  VOUT << "</TABLE>\n";
}

void generate_modify_element_FORM_interface_DIL_entry_parameters(DIL_entry * de) { //, Detailed_Items_List & dilist) {
  // generates FORM components specific to editing the parameter elements of
  // a DIL entry
  bool isplanoutcome = (de->Is_Plan_Entry()==PLAN_ENTRY_TYPE_OUTCOME);
  VOUT << "<FORM METHOD=\"POST\" ACTION=\"/cgi-bin/dil2al\"><INPUT type=\"hidden\" name=\"dil2al\" value=\"MEi\">\n<P>\n";
  // ID
  VOUT << "<B>DIL ID# " << de->chars() << "</B> Parameters <INPUT type=\"hidden\" name=\"DILID\" value=\"" << de->chars() << "\">\n<P>\n";
  // ***I can add an interface to edit topic information here
  // Current superiors/projects that may be removed
  DIL_Superiors * dilsup = de->Projects(0);
  if (!dilsup) VOUT << "No current superior DIL entry references.\n<P>\n";
  else {
    VOUT << "<U>Current superior DIL ID references</U>:\n<P>\n<OL>\n";
    for (; (dilsup); dilsup = dilsup->Next()) {
      VOUT << "<LI>(remove <INPUT type=\"checkbox\" name=\"suprm__EQ__" << dilsup->al.title << "\">) " << HTML_put_href(dilsup->al.file,dilsup->al.title) << ": ";
      generate_modify_element_FORM_interface_DIL_Superiors(dilsup->Superiorbyid(),dilsup->al.title,isplanoutcome,dilsup);
    }
    VOUT << "</OL>\n<P>\nSelect references above to remove.\n<P>\n";
  }
  // Possible superiors to add
  String dilrefsupstr;
  if (!read_file_into_String(dilref,dilrefsupstr,false)) VOUT << "No superior DIL entries in " << dilref << " for possible addition.\n<P>\n";
  else {
    VOUT << "<U>DIL IDs referenced in " << dilref << "</U>:\n<P>\n<OL>\n";
    dilrefsupstr.gsub(BigRegex("Current[^f]*file..."),"");
    StringList dilrefsups(dilrefsupstr,'\n'); String supid;
    for (unsigned int i=0; i<dilrefsups.length(); i++) {
      supid = dilrefsups[i].after('#');
      DIL_ID did(supid);
      if (did.valid()) {
	VOUT << "<LI>" << HTML_put_href(dilrefsups[i],supid) << ": ";
	generate_modify_element_FORM_interface_DIL_Superiors(de->elbyid(did),supid,isplanoutcome);
      }
    }
    VOUT << "</OL>\n<P>\n<INPUT type=\"checkbox\" name=\"dilrefsups\"> Add these as superior DIL entries.\n<P>\n";
  }
  // close FORM
  VOUT << "<BR><INPUT type=\"submit\" value=\"Process Parameters\"> <INPUT type=\"reset\"></FORM>\n";
}

bool generate_modify_element_FORM_interface(StringList * qlist) {
// generates an HTML FORM interface that enables modification of elements
// of a DIL entry. The DIL entry is given by a DILID variable in qlist.
  int dilididx = qlist->contains("DILID");
  if (dilididx<0) return false;
  DIL_ID dilid((*qlist)[dilididx].after('='));
  if (!dilid.valid()) return false;
  if (calledbyforminput) VOUT << "</PRE><!-- "; // clean up HTML output (dil2al processing output can still be inspected by looking at the HTML source)
  Detailed_Items_List dilist;
  if (dilist.Get_All_DIL_ID_File_Parameters()<0) return false;
  if (!dilist.list.head()) return false;
  if (dilist.Get_All_Topical_DIL_Parameters(true)<0) return false;
  DIL_entry * de = dilist.list.head()->elbyid(dilid);
  if (!de) return false;
  VOUT << "<!-- comment out process output -->\n";
  generate_modify_element_FORM_interface_DIL_entry_content(de);
  VOUT << "<P>&nbsp;<P>\n<HR>\n<P>\n";
  generate_modify_element_FORM_interface_DIL_entry_parameters(de); //,dilist);
  VOUT << "<P>&nbsp;<P>\n";
  return true;
}

void modify_element_through_FORM_interface_DIL_Superiors(int & dilididx, StringList * qlist, String supid, DIL_Superiors * dilsup) {
// test if specific parameters of a DIL_Superiors object should be
// modified and make the modification if possible
// Note that according to the reference at
// http://www.w3.org/TR/REC-html40/interact/forms.html#successful-controls
// an empty text input field may or may not be treated as a successful
// control by the user agent (e.g. w3m), so that particular user agents
// or their particular versions may behave differently. For that reason,
// even if the QUERY_STRING contains some of the parameter tags tested
// below, there must also be a test for a valid value.
  if ((!qlist) || (!dilsup)) return;
  bool validvalue;
  if ((dilididx=qlist->contains(supid+".relevance="))>=0) {
    dilsup->relevance = get_double((*qlist)[dilididx].after('='),dilsup->relevance,&validvalue);
    if (validvalue && verbose) VOUT << "  " << supid << ".relevance = " << String((double) dilsup->relevance,"%.2f\n");
  }
  if ((dilididx=qlist->contains(supid+".unbounded="))>=0) {
    dilsup->unbounded = get_double((*qlist)[dilididx].after('='),dilsup->unbounded,&validvalue);
    if (validvalue && verbose) VOUT << "  " << supid << ".unbounded = " << String((double) dilsup->unbounded,"%.2f\n");
  }
  if ((dilididx=qlist->contains(supid+".bounded="))>=0) {
    dilsup->bounded = get_double((*qlist)[dilididx].after('='),dilsup->bounded,&validvalue);
    if (validvalue && verbose) VOUT << "  " << supid << ".bounded = " << String((double) dilsup->bounded,"%.2f\n");
  }
  if ((dilididx=qlist->contains(supid+".targetdate="))>=0) {
    String newtargetdate = (*qlist)[dilididx].after('=');
    if ((!newtargetdate.empty()) && (newtargetdate.matches(BRXint))) {
      if (!dilsup->set_targetdate(time_stamp_time(newtargetdate))) VOUT << "Unable to modify targetdate, targetdate property=FIXED.\n";
      else if (verbose) VOUT << "  " << supid << ".targetdate = " << time_stamp("%Y%m%d%H%M\n",dilsup->targetdate());
    }
  }
  // Note below: Fixed and variable are possible without exact, but exact is possible only with fixed.
  if ((dilididx=qlist->contains(supid+".fixed=fixed"))>=0) {
#ifdef INCLUDE_EXACT_TARGET_DATES
    dilsup->set_tdproperty((dilsup->tdproperty() | DILSUPS_TDPROP_FIXED) & (~DILSUPS_TDPROP_EXACT));
    dilsup->set_tdexact(false);
#else
    dilsup->set_tdproperty(DILSUPS_TDPROP_FIXED);
#endif
    if (verbose) VOUT << "  " << supid << ".tdproperty = fixed\n";
#ifdef INCLUDE_EXACT_TARGET_DATES
    if (verbose) VOUT << "  " << supid << ".tdexact = false\n";
#endif
  }
  if ((dilididx=qlist->contains(supid+".fixed=variable"))>=0) {
#ifdef INCLUDE_EXACT_TARGET_DATES
    dilsup->set_tdproperty(dilsup->tdproperty() & (~DILSUPS_TDPROP_FIXED) & (~DILSUPS_TDPROP_EXACT));
    dilsup->set_tdexact(false);
#else
    dilsup->set_tdproperty(0);
#endif
    if (verbose) VOUT << "  " << supid << ".tdproperty = variable\n";
#ifdef INCLUDE_EXACT_TARGET_DATES
    if (verbose) VOUT << "  " << supid << ".tdexact = false\n";
#endif
  }
#ifdef INCLUDE_EXACT_TARGET_DATES
  if ((dilididx=qlist->contains(supid+".fixed=exact"))>=0) {
    dilsup->set_tdproperty(dilsup->tdproperty() | DILSUPS_TDPROP_FIXED | DILSUPS_TDPROP_EXACT);
    dilsup->set_tdexact(true);
    if (verbose) VOUT << "  " << supid << ".tdproperty = fixed | exact\n  " << supid << ".tdexact = true\n";
  }
  if ((dilididx=qlist->contains(supid+".period"))>=0) {
    if ((!dilsup->tdexact()) && ((dilididx=qlist->contains(supid+".period=non-periodic"))<0)) {
      VOUT << "Periodic specification ignored! Periodic tasks currently require 'exact' target dates.\n";
    }
    if ((dilididx=qlist->contains(supid+".period=non-periodic"))>=0) dilsup->set_tdperiod('\0');
    else if ((dilididx=qlist->contains(supid+".period=daily"))>=0) dilsup->set_tdperiod('d');
    else if ((dilididx=qlist->contains(supid+".period=weekly"))>=0) dilsup->set_tdperiod('w');
    else if ((dilididx=qlist->contains(supid+".period=bi-weekly"))>=0) dilsup->set_tdperiod('b');
    else if ((dilididx=qlist->contains(supid+".period=monthly"))>=0) dilsup->set_tdperiod('m');
    else if ((dilididx=qlist->contains(supid+".period=eomoffset"))>=0) dilsup->set_tdperiod('M');
    else if ((dilididx=qlist->contains(supid+".period=yearly"))>=0) dilsup->set_tdperiod('y');
    if ((dilididx>=0) && (verbose)) {
      String & qliststr = (*qlist)[dilididx];
      VOUT << "  " << supid << ".tdperiod = " << String(qliststr.after(".period=")) << '\n';
    }
  }
#endif
  if ((dilididx=qlist->contains(supid+".urgency="))>=0) {
    dilsup->urgency = get_double((*qlist)[dilididx].after('='),dilsup->urgency,&validvalue);
    if (validvalue && verbose) VOUT << "  " << supid << ".urgency = " << String((double) dilsup->urgency,"%.2f\n");
  }
  if ((dilididx=qlist->contains(supid+".priority="))>=0) {
    dilsup->priority = get_double((*qlist)[dilididx].after('='),dilsup->priority,&validvalue);
    if (validvalue && verbose) VOUT << "  " << supid << ".priority = " << String((double) dilsup->priority,"%.2f\n");
  }
}

bool modify_element_through_FORM_interface(StringList * qlist) {
// receives information about element modifications in a DIL entry through
// an HTML FORM interface. The DIL entry is given by a DILID variable in qlist.
  if (!qlist) return false;
  // for (int i = 0; i<qlist->length(); i++) VOUT << (*qlist)[i] << '\n';
  int dilididx = qlist->contains("DILID");
  if (dilididx<0) return false;
  DIL_ID dilid((*qlist)[dilididx].after('='));
  if (!dilid.valid()) return false;
  // content modifications
  double valuation = 0.0, completion = 0.0, required = 0.0;
  bool updateval = false, updatecomp = false, updatereq = false;
  String valstr;
  if ((dilididx=qlist->contains("valuation="))>=0) valuation=get_double((*qlist)[dilididx].after('='),valuation,&updateval); // modify valuation
  if ((dilididx=qlist->contains("completion="))>=0) completion=get_double((*qlist)[dilididx].after('='),completion,&updatecomp); // modify completion ratio
  if ((dilididx=qlist->contains("required="))>=0) required=get_double((*qlist)[dilididx].after('='),required,&updatereq); // modify time required
  if (updateval || updatecomp || updatereq) {
    if (!update_DIL_entry_elements(dilid.chars(),valuation,updateval,completion,updatecomp,required,updatereq)) {
      VOUT << "Unable to modify content elements of DIL entry\n";
      return false;
    }
    return true;
  }
  // parameters modifications
  Detailed_Items_List dilist; int entrynum;
  DIL2AL_CONDITIONAL_ERROR_RETURN((entrynum=dilist.Get_All_DIL_ID_File_Parameters())<=0,"No DIL entries found in "+idfile+" in modify_element_through_FORM_interface()\n");
  DIL_entry * de;
  DIL2AL_CONDITIONAL_ERROR_RETURN(!(de = dilist.list.head()->elbyid(dilid)),"The DIL entry "+dilid.str()+" does not appear to exist in modify_element_through_FORM_interface()\n");
  PLLRoot<DIL_Superiors> addsups;
  // detect add
  if ((dilididx=qlist->contains("dilrefsups="))>=0) { // add superiors specified in dilref
    String dilrefsupstr;
    if (!read_file_into_String(dilref,dilrefsupstr,false)) VOUT << "No superior DIL entries in " << dilref << " for possible addition.\n";
    else {
      dilrefsupstr.gsub(BigRegex("Current[^f]*file..."),"");
      StringList dilrefsups(dilrefsupstr,'\n'); String supid;

      for (unsigned int i=0; i<dilrefsups.length(); i++) {
	supid = dilrefsups[i].after('#');
	DIL_ID did(supid);
	if (did.valid()) {
	  DIL_entry * sup = dilist.list.head()->elbyid(did);
	  if (sup) {
	    DIL_Superiors * dilsup = new DIL_Superiors(*de);
	    dilsup->al.title = supid;
	    dilsup->al.file = absurl(idfile,'#'+supid);
	    modify_element_through_FORM_interface_DIL_Superiors(dilididx,qlist,supid,dilsup);
	    addsups.link_before(dilsup);
	    continue;
	  }
	}
	VOUT << supid << "does not appear to be a valid reference!\n";
      }
    }
  }
  // detect remove
  StringList removesups; int removesupsnum = 0;
  for (StringList * qlistptr = qlist->List_Index(qlist->contains("suprm=")); (qlistptr); ) {
    removesups[removesupsnum] = (*qlistptr)[0].after('=');
    if (removesups[removesupsnum].contains('=')) removesups[removesupsnum] = removesups[removesupsnum].before('=');
    removesupsnum++;
    if (!(qlistptr=qlistptr->get_Next())) break;
    qlistptr = qlistptr->List_Index(qlistptr->contains("suprm="));
  }
  // detect modify
  for (DIL_Superiors * dilsup = de->Projects(0); dilsup; dilsup = dilsup->Next())
    modify_element_through_FORM_interface_DIL_Superiors(dilididx,qlist,dilsup->al.title,dilsup);
  if (!update_DIL_entry_parameter_elements(dilist,dilid,addsups,&removesups,removesupsnum)) {
    VOUT << "Unable to modify parameter elements of DIL entry\n";
    return false;
  }
  return true;
}

bool update_DIL_entry_elements(String dilid, double valuation, bool updateval, double completion, bool updatecomp, double required, bool updatereq, time_t tdiff) {
  // update the elements of all instances of dilid, as
  // referenced in the DIL-by-ID file
  // When tdiff>=0, this is used to indicate new time spent on the DIL
  // entry during a task chunk instead of the value in completion.
  // The simplest update uses the difference between current time
  // and the start time of the most recent task log chunk to compute
  // the update. More sophisticated updates apply the rules
  // specified in dil2al.html#20000815153735.1.
  // get DIL references of DIL entry
  Detailed_Items_List dilist; int entrynum;
  if ((entrynum=dilist.Get_All_DIL_ID_File_Parameters(&dilid))<=0) {
    EOUT << "DIL entry " << dilid << " not found in " << idfile << " in update_DIL_entry_completion_ratio(), continuing as is\n";
    return false;
  }
  if (entrynum>1) VOUT << "Warning - DIL entry with ID " << dilid << " occurs " << entrynum << " times in " << idfile << '\n';
  DIL_entry * de = dilist.list.head(); int dilidx;
  PLL_LOOP_FORWARD(DIL_Topical_List,de->Topics(0),1) {
    // get DIL file and update completion ratio of entry
    if ((dilidx=get_file_in_list(e->dil.file,dilist.tf,dilist.tfname,dilist.tfnum))<0)
      EOUT << "dil2al: DIL file " << e->dil.file << " not found in update_DIL_entry_elements(), continuing as is\n";
    else {
      // find DIL ID
      String & dilstr = dilist.tf[dilidx];
      int dilpos, dilentryend; String cellparams, cellcontent;
      if ((dilpos=dilstr.index(BigRegex("[<]!--[ 	]*dil2al:[ 	]*DIL begin[ 	]*--[>]"),String::SEARCH_END))<0) {
        EOUT << "dil2al: Missing DIL begin marker in DIL file " << e->dil.file << " in update_DIL_entry_elements(), continuing as is\n";
        continue;
      }
      if ((dilpos=dilstr.index(BigRegex(("[<][Aa][ 	]+[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\""+RX_Search_Safe(dilid))+'"'),dilpos))<0) {
        EOUT << "dil2al: DIL entry with ID " << dilid << " not found in DIL file " << e->dil.file << " in update_DIL_entry_elements(), continuing as is\n";
        continue;
      }
      if ((dilentryend=HTML_get_table_cell(dilstr,dilpos,cellparams,cellcontent,&dilpos))<0) {
	EOUT << "dil2al: Missing data at DIL entry with ID " << dilid << " in DIL file " << e->dil.file << " in update_DIL_entry_elements(), continuing as is\n";
	continue;
      }
      if (verbose) VOUT << "Setting:\n";
      if (updateval) { // modify valuation
	String vstr(valuation,"_1 %4.2f");
	if (verbose) VOUT << "  valuation = " << vstr << '\n';
	cellcontent.gsub(BigRegex("\\(valuation:[^-0-9 	]*\\)[ 	]*\\([0-9]+[.][0-9]+\\|-\\)"),vstr,'_');
      }
      if (updatecomp) { // modify completion ratio
	String crstr;
	if (tdiff>=0) {
	  if (!updatereq) {
	    cellparams = cellcontent.after(BigRegex("time[ 	]+required[^: 	]*[: 	]")); HTML_remove_tags(cellparams);
	    required = atof(cellparams);
	  }
	  crstr = cellparams.after(BigRegex("completion[ 	]+ratio[^: 	]*[: 	]"));
	  completion = atof(crstr);
	  if (completion<0.0) EOUT << "dil2al: DIL entry with ID " << dilid << " in DIL file " << e->dil.file << " has a completion status with special meaning that cannot be updated in update_DIL_entry_elements(), continuing as is\n";
	  else {
	    if (required==0.0) EOUT << "dil2al: No time required indicated for DIL entry with ID " << dilid << " in DIL file " << e->dil.file << " in update_DIL_entry_elements(), continuing as is\n";
	    else completion += (((double) tdiff)/(ceil(required*60.0)*60.0));
	  }
	}
	crstr = String(completion,"_1 %4.2f");
	if (verbose) VOUT << "  completion ratio = " << crstr << '\n';
	cellcontent.gsub(BigRegex("\\(completion[ 	]+ratio:[^-0-9 	]*\\)[ 	]*\\([0-9]+[.][0-9]+\\|-\\)"),crstr,'_');
      }
      if (updatereq) { // modify required time
	String rstr(required,"_1 %4.2f");
	if (verbose) VOUT << "  required = " << rstr << '\n';
	cellcontent.gsub(BigRegex("\\(time[ 	]+required:[^-0-9 	]*\\)[ 	]*\\([0-9]+[.][0-9]+\\|-\\)"),rstr,'_');
      }
      // paste modified DIL entry into topical DIL file
      String newdilstr(dilstr.before(dilpos));
      newdilstr += HTML_put_table_cell("",cellcontent,true) + dilstr.from(dilentryend);
      // write modified DIL file
      if (!write_file_from_String(e->dil.file,newdilstr,"DIL ``"+e->dil.title+"''")) return false;
    }
  }
#ifdef DEBUG
  EOUT << "Completed DIL updates\n";
#endif
  return true;
}

bool update_DIL_entry_parameter_elements(Detailed_Items_List & dilist, DIL_ID dilid, PLLRoot<DIL_Superiors> & addsups, StringList * removesups, int removesupsnum) {
  // update elements of the DIL-by-ID parameters file
  // target date modification is currently a special case, as described in
  // the modify_DIL_entry_target_date() and modify_DIL_group_target_dates()
  // and is therefore not included in this function
  int entrynum = dilist.list.length();
  if (entrynum<1) return false;
  DIL_entry * de = dilist.list.head()->elbyid(dilid);
  if (!de) {
    VOUT << "The DIL entry with ID " << dilid.chars() << "was not found in the Detailed_Items_List in update_DIL_entry_parameter_elements()\n";
    return false;
  }
  // Add superiors referenced in dilref
  if (addsups.head()) {
    // modify project data to add the superiors
    if (!de->parameters) {
      EOUT << "DIL entry " << dilid << " parameters not found in " << idfile << " in update_DIL_entry_parameter_elements()\n";
      return false;
    }
    if (verbose) VOUT << "Adding superior references from " << dilref << ":\n";
    for (DIL_Superiors * dilsup = addsups.head(); dilsup; dilsup = dilsup->Next()) {
      if (!de->parameters->project_append(dilsup->al.file,dilsup->al.title,dilsup->relevance,dilsup->unbounded,dilsup->bounded,dilsup->targetdate(),dilsup->tdproperty(),
#ifdef INCLUDE_EXACT_TARGET_DATES
					  dilsup->tdexact(),dilsup->tdperiod(),
#endif
					  dilsup->urgency,dilsup->priority)) VOUT << "Unable to append a superior reference with ID " << dilsup->al.title << '\n';
      else if (verbose) VOUT << "     " << dilsup->al.title << " added\n";
    }
  }
  // Remove superiors indicated in removesups
  if ((removesupsnum>0) && (removesups)) {
    if (verbose) {
      VOUT << "Removing superior references:\n";
      for (int i = 0; i<removesupsnum; i++) VOUT << "     " << (*removesups)[i] << '\n';
    }
    // modify project data to remove the superiors
    if (!de->Projects(0)) {
      VOUT << "The DIL entry with ID " << dilid.chars() << " has no superiors, therefore none can be removed.\n";
      return false;
    }
    for (int i = 0; i<removesupsnum; i++) {
      PLL_LOOP_FORWARD(DIL_Superiors,de->Projects(0),1) if (e->al.title==(*removesups)[i]) {
	e->remove();
	if (verbose) VOUT << "     " << (*removesups)[i] << " removed\n";
	break;
      }
    }
  }
  return dilist.Write_to_File();
}

bool modify_DIL_entry_target_date(DIL_ID dilid, time_t tdate, Detailed_Items_List & dilist) {
// modify the target date of dilid in all self- or superior-
// references (dilid can be initialized from a String)
// Target dates are modified locally, without regard to target
// dates of superiors. If no target date was previously given,
// a set of parameters is created. The target date -1 indicates
// that target dates should be set to "?", i.e. unspecified.
// If dilist is empty, Get_All_DIL_ID_File_Parameters() is called.
// Modifications are made only if tdate differs from Target_Date().
// (Note: Use `modify_DIL_group_target_date()' to update the
// target date with minimal disturbances of relationships
// between dependencies and superiors within a group of DIL
// entries.)
// *** perhaps there should be a way to `force' modification if
//     it is used to ensure that the target date is local
	// get DIL parameter sets
	int entrynum;
#ifdef DEBUGTIER1
	VOUT << "dil2al: [DEBUGTIER1] Modifying for DIL#" << dilid.chars() << " to tdate=" << tdate << " (" << time_stamp("%Y%m%d%H%M",tdate) << ")\n";
#endif
	if (!dilist.list.head()) entrynum=dilist.Get_All_DIL_ID_File_Parameters();
	else entrynum=dilist.list.length();
	if (entrynum<=0) {
		EOUT << "No DIL entries found in " << idfile << " in modify_DIL_entry_target_date(), continuing as is\n";
		return false;
	}
#ifdef DEBUGTIER2
	VOUT << "dil2al: [DEBUGTIER2] Modification progress: 1";
#endif
	// get first entry in list
	DIL_entry * de = dilist.list.head();
	// if (!de) return false; // should never happen when entrynum>0
	DIL_entry * did = de->elbyid(dilid);
	if (!did) {
		EOUT << "DIL entry " << dilid << " not found in " << idfile << " in modify_DIL_entry_target_date(), continuing as is\n";
		return false;
	}
#ifdef DEBUGTIER2
	VOUT << ", 2";
#endif
	if (did->Target_Date()!=tdate) { // modify only if different
		if (!did->parameters) {
			EOUT << "DIL entry " << dilid << " parameters not found in " << idfile << " in modify_DIL_entry_target_date(), continuing as is\n";
			return false;
		}
#ifdef DEBUGTIER2
	VOUT << ", 3\n";
#endif
		// modify dilid target dates
		if (did->Projects(0)) PLL_LOOP_FORWARD(DIL_AL_List,did->Projects(0),1) {
#ifdef DEBUGTIER2
			VOUT << "e->targetdate = tdate\n";
#endif
			if (!e->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << dilid << "->#" << e->al.title << '\n';
		} else if (tdate>=0) { // create self-reference for specified target date
			// *** Modify this if the data format changes
#ifdef DEBUGTIER2
			VOUT << "did->parameters->project_append\n";
#endif
			did->parameters->project_append(idfile+String('#')+did->chars(),did->chars(),DILSUPS_REL_UNSPECIFIED,DILSUPS_UNB_UNSPECIFIED,DILSUPS_BND_UNSPECIFIED,tdate,0,
#ifdef INCLUDE_EXACT_TARGET_DATES
							false,'\0',
#endif
							DILSUPS_URG_UNSPECIFIED,DILSUPS_PRI_UNSPECIFIED);
		}
#ifdef DEBUGTIER1
		VOUT << "dil2al: [DEBUGTIER1] Modification performed\n";
#endif
	}
#ifdef DEBUGTIER2
	else VOUT << ", target date already correct\n";
#endif
#ifdef DEBUG
	EOUT << "Modified DIL entry target date\n";
#endif
	return true;
}

bool modify_DIL_entry_target_date(DIL_ID dilid, time_t tdate) {
// modify the target date of dilid in all self- or superior-
// references (dilid can be initialized from a String) and
// write to DIL ID file
// Target dates are modified locally, without regard to target
// dates of superiors. If no target date was previously given,
// a set of parameters is created. The target date -1 indicates
// that target dates should be set to "?", i.e. unspecified.
// Modifications are made only if tdate differs from Target_Date().
// (Note: Use `modify_DIL_group_target_date()' to update the
// target date with minimal disturbances of relationships
// between dependencies and superiors within a group of DIL
// entries.)
	// modify dilid target dates
	Detailed_Items_List dilist;
	if (!modify_DIL_entry_target_date(dilid,tdate,dilist)) return false;
	// place new data and copy rest
#ifdef VERBOSEDEBUG
	PLL_LOOP_FORWARD(DIL_entry,dilist.list.head(),1) {
		EOUT << e->chars();
		if (e->Projects(0)) EOUT << '\t' << e->Projects(0)->targetdate();
		EOUT << '\n';
	}
#endif
#ifdef DEBUG
	bool res = dilist.Write_to_File();
	if (res) EOUT << "Modified DIL entry target date and stored to DIL ID file\n";
	return res;
#else
	return dilist.Write_to_File();
#endif
}

bool modify_DIL_group_target_dates(Detailed_Items_List & dilgroup, bool minfragmentation) {
// Adjust the target dates of DIL entries listed in dilgroup,
// utilizing propagation rules to minimize the number of
// locally specified target dates where superiors can be
// modified and are members of the group. Desired target dates
// are specified in dilgroup.list[i]->Projects(0)->_targetdate,
// so that they can be obtained through dilgroup.list[i]->Target_Date().
// A target date is not changed if it is the same as the
// entry's current Target_Date() or if -2 was specified.
// A target date specification of -1 implies that it will be
// set to `DILSUPS_TD_UNSPECIFIED'.
#ifdef DEBUG_REPORT_DEVIATIONS
  int tdmodifdeviations = 0;
#endif
  Detailed_Items_List dilist; DIL_entry * did = NULL; time_t tdate;
#ifdef DEBUGTIER2
  time_t * oldtargetdate;
  if (!dilist.list.head()) dilist.Get_All_DIL_ID_File_Parameters();
  oldtargetdate = new time_t[dilist.list.length()];
  for (int i=0; i<dilist.list.length(); i++) oldtargetdate[i] = dilist.list.el(i)->Local_Target_Date(0);
#endif
  if (minfragmentation) { // apply minimization rules
#ifdef DEBUGTIER2
    VOUT << "dil2al: [DEBUGTIER2] Applying rules to minimize fragmentation\n";
#endif
    int entrynum=dilist.Get_All_DIL_ID_File_Parameters();
    if (entrynum<=0) {
      EOUT << "No DIL entries found in " << idfile << " in modify_DIL_group_target_dates(), continuing as is\n";
      return false;
    }
    DIL_entry * de = dilist.list.head();
    // sort dilgroup in reverse order of desired target dates
    // - thus superiors with the latest target date are updated first (minimizes insulations)
    DIL_entry ** e = dilgroup.Sort_by_Target_Date(); // traverse in reverse order, highest to lowest
#define MODIFY_DIL_GROUP_TARGET_DATES_RETURN_WITH_CLEANUP(res) delete[] e; return res
    for (int i = dilgroup.list.length()-1; i>=0; i--) if ((tdate=e[i]->Local_Target_Date(0))>=-1) { // iterate through dilgroup members
      did = de->elbyid(*(e[i]));
      if (!did) {
	EOUT << "DIL entry " << e[i]->chars() << " not found in " << idfile << " in modify_DIL_group_target_dates(), continuing as is\n";
	MODIFY_DIL_GROUP_TARGET_DATES_RETURN_WITH_CLEANUP(false);
      }
      if (did->Projects(0)) PLL_LOOP_FORWARD_NESTED(DIL_Superiors,did->Projects(0),1,pe) { // iterate through corresponding dilist member superiors
	// Note: Do this even if did->Target_Date()==tdate to insure that
	//       did->Target_Date()==tdate will also be true after the
	//       target dates of superiors may have been modified.
	// *** can set local target date if pe refers to self
	//     once superior references are pointer parameters
	// set `local' target date specifications to desired target date
	if (pe->targetdate()>=0) { 
	  if (!pe->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << e[i]->chars() << "->#" << pe->al.title << '\n';
	} else if (tdate>=0) { // if original TD is propagated from superior
	  if (pe->IsSelfReference()) {
	    EOUT << "dil2al: Warning - Correcting self-reference without local target date in modify_DIL_group_target_dates\n()";
	    if (!pe->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << e[i]->chars() << "->#" << pe->al.title << '\n';
	  } else {
	    // 1 - find the new target date that this superior is to be set to
	    DIL_ID peid(pe->al.title);
	    DIL_entry * peg = dilgroup.list.head()->elbyid(peid); // can't use Superiorbyid() here, since getting in dilgroup
	    time_t petdate = -1;
	    if (peg) petdate = peg->Local_Target_Date(0); // to insure that code -1 is detected
	    // 2 - does this superior take care of the intended target date?
	    DIL_entry * sup = pe->Superiorbyid();
	    if (!sup) {
	      EOUT << "dil2al: DIL entry superior with ID #" << pe->al.title << " not found in modify_DIL_group_target_dates(), continuing as is\n";
	      continue;
	    }
	    // if superior pe of e is in dilgroup with same desired TD
	    // then pe will take care of update (beware of loops)
	    if (petdate==tdate) continue;
	    // 3 - to avoid propagation of earlier TD, set locally
	    // if pe->Target_Date() is earlier than desired
	    // then set desired locally (don't alter superior, since
	    // that could affect other dependencies of that superior)
	    if (sup->Target_Date()<tdate) { // insulate from superior's target date
	      if (!pe->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << e[i]->chars() << "->#" << pe->al.title << '\n';
	    } else {
	      // 4 - if the dependency is highly relevant, completing the
	      //     superior earlier does not make sense
	      // if pe in dilgroup and pe desired < e desired
	      // and relevance not 1.0 or unspecified then set locally
	      // else warn incompatibility for fully relevant dependency
	      if ((peg) && (petdate<tdate)) {
		if ((pe->relevance<1.0) && (pe->relevance!=DILSUPS_REL_UNSPECIFIED)) {
		  // set locally, because superior will be set to earlier
		  if (!pe->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << e[i]->chars() << "->#" << pe->al.title << '\n';
		  continue;
		} else if (petdate>=0) EOUT << "dil2al: Warning - earlier target date requested for superior with ID #" << pe->al.title << " than for dependency with ID # " << e[i]->chars() << " in modify_DIL_group_target_dates(), continuing\n";
	      }
	      // 5 - if superior is not being changed or petdate>tdate then
	      //     if propagated TD is still too late then set it locally
	      // if pe is last superior and Target_Date() is still
	      // > desired then set locally
	      if (!pe->Next()) if (did->Target_Date()>tdate) {
		if (!pe->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << e[i]->chars() << "->#" << pe->al.title << '\n';
	      }
	    }
	  }
	}
      } else if (tdate>=0) { // unless setting to unspecified, make a self-reference
	// *** Modify this if the data format changes
	if (!did->parameters) did->parameters = new DIL_entry_parameters(*did);
	did->parameters->project_append(idfile+'#'+did->chars(),did->chars(),DILSUPS_REL_UNSPECIFIED,DILSUPS_UNB_UNSPECIFIED,DILSUPS_BND_UNSPECIFIED,tdate,0,
#ifdef INCLUDE_EXACT_TARGET_DATES
					false,'\0',
#endif
					DILSUPS_URG_UNSPECIFIED,DILSUPS_PRI_UNSPECIFIED);
      }
    }
    // Double-check to insure that target dates are detected as requested
    for (int i = dilgroup.list.length()-1; i>=0; i--) if ((tdate=e[i]->Local_Target_Date(0))>=0) { // iterate through dilgroup members
      did = de->elbyid(*(e[i]));
      if (did->Target_Date()!=tdate) {
#ifdef DEBUG_REPORT_DEVIATIONS
	tdmodifdeviations++; // useful when testing functional or rule-based approach above
#endif
	if (did->Projects(0)) {
	  if (did->Target_Date()>tdate) {
	    if (!did->Projects(0)->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << e[i]->chars() << "->#" << did->Projects(0)->al.title << '\n';
	    else VOUT << "Forcing target date adjustment at DIL entry #" << did->chars() << " superior reference " << did->Projects(0)->al.title << '\n';
	  } else PLL_LOOP_FORWARD_NESTED(DIL_Superiors,did->Projects(0),1,pe) { // iterate through corresponding dilist member superiors
	    if (pe->targetdate() < tdate) {
	      if (!pe->set_targetdate(tdate)) VOUT << "Unable to modify FIXED target date of ref.#" << e[i]->chars() << "->#" << pe->al.title << '\n';
	      else VOUT << "Forcing target date adjustment at DIL entry #" << did->chars() << " superior reference " << pe->al.title << '\n';
	    }
	  }
	}
      }
    }
    // Final test of detected target dates achieved
    for (int i = dilgroup.list.length()-1; i>=0; i--) if ((tdate=e[i]->Local_Target_Date(0))>=0) // iterate through dilgroup members
      if (de->elbyid(*(e[i]))->Target_Date()!=tdate) EOUT << "dil2al: Unable to set target date for DIL#" << did->chars() << " in modify_DIL_group_target_dates(), continuing as is\n";
    delete[] e;
  } else PLL_LOOP_FORWARD(DIL_entry,dilgroup.list.head(),1) { // modify target dates directly
    tdate = e->Local_Target_Date(0); // not using Target_Date() to insure -1 and -2 codes are detected
    if (tdate>=-1) if (!modify_DIL_entry_target_date(*e,tdate,dilist)) return false;
  }
#ifdef DEBUGTIER2
  int i = 0;
  PLL_LOOP_FORWARD(DIL_entry,dilist.list.head(),1) {
    if (e->Local_Target_Date(0)!=oldtargetdate[i]) cout << "dil2al: [DEBUGTIER2] Changed DIL entry #" << e->chars() << ", old=" << oldtargetdate[i] << " (" << time_stamp("%Y%m%d%H%M",oldtargetdate[i]) << "), new=" << e->Local_Target_Date(0) << " (" << time_stamp("%Y%m%d%H%M",e->Local_Target_Date(0)) << ") TD=" << time_stamp("%Y%m%d%H%M",e->Target_Date()) << '\n';
    i++;
  }
  delete[] oldtargetdate;
#endif
#ifdef DEBUG_REPORT_DEVIATIONS
  EOUT << "dil2al: [DEBUG_REPORT_DEVIATIONS] Target Date Modification Deviations = " << tdmodifdeviations << '\n';
#endif
#ifdef DEBUG
  bool res = dilist.Write_to_File();
  if (res) EOUT << "Modified DIL group target dates and stored to DIL ID file\n";
  return res;
#else
  return dilist.Write_to_File();
#endif
/*
An alternative approach
-----------------------
Note that the concept below needs to be worked out for the case of muiltiple
superiors at each level, i.e. when tracking through the superiors structure,
all path possibilities must be marked/remembered, instead of just using pe as
a roadblock. Due to this, and the depth-search itself, it is unclear if this
functional approach is more or less efficient than the rule-based one. It also
remains to be seen if this approach follows all the same rules as the rule-based
approach.

From furthest TD to nearest TD in list of DIL entries:

isgroupsuperior()
	if (!pe) return false;
	e = dilgroup.list.head()->elbyid(*pe);
	if (!e) return false;
	if (e->Target_Date()!=tdate) return false;
	return true;

while Target_Date()!=tdate
	pe = NULL
	while (!isgroupsuperior(pe)) pe = Target_Date_Specified(pe);
	if (pe->Projects(0)) pe->Projects(0)->_targetdate = tdate;
	else pe->parameters->add_project(...,tdate,...);
*/
}

bool modify_DIL_group_target_dates_cmd(bool minfragmentation, StringList * qlist) {
// Command line interface to modify_DIL_group_target_dates().
// Reads pairs of DIL entry IDs and desired target dates (with
// optional -2 code to indicate no target date modification, and
// -1 to unspecify local target date parameters).
// Data is read from the DIN stream.
// If qlist is not NULL then HTML form data is obtained from qlist.
	const BigRegex td("^TD\\([0-9]+[.][0-9]+\\)=");
	const BigRegex tdchkbx("^TDCHKBX\\([0-9]+[.][0-9]+\\)=");
	const BigRegex pairsep("[ \t,:;]+");
	const BigRegex nonnumerals("[^-0-9]");
	String modifdata;
	if (qlist) { // HTML form interface
		StringList exclude; int excludenum = 0;
		int qnum = qlist->length()-1; // *** empty element at end of StringList
		for (int i = 0; i<qnum; i++) {
		// *** Beware: This code assumes that DIL entry IDs do not
		//     occur as subsets of other DIL entry IDs, i.e. it
		//     assumes that a move to IDs with more digits would imply
		//     prepending older IDs with 0s. This could of course be
		//     handled by a preprocessing loop.
#ifdef DEBUGTIER2
			cout << '$' << (*qlist)[i] << '\n';
#endif
			if ((*qlist)[i].contains("TDupdate=")) {
				if ((*qlist)[i].after('=')=="direct") minfragmentation = false;
				else minfragmentation = true;
			} else if ((*qlist)[i].contains(td)) {
				modifdata += (*qlist)[i].at(td.subpos(1),td.sublen(1)) + ' ';
				String tdstr = (*qlist)[i].after('='); if (tdstr.length()==0) tdstr = "-2";
				modifdata += tdstr + '\n';
			} else if ((*qlist)[i].contains(tdchkbx)) {
				String chkbxid = (*qlist)[i].at(tdchkbx.subpos(1),tdchkbx.sublen(1));
				String tdstr = (*qlist)[i].after('=');
				if (tdstr=="noupdate") { // set corresponding desired target date to code -2
					exclude[excludenum] = chkbxid;
					excludenum++;
				}
			}
		}
		for (int i = 0; i<excludenum; i++) modifdata.gsub(BigRegex(RX_Search_Safe(exclude[i])+" [-0-9]*"),exclude[i]+" -2");
	} else {
		if (useansi) VOUT << ANSI_BOLD_ON;
		VOUT << "Enter group of DIL entries to consider for target date modification.\n";
		if (useansi) VOUT << ANSI_BOLD_OFF;
		VOUT << "Rows of DIL entry ID and desired target date pairs.\n\
Special desired target date codes:\n\
-1 = set to `unspecified', -2 = no desired target date (but modifiable).\n\
Separate pairs with any number of spaces, tabs, commas, colons or semicolons.\n\
End of File (Ctrl+D) or a line stating `EOF' completes data entry.\n\n";
		if (useansi) VOUT << ANSI_UNDERLINE_ON;
		VOUT << "DIL entry ID#\tdesired target date\n";
		if (useansi) VOUT << ANSI_UNDERLINE_OFF;
		read_data_from_stream(DIN,modifdata,"EOF");
	}
	StringList modiflist(modifdata,'\n');
	int groupsize = modiflist.length()-1; // *** last entry empty when initializing from string with separator
	Detailed_Items_List dilgroup; DIL_entry * de; String did; time_t tdate;
#ifdef DEBUGTIER2
	cout << "Content-Type: text/plain\n\ndil2al: [DEBUGTIER2]\n";
	for (int j=0; j<groupsize; j++) {
		String & s = modiflist[j];
		cout << s << '\n';
	}
	cout << "+++\n";
#endif
	for (int i=0; i<groupsize; i++) {
		did = modiflist[i].after(pairsep); if (did.index(nonnumerals)>=0) did = did.before(nonnumerals);
 		tdate = time_stamp_time(did);
		did = modiflist[i].before(pairsep);
		de = new DIL_entry(dilgroup,did);
		de->parameters = new DIL_entry_parameters(*de);
		de->parameters->project_append('#'+did,did,DILSUPS_REL_UNSPECIFIED,DILSUPS_UNB_UNSPECIFIED,DILSUPS_BND_UNSPECIFIED,tdate,0,
#ifdef INCLUDE_EXACT_TARGET_DATES
					       false,'\0',
#endif
					       DILSUPS_URG_UNSPECIFIED,DILSUPS_PRI_UNSPECIFIED);
		dilgroup.list.link_before(de);
	}
#ifdef DEBUGTIER1
	if (minfragmentation) cout << "dil2al: [DEBUGTIER1] Minimum fragmentation\n"; else cout << "dil2al: [DEBUGTIER1] Direct\n";
#endif
#ifdef DEBUGTIER2
	for (int i=0; i<groupsize; i++) {
		cout << "dil2al: [DEBUGTIER2] " << dilgroup.list.el(i)->chars() << '\t';
		if (dilgroup.list.el(i)->Local_Target_Date(0)<0) cout << dilgroup.list.el(i)->Local_Target_Date(0) << '\n';
		else cout << time_stamp("%Y%m%d%H%M",dilgroup.list.el(i)->Local_Target_Date(0)) << '\n';
	}
#endif
	return modify_DIL_group_target_dates(dilgroup,minfragmentation);
}

bool extract_DIL_IDs_from_form(StringList * qlist) {
  // Form interface that extracts DIL IDs that correspond to checked
  // checkboxes in any form.
  // Known variable names in form: dil2al, DILIDCHKBX<DIL_ID>, processcmd,
  // maxdepth, hierarchyfile.
  if (!qlist) return false;
  const BigRegex dilidchkbx("^DILIDCHKBX\\([0-9]+[.][0-9]+\\)=");
  StringList dilids; int dilidsnum = 0;
  // Find checked checkboxes that contain DIL IDs
  int qnum = qlist->length()-1; // *** empty element at end of StringList
  for (int i = 0; i<qnum; i++) {
    // *** Beware: The same caveat about the assumed length of DIL IDs applies
    //     as in the modify_DIL_group_target_dates_cmd() function above.
#ifdef DEBUGTIER2
    cout << '$' << (*qlist)[i] << '\n';
#endif
    if ((*qlist)[i].contains(dilidchkbx)) {
      String chkbxid = (*qlist)[i].at(dilidchkbx.subpos(1),dilidchkbx.sublen(1));
      String chkbxval = (*qlist)[i].after('=');
      if (chkbxval=="extract") {
	dilids[dilidsnum] = chkbxid;
	dilidsnum++;
      }
    }
  }
  // Check if extract or make new hierarchy
  int processcmdidx = qlist->contains("processcmd");
  if (processcmdidx>0) if (String((*qlist)[processcmdidx].after('='))=="newhierarchy") {
    int depthidx = qlist->contains("maxdepth"), maxdepth = 50;
    if (depthidx>0) maxdepth = atol((const char *) String((*qlist)[depthidx].after('=')));
    int hierarchyfileidx = qlist->contains("hierarchyfile"); String hierarchyfile("");
    if (hierarchyfileidx>0) hierarchyfile = '@'+String((*qlist)[hierarchyfileidx].after('='))+'@';
    int expressionsidx = qlist->contains("expressions"); String expressions("");
    if (expressionsidx>0) expressions = '#'+URI_unescape(String((*qlist)[expressionsidx].after('=')));
    int contentfileidx = qlist->contains("contentfile"); String contentfile("");
    if (contentfileidx>0) contentfile = 'c'+String((*qlist)[contentfileidx].after('='));
    return DIL_Hierarchy_cmd(hierarchyfile+"FORM"+dilids.concatenate('+')+contentfile+expressions,maxdepth);
  }
  // Write the DIL IDs to the dilref file
  if (dilidsnum==0) return false;
  VOUT << dilids.concatenate("\n");
  String dilidsstr;
  for (int i = 0; i<dilidsnum; i++) dilidsstr += "Current URL      file://"+idfile+'#'+dilids[i]+'\n';
  return write_file_from_String(dilref,dilidsstr,"Checked DIL IDs");
}

void Show_DIL_Hierarchy(DIL_entry * topde, DIL_Visualize & dv, const int maxdepth, int depth, double likelihood) {
// create a visual representation of a DIL hierarchy from a DIL entry
// topde must be part of a valid Detailed_Items_List or at least part
// of a valid PLLHandle<DIL_entry> list.
#ifdef DEBUG_PLAN_ENTRY
  EOUT << "Show " << topde->chars() << '\n'; EOUT.flush();
#endif
  DIL_Hierarchy_Level_Data ld(*topde,likelihood);
  dv.ldroot.link_before(&ld); // link into list of level data in this depth first process
  dv.Attach_Level_Data(ld);
  dv.Visualize_Element(topde,depth);
  dv.Detach_Level_Data();
  depth++;
  int numdependencies = 0; double thislevelcumlikelihood = dv.get_cumlikelihood();
  if (hierarchysorting) {
    DIL_entry_ptr * dep = 0; int n = 0;
    if (reversehierarchy) {
      DIL_AL_List * topdeproj = topde->Projects(0);
      if (topdeproj) dep = new DIL_entry_ptr[topdeproj->length()]; 
      if (topdeproj) PLL_LOOP_FORWARD(DIL_AL_List,topdeproj,1) if (!(e->Superiorbyid()==topde)) {
	if (maxdepth>=depth) dep[n++] = e->Superiorbyid();
	else numdependencies++;
      }
    } else {
      if (topde->head()) dep = new DIL_entry_ptr[topde->head()->length()]; 
      PLL_LOOP_FORWARD(DIL_entry,topde->head(),1) if (e->Is_Direct_Dependency_Of(topde)) {
	if (maxdepth>=depth) dep[n++] = e;
	else numdependencies++;
      }
    }
    if (n>0) {
      qsort(dep,n,sizeof(DIL_entry_ptr),DIL_entry_target_date_qsort_compare);
      for (int i=0; i<n; i++) {
	// [***INCOMPLETE] This implementation does not take into account
	// e->PLAN_OUTCOME_LIKELIHOOD when hierarchysorting is true.
	dv.set_cumlikelihood(thislevelcumlikelihood);
	Show_DIL_Hierarchy(dep[i],dv,maxdepth,depth);
      }
    }
    delete[] dep;
  } else {
    if (reversehierarchy) {
      DIL_AL_List * topdeproj = topde->Projects(0);
      if (topdeproj) PLL_LOOP_FORWARD(DIL_AL_List,topdeproj,1) if (!(e->Superiorbyid()==topde)) {
	if (maxdepth>=depth) {
	  dv.set_cumlikelihood(thislevelcumlikelihood);
	  Show_DIL_Hierarchy(e->Superiorbyid(),dv,maxdepth,depth,e->PLAN_OUTCOME_LIKELIHOOD);
	} else numdependencies++;
      }
    } else {
      PLL_LOOP_FORWARD(DIL_entry,topde->head(),1) if (e->Is_Direct_Dependency_Of(topde)) {
	if (maxdepth>=depth) Show_DIL_Hierarchy(e,dv,maxdepth,depth);
	else numdependencies++;
      }
    }
  }
  // the following is used to convey benefit/risk information for PLAN
  // entries and if maxdepth was reached and there are further dependencies
  dv.Attach_Level_Data(ld);
  dv.Visualize_NotShown(numdependencies,depth);
  dv.Detach_Level_Data();
  // ld is automatically removed from list of level data in this depth first process
}

String Tabbed_DIL_Hierarchy(String dilidstr, int maxdepth) {
// visualize a DIL hierarchy starting at dilid with tabs indicating depth
	DIL_Visualize_with_Tabs dv;
	// 3. Get optional expressions that must occur in DIL entry content text
 	String expressions(dilidstr.after('#'));
	if (!expressions.empty()) dilidstr = dilidstr.before('#');
	// 4. Get optional ContentFile reference
	String contentfile(dilidstr.after('c'));
	if (!contentfile.empty()) dilidstr = dilidstr.before('c');
	DIL_ID dilid(dilidstr);
	if (!dilid.valid()) return String("");
	Detailed_Items_List dilist;
	dilist.Get_All_DIL_ID_File_Parameters();
	if (!contentfile.empty()) dilist.Get_All_Topical_DIL_Parameters(true);
	if (dilist.list.head()) Show_DIL_Hierarchy(dilist.list.head()->elbyid(dilid),dv,maxdepth);
	if (!contentfile.empty()) if (!write_file_from_String(contentfile,dv.Output_Content(),"DIL Hierarchy Content")) EOUT << "dil2al: Unable to write " << contentfile << "in Tabbed_DIL_Hierarchy(), continuing as is\n";
	return dv.Output();
}

String Tabbed_HTML_DIL_Hierarchy(String dilidstr, int maxdepth) {
// visualize a DIL hierarchy starting at dilid with tabs indicating depth
// including HREFs and other HTML code, while HTML head and tail code are
// left to the content in which the extracted hierarchy is embedded
// Note that since standard output does not know which file the text may
// be embedded in, HREF file references are absolute. Post-processing may
// convert those to relative references.
	DIL_Visualize_with_HTML_Tabs dv;
  	// 3. Get optional expressions that must occur in DIL entry content text
  	String expressions(dilidstr.after('#'));
  	if (!expressions.empty()) dilidstr = dilidstr.before('#');
  	// 4. Get optional ContentFile reference
	String contentfile(dilidstr.after('c'));
	if (!contentfile.empty()) dilidstr = dilidstr.before('c');
	DIL_ID dilid(dilidstr);
	if (!dilid.valid()) return String("");
	Detailed_Items_List dilist;
	dilist.Get_All_DIL_ID_File_Parameters();
	if (!contentfile.empty()) dilist.Get_All_Topical_DIL_Parameters(true);
	if (dilist.list.head()) Show_DIL_Hierarchy(dilist.list.head()->elbyid(dilid),dv,maxdepth);
	if (!contentfile.empty()) if (!write_file_from_String(contentfile,dv.Output_Content(),"DIL Hierarchy Content")) EOUT << "dil2al: Unable to write " << contentfile << "in Tabbed_HTML_DIL_Hierarchy(), continuing as is\n";
	return "<PRE>\n"+dv.Output()+"</PRE>\n";
}

void Tabbed_FORM_DIL_Hierarchy_full(Detailed_Items_List & dilist, DIL_Visualize_with_FORM_Tabs & dv, const int maxdepth, String & expressions) {
  // Show full hierarchy with possible restriction to roots containing certain expressions
  StringList expressionlist(expressions,'+');
  int expressionnum = expressionlist.length()-1; // since an empty extra item is initialized in the StringList
  for (int i = 0; i<expressionnum; i++) expressionlist[i] = URI_unescape(expressionlist[i]);
#ifdef DEBUG_HIERARCHY_EXPRESSIONS
  for (int i = 0; i<expressionnum; i++) VOUT << "&&& expressionlist[" << i << "] = " << expressionlist[i] << '\n';
#endif
  if (dilist.list.head()) dilist.list.head()->Set_Semaphores(1); // initialize all as valid to show
  // if specific expressions are selected, test for their presence
  if (expressionnum>0) PLL_LOOP_FORWARD(DIL_entry,dilist.list.head(),1) {
    String * cptr = e->Entry_Text();
    if (!cptr) e->Set_Semaphore(0);
    else if (expressionlist.first_contained_in(*cptr)<0) e->Set_Semaphore(0);
  }
  // show the desired entries of the full DIL hierarchy
  if (hierarchysorting) {
    DIL_entry_ptr * dep = new DIL_entry_ptr[dilist.list.length()]; int n = 0;
    if (reversehierarchy) PLL_LOOP_FORWARD(DIL_entry,dilist.list.head(),1) {
      if ((e->Get_Semaphore()>0) && (!dilist.Entry_Has_Dependencies(e,true))) dep[n++] = e;
    } else PLL_LOOP_FORWARD(DIL_entry,dilist.list.head(),1) if ((e->Get_Semaphore()>0) && (!e->Has_Superiors(true))) dep[n++] = e;
    if (n>0) {
      qsort(dep,n,sizeof(DIL_entry_ptr),DIL_entry_target_date_qsort_compare);
      for (int i=0; i<n; i++) Show_DIL_Hierarchy(dep[i],dv,maxdepth);
    }
    delete[] dep;
  } else {
    if (reversehierarchy) PLL_LOOP_FORWARD(DIL_entry,dilist.list.head(),1) {
      if ((e->Get_Semaphore()>0) && (!dilist.Entry_Has_Dependencies(e,true))) Show_DIL_Hierarchy(e,dv,maxdepth);
    } else PLL_LOOP_FORWARD(DIL_entry,dilist.list.head(),1) if ((e->Get_Semaphore()>0) && (!e->Has_Superiors(true))) Show_DIL_Hierarchy(e,dv,maxdepth);
  }
}

String Tabbed_FORM_DIL_Hierarchy(String dilidstr, int maxdepth) {
// Visualize a DIL hierarchy starting at dilid with tabs indicating depth
// including HREFs and other HTML code, while HTML head and tail code are
// left to the content in which the extracted hierarchy is embedded.
// A comment is included that enables commenting out of process output simply
// by appending "<!-- " to the head code.
// Note that since standard output does not know which file the text may
// be embedded in, HREF file references are absolute. Post-processing may
// convert those to relative references.
// This output presents FORM check boxes and a "submit" button that extracts
// checked DIL IDs with the aid of dil2al form processing.
// There is also a "new hierarchy" button that uses the checked boxes as
// the top items in new hierarchies to visualize.
#ifdef DEBUG_HIERARCHY_EXPRESSIONS
  VOUT << "&&& Tabbed_FORM_DIL_Hierarchy: dilidstr = " << dilidstr << '\n';
#endif
  DIL_Visualize_with_FORM_Tabs dv;
  // 3. Get optional expressions that must occur in DIL entry content text
  String expressions(dilidstr.after('#'));
  if (!expressions.empty()) dilidstr = dilidstr.before('#');
  // 4. Get optional ContentFile reference
  String contentfile(dilidstr.after('c'));
  if (!contentfile.empty()) dilidstr = dilidstr.before('c');
  // dilidstr may now contain no, one or several DIL IDs
  Detailed_Items_List dilist;
  dilist.Get_All_DIL_ID_File_Parameters();
  dilist.Get_All_Topical_DIL_Parameters(true); // always get for FORM hierarchy
  if (!dilist.list.head()) return String("");
  if (dilidstr.empty()) { // full hierarchy
    VOUT << "No specific DIL ID, creating full hierarchy\n";
    // *** Is implemented in ~/doc/html/lists.html: maxdepth = 5; // reduced depth for full hierarchy
    Tabbed_FORM_DIL_Hierarchy_full(dilist,dv,maxdepth,expressions);
  } else {
	StringList dilidlist(dilidstr,'+'); int dilidnum = dilidlist.length();
	DIL_ID dilid;
	for (int i = 0; i<dilidnum; i++) {
		dilid = dilidlist[i];
		if (dilid.valid()) {
			Show_DIL_Hierarchy(dilist.list.head()->elbyid(dilid),dv,maxdepth);
			dv.Append("<HR>\n");
		}
	}
	if (!expressions.empty()) Tabbed_FORM_DIL_Hierarchy_full(dilist,dv,maxdepth,expressions);
  }
  if (!contentfile.empty()) if (!write_file_from_String(contentfile,dv.Output_Content(),"DIL Hierarchy Content")) EOUT << "dil2al: Unable to write " << contentfile << "in Tabbed_HTML_DIL_Hierarchy(), continuing as is\n";
  // prepare the FORM output
  String formoutputstr("<!-- comment out process output --><B>Maximum Depth = ");
  formoutputstr += String((long) maxdepth)+"</B>\n<FORM METHOD=\"GET\" ACTION=\"/cgi-bin/dil2al\"><INPUT type=\"hidden\" name=\"dil2al\" value=\"D\">\n<PRE>\n"+dv.Output()+"</PRE>\n<P>\n<INPUT type=\"radio\" name=\"processcmd\" value=\"extract\"> Extract\n<BR><INPUT type=\"radio\" name=\"processcmd\" value=\"newhierarchy\" checked> New Hierarchy with depth: <INPUT type=\"text\" name=\"maxdepth\" value=\"" + String((long) maxdepth) + "\" maxlength=5> and excerpt length: <INPUT type=\"text\" name=\"setpar__EQ__hierarchyexcerptlength\" value=\""+String((long) hierarchyexcerptlength)+"\" maxlength=5> <INPUT type=\"radio\" name=\"setpar\" value=\"nohierarchysorting\"";
  if (!hierarchysorting) formoutputstr += " checked";
  formoutputstr += "> unsorted <INPUT type=\"radio\" name=\"setpar\" value=\"hierarchysorting\"";
  if (hierarchysorting) formoutputstr += " checked";
  formoutputstr += "> sorted  <INPUT type=\"radio\" name=\"setpar\" value=\"noreversehierarchy\"";
  if (!reversehierarchy) formoutputstr += " checked";
  formoutputstr += "> top-down <INPUT type=\"radio\" name=\"setpar\" value=\"reversehierarchy hierarchyplanparse\"";
  if (reversehierarchy) formoutputstr += " checked";
  formoutputstr += "> bottom-up <INPUT type=\"checkbox\" name=\"expressions\" value=\"%40begin%3A%20PLAN%20DIL%20TEMPLATE\"";
  if (!expressions.empty()) formoutputstr += " checked";
  formoutputstr += "> PLAN entries only\n<BR><INPUT type=\"submit\" value=\"Process\"> <INPUT type=\"reset\"></FORM>\n";
  return formoutputstr;
}

bool DIL_Hierarchy_cmd(String dilidstr, int maxdepth) {
// visualize a DIL hierarchy
#ifdef DEBUG_HIERARCHY_EXPRESSIONS
  VOUT << "&&& DIL_Hierarchy_cmd: dilidstr = " << dilidstr << '\n';
#endif
  String hierarchyfile("");
  // 1. Get optional @f@ hierarchyfile reference
  if ((dilidstr.length()>=2) && (dilidstr[0]=='@')) {
    dilidstr.del(0,1);
    hierarchyfile = dilidstr.before('@');
    dilidstr = dilidstr.after('@');
  }
#ifdef DEBUG_HIERARCHY_EXPRESSIONS
  VOUT << "&&& DIL_Hierarchy_cmd: hierarchyfile = " << hierarchyfile << " dilidstr = " << dilidstr << '\n';
#endif
  // 2. Get optional type identifier
  if ((dilidstr.length()>=4) && (String(dilidstr.before(4))=="FORM")) {
    dilidstr = dilidstr.from(4);
#ifdef DEBUG_HIERARCHY_EXPRESSIONS
    VOUT << "&&& DIL_Hierarchy_cmd: type is FORM, dilidstr = " << dilidstr << '\n';
#endif
    if ((calledbyforminput) && (hierarchyfile.empty())) VOUT << "</PRE><!-- "; // clean up HTML output (dil2al processing output can still be inspected by looking at the HTML source)
    dilidstr = Tabbed_FORM_DIL_Hierarchy(dilidstr,maxdepth);
    // *** If I want to give hierarchy.html a proper head and tail then I
    //     can detect "if ((!hierarchyfile.empty()) && (!dilidstr.empty()))"
    //     here and prepend the head and append the tail to dilidstr if true.
  } else if ((dilidstr.length()>4) && (String(dilidstr.before(4))=="HTML")) {
    dilidstr = dilidstr.from(4);
    dilidstr = Tabbed_HTML_DIL_Hierarchy(dilidstr,maxdepth);
  } else dilidstr = Tabbed_DIL_Hierarchy(dilidstr,maxdepth);
  if (dilidstr.empty()) return false;
  if (!hierarchyfile.empty()) {
    VOUT << "Writing DIL Hierarchy to file " << hierarchyfile << " (<A HREF=\"file://" << hierarchyfile << "\">" << hierarchyfile << "</A>\n";
    return write_file_from_String(hierarchyfile,dilidstr,"DIL Hierarchy");
  }
  VOUT << dilidstr;
  return true;
}
