// note.cc
// Randal A. Koene, 20000304

#include "dil2al.hh"

void process_HTML(String & notestr) {
// Process note shorthand codes to HTML and fill in @tags@
	// line breaks
	notestr.gsub("\n","<BR>\n");
	// paragraphs
	notestr.gsub(BigRegex("<BR>\n\\(<BR>\n\\)+"),"\n<P>\n");
	// lists with `-' or `*' item indicators
	notestr.gsub(BigRegex("^[ 	]*-[ 	]+"),"<LI>");
	int lstart, lend;
	while ((lstart=notestr.index(BigRegex("^[ 	]*[*][ 	]+")))>=0) {
		notestr.at(BigRegex("^[ 	]*[*][ 	]+"),lstart)="<UL>\n<LI>";
		while ((lend=notestr.index("\n",lstart))>=0) {
			lstart = lend+1;
			if (notestr.contains(BigRegex("\n\\([ 	]+[^ 	]+\\|[ 	]*[*][ 	]+\\)"),lend)) {
				notestr.at(BigRegex("\n[ 	]*[*][ 	]+"),lend) = "\n<LI>";
			} else break;
		}
		if (lend<0) { lend = notestr.length(); notestr += "\n"; }
		notestr.at("\n",lend) = "\n</UL>\n";
	}
	// note that HTML references are already correct
	// tag definitions
	// NOVELTY tags
	long novcount = 0;
	lstart = -1;
	while ((lstart=notestr.index("@NOV@",lstart+1))>=0) {
		if ((lend=notestr.index("@/NOV@",lstart))>=0) {
			String tmp1,tmp2;
			novcount++;
			tmp1 = notestr.at(lstart+5,lend-(lstart+4));
			tmp2 = notestr.after(lend+6);
			notestr = notestr.before(lstart) + "<A NAME=\"NOVELTY-"+((curtime+'-')+String(novcount))+"\">[<B>N</B>]</A> "
					+ tmp1 + "<!-- @NOVELTY-"+((curtime+'-')+String(novcount))+"@ -->" + tmp2;
		} else EOUT << "dil2al: @NOV@ without matching @/NOV@ in process_HTML(), continuing as is\n";
	}
//*** add code here to replace @tags@ and tags defined in the configuration file
	// clean up
	notestr.gsub("<BR><BR>","<BR>");
	notestr.gsub("<BR><P>","<P>");
	notestr.gsub("<P><BR>","<P>");
	notestr.gsub("<BR>\n<P>","\n<P>");
	notestr.gsub("<P>\n<P>","<P>");
	notestr.gsub("<BR>\n<UL>","\n<UL>");
	notestr.gsub("<BR>\n<LI>","\n<LI>");
	notestr.gsub("<BR>\n</UL>","\n</UL>");
}

int pre_process_note(String notefile, String notedst, String typestr, String & notestr, String & notedststr, bool & isnew) {
	if (!read_file_into_String(notefile,notestr)) return -1;
	if (notestr=="") { // if note is empty, don't do anything, but return true
		if (verbose) VOUT << "Note is empty, no change\n";
		return 0;
	}
	if (verbose) VOUT << "Processing destination file as " << typestr << '\n';
	process_HTML(notestr);
	// read note destination into memory
	if (!read_file_into_String(isnew,notedst,notedststr)) return -1;
	return 1;
}

int post_process_note(String notedst, String & notestr, String & notedststr, int insertindex, bool isnew) {
	// insert note into notedst
	if (insertindex>=0) {
		String c = notedststr.at(insertindex,1);
		notedststr.at(insertindex,1) = notestr+c;
	} else {
		insertindex = notedststr.length();
		notedststr += notestr;
	}
	// store and backup
	if (!write_file_from_String(notedst,notedststr,"Note destination",isnew)) return -1;
	return insertindex;
}

int process_note_TL(String notefile, String notedst) {
// A task log entry will be added to the current TL chunk, or to the TL chunk
// immediately preceding a @INSERT-TL-NOTE@ tag, or optionally to a new TL chunk,
// possibly in a new TL section.
	String notestr, tl; bool isnew; int res;
	if ((res = pre_process_note(notefile,notedst,"Task Log",notestr,tl,isnew))<=0) return res;
	// search for <!-- @INSERT-TL-NOTE@ --> in TL
	int tlinsertloc; bool comparetimes = true;
	if ((tlinsertloc = tl.index("<!-- @INSERT-TL-NOTE@ -->"))>=0) {
		tlinsertloc -= tl.length();
		comparetimes = false;
	}
	// determine whether to add a new Task Log chunk
	String chunkid;
	if ((chunkid=decide_add_TL_chunk(tl,tlinsertloc,comparetimes))=="") return -1;
	// HTML process entry (and fill in @tag@ codes)
	process_HTML(notestr);
	// add entry to Task Log chunk
	newTLID = add_TL_chunk_or_entry(tl,notestr,false,chunkid,tlinsertloc);
	if (newTLID=="") {
		EOUT << "dil2al: Unable to add new Task Log entry in process_note_TL()\n";
		return -1;
	}
	return tlinsertloc;
}

int process_note_HTML(String notefile, String notedst) {
	String notestr, notedststr; bool isnew; int res;
	if ((res = pre_process_note(notefile,notedst,"HTML",notestr,notedststr,isnew))<=0) return res;
	// find a possible <!-- @INSERT-AT:<tag>@ -->
	int insertindex = -1;
	String inserttag = notestr.at(BigRegex("[<]!--[ 	]*@INSERT-AT:[^@]+@[ 	]*--[>]"));
	if (inserttag!="") {
		inserttag = inserttag.after("INSERT-AT:");
		inserttag = inserttag.before("@",-1);
		insertindex = notedststr.index(BigRegex("[<]!--[ 	]*@"+inserttag+"@[ 	]*--[>]"));
	}
	// find a possible <!-- @INSERT-TL-NOTE@ -->
	if (insertindex<0) insertindex = notedststr.index(BigRegex("[<]!--[ 	]*@INSERT-TL-NOTE@[ 	]*--[>]"));
	// find </BODY>
	if (insertindex<0) insertindex = notedststr.index("</BODY>");
	if (insertindex<0) EOUT << "dil2al: Note destination " << notedst << " missing </BODY> tag, continuing\n";
	// insert note into notedst
	return post_process_note(notedst,notestr,notedststr,insertindex,isnew);
}

int process_note_TeX(String notefile, String notedst) {
	String notestr, notedststr; bool isnew; int res;
	if ((res = pre_process_note(notefile,notedst,"TeX",notestr,notedststr,isnew))<=0) return res;
	// find a possible % <!-- @INSERT-AT:<tag>@ -->
	int insertindex = -1;
	String inserttag = notestr.at(BigRegex("[<]!--[ 	]*@INSERT-AT:[^@]+@[ 	]*--[>]"));
	if (inserttag!="") {
		inserttag = inserttag.after("INSERT-AT:");
		inserttag = inserttag.before("@",-1);
		insertindex = notedststr.index(BigRegex("%[\n]*[<]!--[ 	]*@"+inserttag+"@[ 	]*--[>]"));
	}
	// find a possible % <!-- @INSERT-TL-NOTE@ -->
	if (insertindex<0) insertindex = notedststr.index(BigRegex("%[\n]*[<]!--[ 	]*@INSERT-TL-NOTE@[ 	]*--[>]"));
	// find \end{document}
	if (insertindex<0) insertindex = notedststr.index("\\end{document}");
	// find \endinput
	if (insertindex<0) insertindex = notedststr.index("\\endinput");
	if (insertindex<0) EOUT << "dil2al: Note destination " << notedst << " missing \\end{document} and \\endinput tags, continuing\n";
	// convert to TeX
	notestr.gsub(BigRegex("[<][Bb][Rr]\\([ 	]+[^>][>]\\|[>]\\)"),"\\\\"); // <BR>
	notestr.gsub(BigRegex("[<][Pp]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\n\n"); // <P>
	notestr.gsub(BigRegex("[<][Uu][Ll]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\begin{itemize}"); // <UL>
	notestr.gsub(BigRegex("[<]/[Uu][Ll]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\end{itemize}"); // </UL>
	notestr.gsub(BigRegex("[<][Oo][Ll]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\begin{enumerate}"); // <OL>
	notestr.gsub(BigRegex("[<]/[Oo][Ll]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\end{enumerate}"); // </OL>
	notestr.gsub(BigRegex("[<][Ll][Ii]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\item "); // <LI>
	notestr.gsub(BigRegex("[<][Hh]1\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\section{"); // <H1>
	notestr.gsub(BigRegex("[<][Hh]2\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\subsection{"); // <H2>
	notestr.gsub(BigRegex("[<][Hh]3\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\subsubsection{"); // <H3>
	notestr.gsub(BigRegex("[<][Hh]4\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\paragraph{"); // <H3>
	notestr.gsub(BigRegex("[<]/[Hh][1-4]\\([ 	]+[^>]*[>]\\|[>]\\)"),"}"); // </H1>,</H2>,</H3>,</H4>
	notestr.gsub(BigRegex("[<][Hh][Rr]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\hline "); // <HR>
	notestr.gsub(BigRegex("[<]!--"),"% <!--"); // <!-- -->
	notestr.gsub(BigRegex("[<][Tt][Aa][Bb][Ll][Ee][ 	]*[^>]*[>]"),"\\begin{tabular}{???}"); // <TABLE>
	notestr.gsub(BigRegex("[<]/[Tt][Aa][Bb][Ll][Ee][ 	]*[^>]*[>]"),"\\end{tabular}"); // </TABLE>
	notestr.gsub(BigRegex("[<][Tt][Rr][ 	]*[^>]*[>]"),"\\\\\n"); // <TR>
	notestr.gsub(BigRegex("[<]/[Tt][Rr][ 	]*[^>]*[>]"),""); // <TR>
	notestr.gsub(BigRegex("[<][Tt][Dd][ 	]*[^>]*[>]")," & "); // <TD>
	notestr.gsub(BigRegex("[<]/[Tt][Dd][ 	]*[^>]*[>]"),""); // <TD>
	notestr.gsub(BigRegex("[<][Tt][Hh][ 	]*[^>]*[>]")," & {\\bf "); // <TH>
	notestr.gsub(BigRegex("[<]/[Tt][Hh][ 	]*[^>]*[>]"),"}"); // <TH>
	notestr.gsub(BigRegex("[<][Bb]\\([ 	]+[^>]*[>]\\|[>]\\)"),"{\\bf "); // <B>
	notestr.gsub(BigRegex("[<][Ii]\\([ 	]+[^>]*[>]\\|[>]\\)"),"{\\em "); // <I>
	notestr.gsub(BigRegex("[<][Uu]\\([ 	]+[^>]*[>]\\|[>]\\)"),"\\underline{"); // <U>
	notestr.gsub(BigRegex("[<]/[BbIiUu]\\([ 	]+[^>]*[>]\\|[>]\\)"),"}"); // </B>,</I>,</U>
	notestr.gsub(BigRegex("[<][Ee][Mm]\\([ 	]+[^>]*[>]\\|[>]\\)"),"{\\em "); // <EM>
	notestr.gsub(BigRegex("[<]/[Ee][Mm]\\([ 	]+[^>]*[>]\\|[>]\\)"),"}"); // </EM>
	notestr.gsub(BigRegex("[<][Ss][Tt][Rr][Oo][Nn][Gg][ 	]*[^>]*[>]"),"{\\bf "); // <STRONG>
	notestr.gsub(BigRegex("[<]/[Ss][Tt][Rr][Oo][Nn][Gg][ 	]*[^>]*[>]"),"}"); // </STRONG>
	// <A HREF="http://the-reference-url/">the-reference-text</A>
	// <A NAME="the-reference-name-tag">the-reference-anchor</A>
	int i = 0, j = 0, k;
	while (i>=0) {
		i = notestr.index(BigRegex("[<][Aa][ 	]+[^>]*\\([Hh][Rr][Ee][Ff]\\|[Nn][Aa][Mm][Ee]\\)[ 	]*=[ 	]*[^>]*[>].*[<]/[Aa][ 	]*[^>]*[>]"),j);
		if (i>=0) {
			k = notestr.index(">",i) + 1;
			j = notestr.index(BigRegex("[<]/[Aa][ 	]*[^>]*[>]"),i);
			if (k<j) {
				String tmpstr = "</A><!--\n"+notestr.at(k,j-k)+'\n'+notestr.after(BigRegex("[<]/[Aa][ 	]*[^>]*[>]"),j);
				notestr = notestr.before(BigRegex("[<]/[Aa][ 	]*[^>]*[>]"),j);
				notestr += tmpstr;
				//notestr.at(BigRegex("[<]/[Aa][ 	]*[^>]*[>]"),j)="</A><!--\n"+notestr.at(k,j-k)+'\n';
			}
			String tmpstr = "% -->"+notestr.from(i);
			notestr = notestr.before(i);
			notestr += tmpstr;
			//notestr.at(i,1)="% --><";
		}
	}
	// other <...> tags
	i = 0; j = 0;
	while (i>=0) {
		i = notestr.index(BigRegex("[<][^>]*[>]"),j);
		if (i>=0) {
			j = notestr.index(">",i);
			String tmpstr = "% "+notestr.at(i,(j-i)+1)+"\n"+notestr.after(j);
			notestr = notestr.before(i)+tmpstr;
			//notestr.at(j,1) = ">\n";
			//notestr.at(i,1) = "% <";
		}
	}
	notestr.gsub("&lt;","<"); // &lt;
	notestr.gsub("&gt;",">"); // &gt;
	notestr.gsub("&amp;","\\&"); // &amp;
	notestr.gsub("&nbsp;","\\relax"); // &nbsp;
	// clean up
	notestr.gsub("\n\n","\n");
	notestr.gsub(BigRegex("[ 	]+\n"),"\n");
	// insert note into notedst
	return post_process_note(notedst,notestr,notedststr,insertindex,isnew);
}

int process_note_CC(String notefile, String notedst) {
	String notestr, notedststr; bool isnew; int res;
	if ((res = pre_process_note(notefile,notedst,"C++",notestr,notedststr,isnew))<=0) return res;
	// find a possible // <!-- @INSERT-AT:<tag>@ -->
	int insertindex = -1;
	String inserttag = notestr.at(BigRegex("[<]!--[ 	]*@INSERT-AT:[^@]+@[ 	]*--[>]"));
	if (inserttag!="") {
		inserttag = inserttag.after("INSERT-AT:");
		inserttag = inserttag.before("@",-1);
		insertindex = notedststr.index(BigRegex("//[\n]*[<]!--[ 	]*@"+inserttag+"@[ 	]*--[>]"));
	}
	// find a possible // <!-- @INSERT-TL-NOTE@ -->
	if (insertindex<0) insertindex = notedststr.index(BigRegex("//[\n]*[<]!--[ 	]*@INSERT-TL-NOTE@[ 	]*--[>]"));
	if ((insertindex<0) && (verbose))  VOUT << "No specific insertion location in " << notedst << ", appending note to end\n";
	// convert to C++
	notestr.gsub(BigRegex("[<][Bb][Rr][ 	]*[^>][>]\n?"),"\n"); // <BR>
	notestr.gsub(BigRegex("\n?[<][Pp][ 	]*[^>]*[>]\n?"),"\n\n"); // <P>
	notestr.gsub(BigRegex("[<][Uu][Ll][ 	]*[^>]*[>]"),""); // <UL>
	notestr.gsub(BigRegex("[<]/[Uu][Ll][ 	]*[^>]*[>]"),""); // </UL>
	notestr.gsub(BigRegex("[<][Oo][Ll][ 	]*[^>]*[>]"),""); // <OL>
	notestr.gsub(BigRegex("[<]/[Oo][Ll][ 	]*[^>]*[>]"),""); // </OL>
	notestr.gsub(BigRegex("[<][Ll][Ii][ 	]*[^>]*[>]"),"- "); // <LI>
	// <A HREF="http://the-reference-url/">the-reference-text</A>
	// <A NAME="the-reference-name-tag">the-reference-anchor</A>
	int i = 0, j = 0, k;
	while (i>=0) {
		i = notestr.index(BigRegex("[<][Aa][ 	]+[^>]*\\([Hh][Rr][Ee][Ff]\\|[Nn][Aa][Mm][Ee]\\)[ 	]*=[ 	]*[^>]*[>].*[<]/[Aa][ 	]*[^>]*[>]"),j);
		if (i>=0) {
			j = notestr.index(BigRegex("//[^\n]*"),i-notestr.length()); // check if already // commented
			if (j<0) {
				j = notestr.index("/*",i-notestr.length());
				if (j>=0) {
					k = notestr.index("*/",i-notestr.length());
					if (k>j) j = -1;
				}
			}
			if (j<0) {
				j = notestr.index(BigRegex("[<]/[Aa][ 	]*[^>]*[>]"),i);
				j = notestr.index(">",j);
				String tmpstr = "/* "+notestr.at(i,(j-i)+1)+" */"+notestr.after(j);
				notestr = notestr.before(i)+tmpstr;
				//notestr.at(j,1) = "> */";
				//notestr.at(i,1) = "/* <";
			}
		}
	}
	// other <...> tags
	i = 0; j = 0;
	while (i>=0) {
		i = notestr.index(BigRegex("[<][^>]*[>]"),j);
		if (i>=0) {
			j = notestr.index(BigRegex("//[^\n]*"),i-notestr.length()); // check if already // commented
			if (j<0) {
				j = notestr.index("/*",i-notestr.length());
				if (j>=0) {
					k = notestr.index("*/",i-notestr.length());
					if (k>j) j = -1;
				}
			}
			if (j<0) { // convert tag to comment
				j = notestr.index(">",i);
				String tmpstr = "/* "+notestr.at(i,(j-i)+1)+" */"+notestr.after(j);
				notestr = notestr.before(i)+tmpstr;
				//notestr.at(j,1) = "> */";
				//notestr.at(i,1) = "/* <";
			}
		}
	}
	notestr.gsub("&lt;","<"); // &lt;
	notestr.gsub("&gt;",">"); // &gt;
	notestr.gsub("&amp;","&"); // &amp;
	notestr.gsub("&nbsp;"," "); // &nbsp;
	// clean up
	notestr.gsub(BigRegex("[ 	]+\n"),"\n");
	// insert note into notedst
	return post_process_note(notedst,notestr,notedststr,insertindex,isnew);
}

int process_note_generic(String notefile, String notedst) {
	String notestr, notedststr; bool isnew; int res;
	if ((res = pre_process_note(notefile,notedst,"generic text",notestr,notedststr,isnew))<=0) return res;
	// find a possible <!-- @INSERT-AT:<tag>@ -->
	int insertindex = -1;
	String inserttag = notestr.at(BigRegex("[<]!--[ 	]*@INSERT-AT:[^@]+@[ 	]*--[>]"));
	if (inserttag!="") {
		inserttag = inserttag.after("INSERT-AT:");
		inserttag = inserttag.before("@",-1);
		insertindex = notedststr.index(BigRegex("[<]!--[ 	]*@"+inserttag+"@[ 	]*--[>]"));
	}
	// find a possible <!-- @INSERT-TL-NOTE@ -->
	if (insertindex<0) insertindex = notedststr.index(BigRegex("[<]!--[ 	]*@INSERT-TL-NOTE@[ 	]*--[>]"));
	if ((insertindex<0) && (verbose))  VOUT << "No specific insertion location in " << notedst << ", appending note to end\n";
	// convert to generic text
	notestr.gsub(BigRegex("[<][Bb][Rr][ 	]*[^>][>]\n?"),"\n"); // <BR>
	notestr.gsub(BigRegex("\n?[<][Pp][ 	]*[^>]*[>]\n?"),"\n\n"); // <P>
	notestr.gsub(BigRegex("[<][Uu][Ll][ 	]*[^>]*[>]"),""); // <UL>
	notestr.gsub(BigRegex("[<]/[Uu][Ll][ 	]*[^>]*[>]"),""); // </UL>
	notestr.gsub(BigRegex("[<][Oo][Ll][ 	]*[^>]*[>]"),""); // <OL>
	notestr.gsub(BigRegex("[<]/[Oo][Ll][ 	]*[^>]*[>]"),""); // </OL>
	notestr.gsub(BigRegex("[<][Ll][Ii][ 	]*[^>]*[>]"),"- "); // <LI>
	notestr.gsub("&lt;","<"); // &lt;
	notestr.gsub("&gt;",">"); // &gt;
	notestr.gsub("&amp;","&"); // &amp;
	notestr.gsub("&nbsp;"," "); // &nbsp;
	// clean up
	notestr.gsub(BigRegex("[ 	]+\n"),"\n");
	// insert note into notedst
	return post_process_note(notedst,notestr,notedststr,insertindex,isnew);
}

bool process_note(String notefile, String notedst) {
	const int LLEN = 10240;
	char lbuf[LLEN];
	// determine destination file type
	int filetype = 0; // generic type
	if (notedst==tasklog) {
		filetype = 1; // Task Log type
		if ((notedst = get_TL_head())=="") return false;
	} else if (notedst.matches(BigRegex(".*[.][Hh][Tt][Mm][Ll]?\\([---_.].*\\)?"))) filetype = 2; // HTML type
	else if (notedst.matches(BigRegex(".*[.][Tt][Ee][Xx]\\([---_.].*\\)?"))) filetype = 3; // TeX type
	else if (notedst.matches(BigRegex(".*[.]\\([Cc][Cc]|[Hh][Hh]\\)\\([---_.].*\\)?"))) filetype = 4; // C++ type
	else if (askprocesstype) {
		filetype = -1;
		while ((filetype<0) || (filetype>4)) {
			cout << "Destination file type (0=generic,1=Task Log,2=HTML,3=TeX,4=C++): ";
			cin.getline(lbuf,LLEN);
			String ftstr = lbuf;
			if (ftstr.matches(BRXint)) filetype = atoi((const char *) ftstr);
		}
	}
	// process and insert note in destination file
	long res;
	switch (filetype) {
		case 0: res=process_note_generic(notefile,notedst); break;
		case 1: res=process_note_TL(notefile,notedst); break;
		case 2: res=process_note_HTML(notefile,notedst); break;
		case 3: res=process_note_TeX(notefile,notedst); break;
		case 4: res=process_note_CC(notefile,notedst); break;
		default: {
				EOUT << "dil2al: Unknown destination file type in process_note()\n";
				return false;
			}
	}
	if (res<0) {
		EOUT << "dil2al: Unable to process destination file in process_note()\n";
		return false;
	}
	// update and open notedst in an editor
	bool updateineditor = (updatenoteineditor == UNIE_YES);
	if (updatenoteineditor==UNIE_ASK) {
		cout << "\nUpdate and open " << notedst << " in editor? (Y/n) ";
		cin.getline(lbuf,LLEN);
		updateineditor = (!((lbuf[0]=='n') || (lbuf[0]=='N')));
	}
	if (updateineditor) {
		String uniecmd = updatenoteineditorcmd;
		uniecmd.gsub("@res@",String(res));
		if (filetype==1) notedst=tasklog; // revert to symbolic link in case new Task Log section was added
		uniecmd.gsub("@notedst@",notedst);
		if (System_Call(uniecmd)<0) EOUT << "dil2al: Unable to update and open " << notedst << " in editor in process_note(), continuing\n";
	}
	return true;
}

bool make_note() {
  const int LLEN = 65525; // was 10240
  char lbuf[LLEN];
  int q,res = -1;
  // open an editor for a plain text entry
  String noteinit;
  if (suggestnameref) {
    noteinit = "<A NAME=\"TL-ref-" + curtime + "\" HREF=\"@TLURL@#@TLNEXTENTRY@\">_</A>";
    if (verbose) VOUT << "Note: If destination is Task Log and suggested reference is not altered,\nthen " << noteinit << " will be cleaned up automatically.\n";
  }
  if (!prepare_temporary_file(notetmpfile,noteinit)) return false;
  if (System_Call(editor+" "+notetmpfile)<0) return false;
  // refresh curtime to avoid misrepresentations due to constantly open note editing window
  curtime = time_stamp("%Y%m%d%H%M");
  // request destination of note
  if (useansi) cout << ANSI_UNDERLINE_ON; // underline on
  cout << "Destination of note (default = Task Log)\n";
  if (useansi) cout << ANSI_UNDERLINE_OFF; // underline off
  // get quick-chooser options from configuration file
  for (int i=0; i<quicknotedstnum; i++) cout << i << ' ' << quicknotedsttitle[i] << quicknotedescr[i] << '\n';
  if (useansi) cout << ANSI_BOLD_ON; // bold on
  cout << "or enter file path: ";
  if (useansi) cout << ANSI_BOLD_OFF; // bold off
  cin.getline(lbuf,LLEN);
  String notedst = lbuf;
  if (notedst == "") {
    notedst = tasklog;
    cout << "notedst = " << notedst << '\n';
    if (suggestnameref) {
      // clean up unnecessary (self-)reference NAME tag
      ifstream ntf(notetmpfile);
      if (!ntf) EOUT << "dil2al: Unable to open " << notetmpfile << " for removal of spurious NAME tag in make_note(), continuing as is\n";
      else {
	ofstream ntfnew(notetmpfile+".tlref_cleaned");
	if (!ntfnew) {
	  EOUT << "dil2al: Unable to create " << notetmpfile << ".tlref_cleaned in make_note(), continuing as is\n";
	  ntf.close();
	} else {
	  if ((res=copy_until_line(&ntf,&ntfnew,noteinit,lbuf,LLEN))==1) {
	    String noteline(lbuf); noteline.del(noteinit);
	    ntfnew << noteline << '\n';
	    ntfnew << ntf.rdbuf();
	    ntf.close(); ntfnew.close();
	    if (rename(notetmpfile+".tlref_cleaned",notetmpfile)<0) EOUT << "dil2al: Unable to rename " << notetmpfile << ".tlref_cleaned to " << notetmpfile << "\nin make_note(), continuing as is\n";
	  } else {
	    ntf.close(); ntfnew.close();
	    if (res<0) EOUT << "dil2al: Unable to remove unnecessary NAME tag in make_note(), continuing as is\n";
	    if (unlink(notetmpfile+".tlref_cleaned")<0) EOUT << "dil2al: Unable to remove " << notetmpfile << ".tlref_cleaned in make_note(), continuing as is\n";
	  }
	}
      }
    }
  } else {
    // default destination document title is file name
    String notedsttitle = notedst; notedsttitle.gsub(BigRegex(".*/"),"");
    // obtain quick-chooser destinations
    if (notedst.matches(BRXint)) {
      q = atoi((const char *) notedst);
      if ((q>=0) && (q<quicknotedstnum)) {
	notedst = quicknotedst[q];
	notedsttitle = quicknotedsttitle[q];
      } else {
	EOUT << "dil2al: Selection " << q << " is not a predefined note destination\n";
	return false;
      }
    }
    // if not task log, request task log reference line, suggest reference to note
    if (notedst[0]!='/') notedst.prepend(homedir);
    if (verbose) VOUT << "Note destination to process: " << notedst << '\n';
    String tlentryinit = "<A HREF=\""+relurl(get_TL_head(),notedst);
    ifstream ntf(notetmpfile);
    if (!ntf) { EOUT << "dil2al: Unable to open " << notetmpfile << " in make_note()\n"; return false; }
    // this NAME could be the suggested one, or one modified/set manually
    if (find_line(&ntf,"[<][Aa][ 	]+[^>]*[Nn][As][Mm][Ee]=[ 	]*\"[^>]+[>]",lbuf,LLEN)) {
      String tlref(lbuf); tlref = tlref.after(BigRegex("[<][Aa][ 	]+[^>]*[Nn][As][Mm][Ee]=[ 	]*\""));
      tlentryinit = tlentryinit + '#' +tlref.before("\"");
    }
    ntf.close();
    tlentryinit +="\">("+notedsttitle+")</A>";
    if (!prepare_temporary_file(tlentrytmpfile,tlentryinit)) return false;
    if (verbose) VOUT << "Task Log entry referring to note (if any)...\n";
    if (System_Call(editor+" "+tlentrytmpfile)<0) return false;
    newTLID = ""; // clear to test if properly generated
    if (!process_note(tlentrytmpfile,tasklog)) return false;
    if (newTLID=="") {
      if (verbose) VOUT << "No new Task Log entry ID, perhaps entry was empty (removing @TLURL@ and\n@TLNEXTENTRY@ references)\n";
      // remove HREF="@TLURL@#@TLNEXTENTRY@" references from notedst
      ntf.open(notetmpfile);
      if (!ntf) EOUT << "dil2al: Unable to remove spurious @TLURL@ and @TLNEXTENTRY@ references in\nmake_note(), continuing as is\n";
      else {
	ofstream ntfnew(notetmpfile+".tlurl_cleaned");
	if (!ntfnew) EOUT << "dil2al: Unable to creaete " << notetmpfile << ".tlurl_cleaned in make_note(),\ncontinuing as is\n";
	else {
	  while (ntf) {
	    if ((res=copy_until_line(&ntf,&ntfnew,"@TLURL@|@TLNEXTENTRY@",lbuf,LLEN))==1) {
	      tlentryinit = lbuf;
	      tlentryinit.gsub(BigRegex("[<][Aa][ 	]+[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\"[^\"]*\\(@TLURL@\\|@TLNEXTENTRY@\\)[^\"]*\"[ 	]*[>][^<]*[<]/[Aa][>]"),"");
	      tlentryinit.gsub(BigRegex("[ 	]+[Hh][Rr][Ee][Ff][ 	]*=[ 	]*\"[^\"]*\\(@TLURL@\\|@TLNEXTENTRY@\\)[^\"]*\"[ 	]*"),"");
	      ntfnew << tlentryinit << '\n';
	    } else break;
	  }
	  ntfnew.close();
	  if (res<0) EOUT << "dil2al: Unable to remove spurious @TLURL@ and @TLNEXTENTRY@ references in\nmake_note(), continuing as is\n";
	  else if (rename(notetmpfile+".tlurl_cleaned",notetmpfile)<0) EOUT << "dil2al: Unable to rename " << notetmpfile << ".tlurl_cleaned to " << notetmpfile << "\nin make_note(), continuing as is\n";
	}
	ntf.close();
      }
    } else {
      // parse notedst to fill in @TLURL@ and @TLNEXTENTRY@
      ntf.open(notetmpfile);
      if (!ntf) EOUT << "dil2al: Unable to fill in @TLURL@ and @TLNEXTENTRY@ references in\nmake_note(), continuing as is\n";
      else {
	ofstream ntfnew(notetmpfile+".tlurl");
	if (!ntfnew) EOUT << "dil2al: Unable to create " << notetmpfile << ".tlurl in make_note(),\ncontinuing as is\n";
	else {
	  String tlurl(relurl(notedst,get_TL_head()));
	  while (ntf) {
	    if ((res=copy_until_line(&ntf,&ntfnew,"@TLURL@|@TLNEXTENTRY@",lbuf,LLEN))==1) {
	      tlentryinit = lbuf;
	      tlentryinit.gsub("@TLURL@",tlurl);
	      tlentryinit.gsub("@TLNEXTENTRY@",newTLID);
	      ntfnew << tlentryinit << '\n';
	    } else break;
	  }
	  ntfnew.close();
	  if (res<0) EOUT << "dil2al: Unable to fill in @TLURL@ and @TLNEXTENTRY@ references in\nmake_note(), continuing as is\n";
	  else if (rename(notetmpfile+".tlurl",notetmpfile)<0) EOUT << "dil2al: Unable to rename " << notetmpfile << ".tlurl to " << notetmpfile << "\nin make_note(), continuing as is\n";
	}
	ntf.close();
      }
    }
  }
  return process_note(notetmpfile,notedst);
}
