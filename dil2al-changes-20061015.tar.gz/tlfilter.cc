// tlfilter.cc
// Randal A. Koene, 20000304

#include "dil2al.hh"

bool filter_TL_by_AL() {
  cerr << "dil2al Error: The filter_TL_by_AL() function is not yet implemented\n";
  exit(1);
  return false;
}

bool generate_TL_keyword_index() {
// keywords can be created with a special tag that you insert anywhere
// in a task log entry, or anywhere in HTML or TeX documents or source code or
// plain text, plus in the dil2al configuration file
  cerr << "dil2al Error: The generate_TL_keyword_index() function is not yet implemented\n";
  exit(1);
  return false;
}

bool search_TL(String searchstr) {
// searchstr is a regexp
  cerr << "dil2al Error: The search_TL() function is not yet implemented\n";
  exit(1);
  return false;
}

bool extract_paper_novelties(String fname, String paperplanurl, ostream & ostr) {
// searches a document for <A NAME="NOVELTY-some-id">[<B>N</B>]</A>/<!-- @NOVELTY-some-id@ -->
// tags and returns the items between the tags
	String fcont;
	if (!read_file_into_String(fname,fcont)) {
		EOUT << "dil2al: Unable to read file " << fname << " in extract_paper_novelties()\n";
		return false;
	}
	_BIGSTRING_ITERATOR i=-1;
	while ((i=fcont.index(BigRegex("[<]A[ 	]+[Nn][Aa][Mm][Ee][ 	]*=[ 	]*\"NOVELTY-[^\"]*\"[>]"),i+1))>=0) {
		_BIGSTRING_ITERATOR ii = fcont.index("\">",i); // find end of ID
		if (ii>=0) {
			String nid;
			nid = fcont.at(i,ii-i);
			nid = nid.after("\"",-1);
			ii = fcont.index("</A>",ii); // find start of content
			if (ii>=0) {
				BigRegex en("[<]!--[ 	]+@"+RX_Search_Safe(nid)+"@[ 	]+\\([^>]*\\)--[>]");
				_BIGSTRING_ITERATOR iii = fcont.index(en,ii); // get end marker
				if (iii>=0) {
					String cstr, istr, lstr, sstr;
					if (en.sublen(1)>0) { // extract possible qualifying and quantifying information
						String qqinfo = fcont.at(en.subpos(1),en.sublen(1));
						const BigRegex qqi("@CONTEXT:[ 	]*\\([^@]*\\)@[ 	]*@IMP:[ 	]*\\([^@]*\\)@[ 	]*@LEN:[ 	]*\\([^@]*\\)@[ 	]*@SECTION:[ 	]*\\([^@]*\\)@");
						if (qqinfo.index(qqi)>=0) {
							cstr = qqinfo.at(qqi.subpos(1),qqi.sublen(1));
							istr = qqinfo.at(qqi.subpos(2),qqi.sublen(2));
							lstr = qqinfo.at(qqi.subpos(3),qqi.sublen(3));
							sstr = qqinfo.at(qqi.subpos(4),qqi.sublen(4));
						}
					}
					String ncont;
					ncont = fcont.at(ii+4,iii-(ii+4)); // get content
					ncont.gsub(BigRegex("[<][^>]*[>]"),""); // clean up content
					String fshortname = fname.after("/",-1);
					if (fshortname == "") fshortname = fname;
					ostr << "<LI>" << ncont << " [<A HREF=\"" << relurl(paperplanurl,fname) << '#' << nid << "\">" << fshortname << '#' << nid << "</A>]<BR>\n"; // return content
//*** selection criteria suggestions can be automatically generated (see DIL#20000310091924.1)
					ostr << "(<B>Context</B>: " << cstr << ", <B>Importance</B>: " << istr << ", <B>Length</B>: " << lstr << ", <B>Section</B>: " << sstr << ")\n"; // add selection criteria
				}
			}
		}
	} // else may already have HREF reference to paper in which it is included
	return true;
}

bool cmdline_extract_paper_novelties(String filepaper) {
// Commandline interface to the extraction of NOVELTY tagged items
	bool res;
	String fname, paperplanurl;
	fname = filepaper.before("+");
	if (fname == "") {
		fname = filepaper;
		paperplanurl = homedir+"doc/tex/somepaper/somepaper.html"; // dummy URL
		res = extract_paper_novelties(fname,paperplanurl,cout);
	} else {
		paperplanurl = filepaper.after("+");
		if (paperplanurl == "") {
			paperplanurl = homedir+"doc/tex/somepaper/somepaper.html"; // dummy URL
			res = extract_paper_novelties(fname,paperplanurl,cout);
		} else {
			if (paperplanurl[0]!='/') paperplanurl.prepend(homedir);
			ofstream ostr(paperplanurl+".new");
			if (!ostr) {
				EOUT << "dil2al: Unable to create " << paperplanurl << ".new in cmdline_extract_paper_novelties()\n";
				return false;
			}
			ifstream istr(paperplanurl);
			bool isnew = (!istr);
			if (!isnew) ostr << istr.rdbuf(); // copy existing content (without regard to a possible </BODY> tag)
			istr.close();
			res = extract_paper_novelties(fname,paperplanurl,ostr);
			ostr.close();
			if (!backup_and_rename(paperplanurl,"Paper Plan",isnew)) return false;
		}
	}
	return true;
}
