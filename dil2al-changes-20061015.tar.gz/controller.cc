// controller.cc
// Randal A. Koene, 20000304

#include "dil2al.hh"

String chunk_controller(String controllercmd) {
// Called timechunk minutes after starting a task chunk
// (e.g. via at-jobs or a timer daemon, which could be
// constructed as an AfterStep Wharf applet).
// It can also be called before timechunk minutes have
// passed if the chunk is stopped early.
// As previous chunks are closed with stop_TL_chunk() where
// necessary with options C,S or T, AL updating options
// determine if and how the current AL and closed chunk's DIL
// entry should be updated, and the corresponding update is done.
	const int LLEN = 10240;
	char lbuf[LLEN];
	// check if audio-visual flag is to be made noticable
	if (showflag) {
		cout << "\a";
		if (flagcmd!="") {
			if (System_Call(flagcmd)<0) EOUT << "dil2al: Unable to show visual flag in chunk_controller(), continuing\n";
		}
	}
	// show next AL item(s) (may involve recomputing)
//*** recomputation of AL not yet included
#ifdef DEBUG
	cout << "dil2al: DEBUG - Recomputation of ALs in chunk_controller() not yet implemented\n";
#endif
	// offer opportunity to make a Task Log entry
	bool madenote = false;
	chunkcreated = false; // reset process variable
	if (useansi) cout << ANSI_BOLD_ON; // bold on
	auto_interactive(controllercmd,"Make Note/Task Log entry? (y/N) ",lbuf,LLEN);
	if (useansi) cout << ANSI_BOLD_OFF; // bold off
	if ((lbuf[0]=='y') || (lbuf[0]=='Y')) {
		// make Task Log entry
		if (!make_note()) EOUT << "dil2al: Unable to make note in chunk_contorller(), continuing as is\n";
		madenote = true;
	}
	// offer controller options
	lbuf[0]='\0'; String chunkid;
	while (lbuf[0]=='\0') {
		String message = "\nOptions:\n[C]ontinue Task Chunk if Time Remaining else Start New Task Chunk\n";
		if (!chunkcreated) message += "[S]tart New Task Chunk (new task context)\n";
		message += "S[t]op Task Chunk (pause list tasks)\nE[x]it Retaining Current State (ignore list suggestions)\n";
		if (useansi) cout << ANSI_BOLD_ON; // bold on
		auto_interactive(controllercmd,message,lbuf,LLEN);
		if (useansi) cout << ANSI_BOLD_OFF; // bold off
		// refresh curtime to avoid misrepresentations due to long delay before option selection
		// but don't change time if madenote to properly detect chunkid==curtime
		// if a new chunk was made during make_note()
		if (!madenote) curtime = time_stamp("%Y%m%d%H%M");
		String tl; int tlinsertloc;
		switch (lbuf[0]) {
			case 'c': case 'C':
				if (verbose) VOUT << "Continuing according to task list chunk controller suggestions\n";
				tlinsertloc = -1;
				if (!read_file_into_String(get_TL_head(),tl)) return String("");
				if (tl=="") return tl;
				if ((chunkid=decide_add_TL_chunk(tl,tlinsertloc,true,false))=="") return String("");
				break;
			case 's': case 'S':
				if (!chunkcreated) {
					if (verbose) VOUT << "Starting task chunk with new context\n";
					tlinsertloc = -1;
					if (!read_file_into_String(get_TL_head(),tl)) return String("");
					if (tl=="") return tl;
					if ((chunkid=decide_add_TL_chunk(tl,tlinsertloc,false,false))=="") return String("");
				} else {
					EOUT << "dil2al: Unknown option `" << lbuf[0] << "'\n";
					lbuf[0]='\0';
				}
				break;
			case 't': case 'T':
//*** instead of this approach, which exits once list tasks are paused
//*** it is possible to stay in this while loop and offer exit as well
//*** as start with comparetimes=false in the decide_add_TL_chunk() call
				if (verbose) VOUT << "Stopping task chunk and pausing list tasks\n";
				if (!read_file_into_String(get_TL_head(),tl)) return String("");
				if (tl=="") return tl;
				stop_TL_chunk(tl);
				if (!write_file_from_String(taskloghead,tl,"Task Log")) return String("");
				chunkid = "-1";
				break;
			case 'x': case 'X':
				if (verbose) VOUT << "Exiting and retaining current task state\n";
				chunkid = "-2";
				break;
			default:
				EOUT << "dil2al: Unknown option `" << lbuf[0] << "'\n";
				lbuf[0] = '\0';
		}
	}
	return chunkid;
}

inline time_t time_chunk_remaining(String chunkid) {
	time_t tdiff = timechunksize*60;
	tdiff -= time_stamp_diff(chunkid,time_stamp("%Y%m%d%H%M"));
	if (verbose) VOUT << "\nTask schedule controller: " << tdiff << " seconds remaining in time chunk\n(Current chunk initiated at " << chunkid << ")\n";
	return tdiff;
}

bool schedule_controller(String controllercmd) {
// schedules periodical calls to chunk_controller(),
// either via an at-job or by retaining dil2al as a daemon
	String chunkid;
	if (isdaemon) { // daemon schedules chunk_controller()
		String ccmd;
		while (1) {
			ccmd = controllercmd; // fresh copy of automatic commands to controller
			if ((chunkid=chunk_controller(ccmd))=="") return false;
			if ((chunkid=="-1") || (chunkid=="-2")) return true;
			time_t tdiff = time_chunk_remaining(chunkid);
			if (tdiff>0) sleep(tdiff);
		}
	} else { // at-job schedules chunk_controller()
		if ((chunkid=chunk_controller(controllercmd))=="") return false;
		if ((chunkid=="-1") || (chunkid=="-2")) return true;
#ifdef DEBUG
cout << "current chunkid = " << chunkid << '\n';
#endif
		time_t tdiff = time_chunk_remaining(chunkid);
#ifdef DEBUG
cout << "seconds remaining = " << tdiff << '\n';
#endif
		if (tdiff>0) {
			tdiff /= 60;
			String atcmd = atcommand;
			if (tdiff) { atcmd += " + "; atcmd += String((long) tdiff); atcmd += " minutes"; }
			else atcmd += " + 1 minute";
			FILE * p = popen((const char *) atcmd, "w");
			if (!p) {
				EOUT << "dil2al: Unable to schedule controller call with " << atcontroller << " in schedule_controller()\n";
				return false;
			}
			fprintf(p,(const char *) atcontroller);
			if (pclose(p)==-1) {
				EOUT << "dil2al: Scheduling controller call with " << atcontroller << " did not complete operations in schedule_controller()\n";
				return false;
			}
		}
	}
#ifdef DEBUG
const int LLEN = 10;
char lbuf[LLEN];
cout << "Scheduled controller processing completed...\n";
cin.getline(lbuf,LLEN);
#endif
	return true;
}
